@include('frontend.header')
<div class="slides">
<!-- Mutual Funds and Plans Start-->



<section id="fragments" data-transition="slide">


<div class="col-lg-12 product">
<p style="padding:19px 0;" class="product-heading-bg">Equity funds </p>

<div class="col-lg-12">
<a href="{{url('sf')}}"><img src="./images/Stock-fund-pimg.jpg" alt=""></a>
<a href="{{url('eqf')}}"><img src="./images/equity-fund-pimg.jpg" alt=""></a>
<a href="{{url('ieqf')}}"><img src="./images/islamic-equity-fund-pimg.jpg" alt=""></a>

</div>
<div class="col-lg-12">
<a href="{{url('isf')}}"><img src="./images/islamic-stock-fund-pimg.jpg" alt=""></a>
<a href="{{url('enf')}}"><img src="./images/energy-fund-pimg.jpg" alt=""></a>
</div>
<p class="product-heading-bg"><a style="color:#fff;" href="products">Products</a></p>
</div>
</section>

<!-- Mutual Funds and Plans End-->




</div>

</div>
@include('frontend.footer')