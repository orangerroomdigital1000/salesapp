@include('frontend.header')
<div class="slides">
<!-- Mutual Funds and Plans Start-->


<section id="fragments" data-transition="slide">

<div class="col-lg-12 product">
<h6>Choose Product</h6>
<p style="padding:15px 0;" class="product-heading-bg">Asset Allocation Funds </p>

<div class="col-lg-12">
<a href="{{url('iaaf')}}"><img src="./images/asset-allocation-fund-pimg.jpg" alt="">		</a>			
</div>
<p class="product-heading-bg"><a style="color:#fff;" href="products">All Products</a></p>
</div>
</section>

<!-- Mutual Funds and Plans End-->




</div>

</div>
@include('frontend.footer')