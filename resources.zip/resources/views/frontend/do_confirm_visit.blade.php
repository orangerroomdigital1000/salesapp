<html class=" js " style="overflow: hidden;"><head>
<title>App Name</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="Novus Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="{{url('css/bootstrap.css')}}" rel="stylesheet" type="text/css">
<!-- Custom CSS -->
<link href="{{url('css/style.css')}}" rel="stylesheet" type="text/css">
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="{{url('css/font-awesome.css')}}" rel="stylesheet"> 
<!-- //font-awesome icons -->
<!-- js-->
<script src="{{url('js/jquery-1.11.1.min.js')}}"></script>
<script src="{{url('js/modernizr.custom.js')}}"></script>
<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css">
<!--//webfonts--> 
<!--animate-->
<link href="{{url('css/animate.css')}}" rel="stylesheet" type="text/css" media="all">
<script src="{{url('js/wow.min.js')}}"></script>


<script>
new WOW().init();
</script>

</head> 
<body class="cbp-spmenu-push cbp-spmenu-push-toright">
<div class="main-content">
<div id="page-wrapper" style="min-height: 335px;">
<div class="main-page">

<div style="margin:auto; width:60%;" class="forms">

<div class=" form-grids row form-grids-right">
<div class="widget-shadow " data-example-id="basic-forms"> 
<div  class="form-title">
<h4 style="text-align: center;">Select Your Mode:</h4>
</div>
<div style="padding: 48px;" class="form-body">
<form method="POST" action="add-user" class="form-horizontal">
<input type="hidden" name="_token" value="7vKhZNvhAYNcODYKBqzBUJkVjQNG9Aoh6R17m0EE">								



<div class="form-group">
<div class="col-md-12">
<center>
<a href="{{url('user-dashboard')}}" class="btn btn-primary">Dashboard Mode</a>                                
<a href="{{url('welcome')}}" class="btn btn-primary">Presentation Mode</a>
</center>
</div>								
</div>
</form>
</div>
</div>
</div>
</div>
<div class="clearfix"> </div>


</div>
</div>

