@include('frontend.header')
<div class="slides">
<!-- Mutual Funds and Plans Start-->


<section id="fragments" data-transition="slide">


<div class="col-lg-12 product">

<p style="padding:15px 0; margin-bottom:0;" class="product-heading-bg">Pensions funds </p>
<div class="col-lg-12">
<a href="{{url('pf')}}"><img src="./images/hbl-pension-fund-pimg.jpg" alt=""></a>
<a href="{{url('ipf')}}"><img src="./images/islamic-pension-fund-pimg.jpg" alt=""></a>
</div>
<p class="product-heading-bg"><a style="color:#fff;" href="products">All Products</a></p>
</div>
</section>

<!-- Mutual Funds and Plans End-->




</div>

</div>
@include('frontend.footer')