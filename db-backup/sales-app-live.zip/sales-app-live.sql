-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for sales-app-live
CREATE DATABASE IF NOT EXISTS `sales-app-live` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `sales-app-live`;

-- Dumping structure for table sales-app-live.aa1
CREATE TABLE IF NOT EXISTS `aa1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aa1_key` varchar(191) DEFAULT NULL,
  `aa1_v1` varchar(191) DEFAULT NULL,
  `aa1_v2` varchar(191) DEFAULT NULL,
  `aa1_v3` varchar(191) DEFAULT NULL,
  `fund_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.aa1: ~25 rows (approximately)
/*!40000 ALTER TABLE `aa1` DISABLE KEYS */;
REPLACE INTO `aa1` (`id`, `aa1_key`, `aa1_v1`, `aa1_v2`, `aa1_v3`, `fund_id`, `created_at`, `updated_at`) VALUES
	(1, 'Equity Funds', '19.01%', '52.06%', '0%', 23, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(2, 'Fixed Income Funds', '75.52%', '46.99%', '0%', 23, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(3, 'Cash', '4.96%', '0.82%', '0%', 23, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(4, 'Others Including Receivables', '0.51%', '0.13%', '0%', 23, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(5, 'Equity Funds', '18.60%', '51.60%', '-', 24, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(6, 'Fixed Income Funds', '73.98%', '42.30%', '-', 24, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(7, 'Cash', '6.33%', '4.96%', '-', 24, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(8, 'Others including receivables', '1.09%', '1.14%', '-', 24, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(9, 'T-Bills', '92.01%', '38.35%', '-', 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(10, 'Cash', '4.34%', '3.18%', '4.90%', 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(12, 'Commercial Paper', '3.23%', '-', '-', 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(13, 'PIBs', '-', '43.50%', '-', 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(14, 'TFCs/ Sukuks', '-', '13.25%', '-', 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(16, 'Stock / Equities', '-', '-', '94.97%', 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(17, 'Others Including Receivables', '0.42%', '1.72%', '0.13%', 25, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(19, 'Cash', '94.93%', '78.98%', '11.05%', 26, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(21, 'TFCs/ Sukuks', '-', '18.95%', '-', 26, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(23, 'Commercial Paper', '3.63%', '-', '-', 26, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(24, 'Stock / Equities', '-', '-', '88.77%', 26, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(25, 'Others including Receivables', '1.44%', '2.07%', '0.18%', 26, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(27, 'GoP Ijarah Sukuk', '-', '-', '-', 26, NULL, NULL);
/*!40000 ALTER TABLE `aa1` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.asset_allocation
CREATE TABLE IF NOT EXISTS `asset_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aa_keys` varchar(191) DEFAULT NULL,
  `aa_values` varchar(191) DEFAULT NULL,
  `fund_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.asset_allocation: ~53 rows (approximately)
/*!40000 ALTER TABLE `asset_allocation` DISABLE KEYS */;
REPLACE INTO `asset_allocation` (`id`, `aa_keys`, `aa_values`, `fund_id`, `created_at`, `updated_at`) VALUES
	(2, 'Placements with Banks & DFIs', '8.07%', 10, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(3, 'T-Bills', '85.74%', 10, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(4, 'Commercial Paper', '4.69%', 10, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(5, 'Others Including receivables', '0.34%', 10, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(6, 'Cash', '80.98%', 11, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(8, 'Commercial paper', '5.61%', 11, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(9, 'Others Including receivables', '1.58%', 11, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(12, 'TFCs / Sukuks', '21.17%', 12, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(14, 'Others Including receivables', '2.05%', 12, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(15, 'Certificate of Modaraba', '5.76%', 12, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(16, 'Cash', '2.07%', 13, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(18, 'Commercial Paper', '2.85%', 13, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(21, 'Others Including receivables', '0.55%', 13, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(22, 'Cash', '10.14%', 14, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(24, 'TFCs/Sukuks', '27.07%', 14, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(29, 'PIBs', '26.93%', 14, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(30, 'Cash', '5.19%', 15, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(37, 'Cash', '7.08%', 16, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(38, 'Stock/Equities', '91.59%', 16, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(40, 'Others including receivables', '1.33%', 16, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(41, 'Cash', '12.82%', 17, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(42, 'Stock/Equities', '86.38%', 17, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(43, 'Others including receivables', '0.80%', 17, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(44, 'Cash', '16.80%', 18, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(45, 'Stock/Equities', '81.85%', 18, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(46, 'Others including receivables', '1.35%', 18, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(47, 'Cash%', '9.16%', 19, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(48, 'Stock/Equities', '90.01%', 19, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(49, 'Others including receivables', '0.83%', 19, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(50, 'Cash', '6.66%', 20, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(51, 'Stock/Equities', '92.18%', 20, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(52, 'Others including receivables', '1.16%', 20, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(53, 'Cash', '35.33%', 21, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(55, 'TFC/ Sukuks', '20.58%', 21, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(56, 'Stock/Equities', '29.99%', 21, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(57, 'GoP Ijarah Sukuk & Certificate of Modaraba', '10.59%', 21, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(58, 'Cash', '26.16%', 22, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(60, 'TFCs/Sukuks', '7.36%', 22, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(63, 'Stock / Equities', '64.65%', 22, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(64, 'Others including receivables', '1.83%', 22, '2018-07-10 11:20:59', '2018-07-10 11:20:59'),
	(66, 'Cash', '71.02%', 12, '2018-07-20 16:24:39', '2018-07-20 16:24:39'),
	(68, 'Commercial Paper', '0.00%', 15, '2018-10-15 16:19:39', '2018-10-15 16:19:39'),
	(69, 'Placements with Banks & DFIs', '6.93%', 13, '2018-11-20 14:51:34', '2018-11-20 14:51:34'),
	(71, 'Others Including Receivables', '3.51%', 21, '2018-11-22 12:32:45', '2018-11-22 12:32:45'),
	(72, 'Commercial Paper', '3.70%', 14, '2019-02-12 10:31:12', '2019-02-12 10:31:12'),
	(74, 'Others Including Receivables', '0.57%', 14, '2019-03-11 10:12:05', '2019-03-11 10:12:05'),
	(75, 'PIBs', '65.23%', 15, '2019-03-11 10:16:25', '2019-03-11 10:16:25'),
	(76, 'TFCs / Sukuks', '2.36%', 15, '2019-03-11 10:16:44', '2019-03-11 10:16:44'),
	(78, 'T-Bills', '87.60%', 13, '2019-05-16 10:04:27', '2019-05-16 10:04:27'),
	(79, 'T-Bills', '24.14%', 15, '2019-05-16 10:13:50', '2019-05-16 10:13:50'),
	(81, 'Cash', '1.16%', 10, '2019-07-17 14:36:24', '2019-07-17 14:36:24'),
	(82, 'TFCs / Sukuks', '0.00%', 10, '2019-08-26 10:04:38', '2019-08-26 10:04:38'),
	(83, 'Others including receivables', '3.08%', 15, '2019-08-26 10:51:12', '2019-08-26 10:51:12'),
	(84, 'T-Bills', '31.59%', 14, '2019-11-15 11:57:56', '2019-11-15 11:57:56'),
	(85, 'Placement with Banks & DFI', '0.00%', 21, '2019-11-15 12:33:55', '2019-11-15 12:33:55'),
	(86, 'T-Bills', '0.00%', 16, '2019-12-12 13:20:57', '2019-12-12 13:20:57'),
	(87, 'TFCs / Sukuks', '11.83%', 11, '2020-06-10 23:17:55', '2020-06-10 23:17:55');
/*!40000 ALTER TABLE `asset_allocation` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.aums1
CREATE TABLE IF NOT EXISTS `aums1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f1` varchar(3000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.aums1: ~0 rows (approximately)
/*!40000 ALTER TABLE `aums1` DISABLE KEYS */;
REPLACE INTO `aums1` (`id`, `title`, `f1`, `created_at`, `updated_at`) VALUES
	(1, 'Assets Under Management (AUMs).', 'During the past 10 years, HBL AMC Assets Under Management has shown a CAGR of 28.03%. AUMs grew from Rs. 5.2 billion in 2010 to Rs.  61.54 billion in July 2020. This illustrates the HBL AMC commitment to becoming one of the leading asset management company.', NULL, NULL);
/*!40000 ALTER TABLE `aums1` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.aums2
CREATE TABLE IF NOT EXISTS `aums2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f1` varchar(3000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.aums2: ~0 rows (approximately)
/*!40000 ALTER TABLE `aums2` DISABLE KEYS */;
REPLACE INTO `aums2` (`id`, `title`, `f1`, `created_at`, `updated_at`) VALUES
	(1, 'Assets Under Management (AUMs)', 'As of July 2020, 24.06% of our assets under management consists of Equity Schemes which offer high returns. Followed by Money Market and Fixed Income (75.53% cumulative) Schemes for those who are willing to opt for consistent returns.', NULL, NULL);
/*!40000 ALTER TABLE `aums2` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.aums_1_chart
CREATE TABLE IF NOT EXISTS `aums_1_chart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aums_1_key` varchar(191) NOT NULL,
  `aums_1_value` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.aums_1_chart: ~5 rows (approximately)
/*!40000 ALTER TABLE `aums_1_chart` DISABLE KEYS */;
REPLACE INTO `aums_1_chart` (`id`, `aums_1_key`, `aums_1_value`) VALUES
	(1, 'July 20', '61,537'),
	(2, 'Dec 19', '46910'),
	(3, 'Dec 18', '51806'),
	(4, 'Dec 17', '55693'),
	(5, 'Dec 16', '52406');
/*!40000 ALTER TABLE `aums_1_chart` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.aums_2_chart
CREATE TABLE IF NOT EXISTS `aums_2_chart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aums_2_key` varchar(191) NOT NULL,
  `aums_2_value` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.aums_2_chart: ~6 rows (approximately)
/*!40000 ALTER TABLE `aums_2_chart` DISABLE KEYS */;
REPLACE INTO `aums_2_chart` (`id`, `aums_2_key`, `aums_2_value`) VALUES
	(1, 'Equity Schemes', '14,807'),
	(2, 'Fixed Income Schemes', '6,597'),
	(3, 'Money Market Schemes', '38,038'),
	(4, 'Balanced Schemes', '529'),
	(5, 'Pension Schemes', '852'),
	(6, 'Funds of Funds Schemes', '714');
/*!40000 ALTER TABLE `aums_2_chart` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.awards
CREATE TABLE IF NOT EXISTS `awards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f1_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f1_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f2_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f2_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f3_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f3_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f4_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f4_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f5_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f5_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f6_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f6_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f7_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f7_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f8_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f8_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f9_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f9_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f10_bold` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f10_normal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.awards: ~0 rows (approximately)
/*!40000 ALTER TABLE `awards` DISABLE KEYS */;
REPLACE INTO `awards` (`id`, `title`, `f1_bold`, `f1_normal`, `f2_bold`, `f2_normal`, `f3_bold`, `f3_normal`, `f4_bold`, `f4_normal`, `f5_bold`, `f5_normal`, `f6_bold`, `f6_normal`, `f7_bold`, `f7_normal`, `f8_bold`, `f8_normal`, `f9_bold`, `f9_normal`, `f10_bold`, `f10_normal`, `created_at`, `updated_at`) VALUES
	(1, 'Awards – Habib Bank Limited', 'Bank of the Year', 'in Pakistan (The Banker)', 'Safest Bank', 'in Pakistan (Global Finance)', 'Best Domestic Bank', '- Pakistan (Asiamoney)', 'Brand of the Year, Banking', '- Pakistan (World Branding Awards)', 'Best Investment Bank', 'in Pakistan (Global Finance)', 'Best Retail Bank', 'in Pakistan (Asian Banker)', 'Best Trade Finance Bank', 'in Pakistan (Global Finance)', 'Best Bank for Small Business & Agriculture', '(Institute of Bankers Pakistan IBP Awards)', 'Best Environmental, Social and Governance Bank', '(Institute of Bankers Pakistan IBP Awards)', 'The Innovators of Transaction Services', '(Global Finance, Digital Bank Awards)', NULL, NULL);
/*!40000 ALTER TABLE `awards` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.banks
CREATE TABLE IF NOT EXISTS `banks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` varchar(191) DEFAULT NULL,
  `bank_color` varchar(191) NOT NULL,
  `chart_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.banks: ~10 rows (approximately)
/*!40000 ALTER TABLE `banks` DISABLE KEYS */;
REPLACE INTO `banks` (`id`, `bank`, `bank_color`, `chart_id`) VALUES
	(1, 'HBL', '#01a896', 1),
	(2, 'UBL', '#004b92', 1),
	(3, 'MCB', '#50b748', 1),
	(4, 'NBP', '#FC0', 1),
	(5, 'ABL', '#fe652c', 1),
	(6, 'HBL', '#01a896', 2),
	(7, 'UBL', '#004b92', 2),
	(8, 'MCB', '#50b748', 2),
	(9, 'NBP', '#FC0', 2),
	(10, 'ABL', '#fe652c', 2);
/*!40000 ALTER TABLE `banks` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.bank_details
CREATE TABLE IF NOT EXISTS `bank_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iban_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.bank_details: 3 rows
/*!40000 ALTER TABLE `bank_details` DISABLE KEYS */;
REPLACE INTO `bank_details` (`id`, `bank_name`, `branch_name`, `account_title`, `iban_number`, `customer_id`, `created_at`, `updated_at`) VALUES
	(59, 'HBL / Konnect', 'KARACHI', 'ALI', '123412341234123412341234', 106, '2020-06-15 10:53:51', '2020-06-15 10:53:51'),
	(60, 'HBL / Konnect', 'KARACHI', 'ALI', '123412341234123412341234', 107, '2020-06-15 10:54:00', '2020-06-15 10:54:00'),
	(61, 'HBL / Konnect', 'KARACHI', 'ALI', '123412341234123412341234', 108, '2020-06-15 10:54:27', '2020-06-15 10:54:27'),
	(62, 'HBL / Konnect', 'KARACHI', 'ALI', '123412341234123412341234', 109, '2020-06-15 10:54:41', '2020-06-15 10:54:41'),
	(63, 'HBL / Konnect', 'KARACHI', 'ALI', '123412341234123412341234', 110, '2020-06-15 10:54:42', '2020-06-15 10:54:42'),
	(64, 'HBL / Konnect', 'KARACHI', 'ALI', '123412341234123412341234', 111, '2020-06-15 10:54:46', '2020-06-15 10:54:46'),
	(65, 'HBL / Konnect', 'KARACHI', 'ALI', '123412341234123412341234', 112, '2020-06-15 10:55:02', '2020-06-15 10:55:02'),
	(66, 'ALBARAKA', 'SHAHRAH E FAISAL', 'ALI HAMZA', 'PK00ABA11112226668887778', 113, '2020-06-16 14:23:08', '2020-06-16 14:23:08'),
	(67, 'ALBARAKA', 'SHAHRAH E FAISAL', 'ALI HAMZA', 'PK00ABA11112226668887778', 114, '2020-06-16 14:23:16', '2020-06-16 14:23:16'),
	(68, 'HBL / Konnect', 'MALL BRANCH LAHORE', 'SHAHZAD UL HAQ', 'PK27HABB0012427949198001', 115, '2020-06-18 14:17:12', '2020-06-18 14:17:12'),
	(69, 'HBL / Konnect', 'MALL BRANCH LAHORE', 'SHAHZAD UL HAQ', 'PK27HABB0012427949198001', 116, '2020-06-18 14:17:16', '2020-06-18 14:17:16'),
	(70, 'HBL / Konnect', 'MALL BRANCH LAHORE', 'SHAHZAD UL HAQ', 'PK27HABB0012427949198001', 117, '2020-06-18 14:17:26', '2020-06-18 14:17:26'),
	(71, 'HBL / Konnect', 'CORPORATE BRANCH LAHORE', 'FIAZ AHMED KHAN', 'PK88HABB0012427949025601', 118, '2020-06-18 14:35:33', '2020-06-18 14:35:33'),
	(72, 'ALFALAH', 'KHAYABAN-E-IQBAL DHA LAHORE', 'SYED ALI RAZA ZAIDI', 'PK58ALFH0364001006920518', 119, '2020-06-18 14:54:42', '2020-06-18 14:54:42'),
	(73, 'ALFALAH', 'KHAYABAN-E-IQBAL DHA LAHORE', 'SYED ALI RAZA ZAIDI', 'PK58ALFH0364001006920518', 120, '2020-06-18 14:54:49', '2020-06-18 14:54:49'),
	(74, 'SCB', 'KARACHI MAIN', 'MUHAMMAD MOAZ QURESHI', 'PK23SCBL0000001417322801', 121, '2020-06-18 15:06:25', '2020-06-18 15:06:25'),
	(75, 'SCB', 'KARACHI MAIN', 'MUHAMMAD MOAZ QURESHI', 'PK23SCBL0000001417322801', 122, '2020-06-18 15:06:31', '2020-06-18 15:06:31'),
	(76, 'HBL / Konnect', 'DOLMEN', 'ZIA JAVED', 'PK32 HABL 01234567981234', 140, '2020-06-19 14:31:54', '2020-06-19 14:31:54'),
	(77, 'HBL / Konnect', 'DOLMEN', 'ZIA JAVED', 'PK32 HABL 01234567981234', 141, '2020-06-19 14:32:03', '2020-06-19 14:32:03'),
	(78, 'HBL / Konnect', 'BILAWAL CHORANGI', '009273U82P011P2', 'PKHBL2349999999999999999', 142, '2020-06-19 14:38:56', '2020-06-19 14:38:56'),
	(79, 'HBL / Konnect', 'BILAWAL CHORANGI', '009273U82P011P2', 'PKHBL2349999999999999999', 143, '2020-06-19 14:39:00', '2020-06-19 14:39:00'),
	(80, 'HBL / Konnect', 'BILAWAL CHORANGI', '009273U82P011P2', 'PKHBL2349999999999999999', 144, '2020-06-19 14:39:12', '2020-06-19 14:39:12'),
	(81, 'HBL / Konnect', 'SHAH RUKNE ALAM MULTAN', 'FAISAL SHABBIR', 'PK35HABB0022257901926501', 147, '2020-06-22 10:35:50', '2020-06-22 10:35:50'),
	(82, 'HBL / Konnect', 'SHAH RUKNE ALAM MULTAN', 'FAISAL SHABBIR', 'PK35HABB0022257901926501', 148, '2020-06-22 10:35:56', '2020-06-22 10:35:56'),
	(83, 'HBL / Konnect', 'TESTING', '21131313131', '012345678901234567890123', 151, '2020-06-22 12:24:40', '2020-06-22 12:24:40'),
	(84, 'HBL / Konnect', 'TESTING', '21131313131', '012345678901234567890123', 152, '2020-06-22 12:24:43', '2020-06-22 12:24:43'),
	(85, 'ALBARAKA', 'TEST', 'TEST', '12233333-((3333489+9179)', 154, '2020-06-22 12:38:50', '2020-06-22 12:38:50'),
	(86, 'ALBARAKA', 'TEST', 'TEST', '12233333-((3333489+9179)', 155, '2020-06-22 12:39:09', '2020-06-22 12:39:09'),
	(87, 'ABL', 'TESTING', '179YY9Y', 'Y6Y6Y6YY6Y666^YY6YYYY6Y6', 157, '2020-06-22 13:05:37', '2020-06-22 13:05:37'),
	(88, 'ABL', 'TESTING', '179YY9Y', 'Y6Y6Y6YY6Y666^YY6YYYY6Y6', 158, '2020-06-22 13:06:13', '2020-06-22 13:06:13'),
	(89, 'HBL / Konnect', 'TESTING', 'Y7856', '555555557757789866887878', 160, '2020-06-22 13:18:16', '2020-06-22 13:18:16'),
	(90, 'HBL / Konnect', 'NORTH NAZIMABAD', 'MUHAMMAD UMER', '637327889297636256282936', 161, '2020-06-22 15:30:58', '2020-06-22 15:30:58'),
	(91, 'HBL / Konnect', 'NORTH NAZIMABAD', 'MUHAMMAD UMER', '637327889297636256282936', 162, '2020-06-22 15:31:02', '2020-06-22 15:31:02'),
	(92, 'HBL / Konnect', 'NORTH NAZIMABAD', 'MUHAMMAD UMER', '637327889297636256282936', 163, '2020-06-22 15:31:06', '2020-06-22 15:31:06'),
	(93, 'SILK Bank', 'KORANGI ROAD', 'SYED IMRAN AHMED', 'ASBL00001234567810121234', 164, '2020-06-22 15:34:45', '2020-06-22 15:34:45'),
	(94, 'HBL / Konnect', 'KHE HAFIZ', 'SARDAR ALY', '123456789012345678900000', 169, '2020-06-23 10:11:23', '2020-06-23 10:11:23'),
	(95, 'HBL / Konnect', 'KHE HAFIZ', 'SARDAR ALY', '123456789012345678900000', 170, '2020-06-23 10:11:27', '2020-06-23 10:11:27'),
	(96, 'HBL / Konnect', 'KHE HAFIZ', 'SARDAR ALY', '123456789012345678900000', 171, '2020-06-23 10:11:32', '2020-06-23 10:11:32'),
	(97, 'ADVANS PAK MIRCOFINANCE', 'ZAMZAMA', 'ALI', 'PK00APM00123456677888665', 172, '2020-06-23 10:44:51', '2020-06-23 10:44:51'),
	(98, 'ADVANS PAK MIRCOFINANCE', 'ZAMZAMA', 'ALI', 'PK00APM00123456677888665', 173, '2020-06-23 10:44:55', '2020-06-23 10:44:55'),
	(99, 'HBL / Konnect', 'CLIFTON', 'LUBNA AHMED', '727272727277272777777777', 174, '2020-06-23 12:51:07', '2020-06-23 12:51:07'),
	(100, 'ALBARAKA', 'PECHS', 'NOMAN ALI', 'PK000ALB1234567891011121', 178, '2020-06-24 12:44:19', '2020-06-24 12:44:19'),
	(101, 'ALBARAKA', 'PECHS', 'NOMAN ALI', 'PK000ALB1234567891011121', 179, '2020-06-24 12:44:21', '2020-06-24 12:44:21'),
	(102, 'HBL / Konnect', 'CDA CIVIC CENTER', 'SAEEM KHAN', 'PK42HABB0006027901254879', 181, '2020-06-25 15:28:24', '2020-06-25 15:28:24'),
	(56, 'HBL / Konnect', 'SHAHRA E FAISAL', 'M. ALI', 'PK00HBL00011111111122222', 100, '2020-05-20 13:03:14', '2020-05-20 13:03:14'),
	(57, 'HBL / Konnect', 'SHAHRA E FAISAL', 'M. ALI', 'PK00HBL00011111111122222', 101, '2020-05-20 13:03:17', '2020-05-20 13:03:17'),
	(58, 'HBL / Konnect', 'SHAHRA E FAISAL', 'M. ALI', 'PK00HBL00011111111122222', 102, '2020-05-20 13:03:18', '2020-05-20 13:03:18'),
	(103, 'HBL / Konnect', 'CDA CIVIC CENTER', 'SAEEM KHAN', 'PK42HABB0006027901254879', 182, '2020-06-25 15:28:30', '2020-06-25 15:28:30'),
	(104, 'HBL / Konnect', 'CDA CIVIC CENTER', 'SAEEM KHAN', 'PK42HABB0006027901254879', 183, '2020-06-25 15:35:53', '2020-06-25 15:35:53'),
	(105, 'HBL / Konnect', 'CDA CIVIC CENTER', 'SAEEM KHAN', 'PK42HABB0006027901254879', 184, '2020-06-25 15:35:58', '2020-06-25 15:35:58'),
	(106, 'MEEZAN BANK', 'JINNAH AVENUE - ISLAMABAD', 'MUHAMMAD DAWOOD KHOKHAR', 'PK11MEZ10100100528652001', 185, '2020-06-25 15:50:36', '2020-06-25 15:50:36'),
	(107, 'ALFALAH', 'JINNAH AVENUE - ISLAMABAD', 'USMAN BIN LADIN', 'PK71ALH10100100528652002', 186, '2020-06-25 16:06:11', '2020-06-25 16:06:11'),
	(108, 'HBL / Konnect', 'F-6', 'MUZAFFAR KHAN', 'PK54HABB0013537901244103', 188, '2020-06-26 11:32:59', '2020-06-26 11:32:59'),
	(109, 'HBL / Konnect', 'F-6', 'MUZAFFAR KHAN', 'PK54HABB0013537901244103', 189, '2020-06-26 11:33:06', '2020-06-26 11:33:06'),
	(110, 'HBL / Konnect', 'F-6', 'MUZAFFAR KHAN', 'PK54HABB0013537901244103', 190, '2020-06-26 11:33:30', '2020-06-26 11:33:30'),
	(111, 'HBL / Konnect', 'F-6', 'MUZAFFAR KHAN', 'PK54HABB0013537901244103', 191, '2020-06-26 11:33:30', '2020-06-26 11:33:30'),
	(112, 'HBL / Konnect', 'F-6', 'MUZAFFAR KHAN', 'PK54HABB0013537901244103', 192, '2020-06-26 11:33:31', '2020-06-26 11:33:31'),
	(113, 'HBL / Konnect', 'HBL F6 ISLAMABAD', 'AWAIS AHMAD', 'PK59HABB0013537901845801', 194, '2020-07-01 11:32:31', '2020-07-01 11:32:31'),
	(114, 'HBL / Konnect', 'HBL F6 ISLAMABAD', 'AWAIS AHMAD', 'PK59HABB0013537901845801', 193, '2020-07-01 11:32:31', '2020-07-01 11:32:31'),
	(115, 'HBL / Konnect', 'BLUE AREA', 'MARIASHAHNAWAZ', 'PKHBL0987654321568086557', 195, '2020-07-01 11:47:00', '2020-07-01 11:47:00'),
	(116, 'HBL / Konnect', 'COMMITTEE CHOWK RAWALPINDI', 'RAJA USMAN AHMED', 'PK07HABB0002157901071403', 197, '2020-07-01 12:04:09', '2020-07-01 12:04:09'),
	(117, 'HBL / Konnect', 'COMMITTEE CHOWK RAWALPINDI', 'RAJA USMAN AHMED', 'PK07HABB0002157901071403', 198, '2020-07-01 12:04:14', '2020-07-01 12:04:14'),
	(118, 'MEEZAN BANK', 'ABC', 'SUMBAL NAZ', '123456789123456789123456', 199, '2020-07-01 14:38:00', '2020-07-01 14:38:00'),
	(119, 'MEEZAN BANK', 'ABC', 'SUMBAL NAZ', '123456789123456789123456', 200, '2020-07-01 14:38:07', '2020-07-01 14:38:07'),
	(120, 'MEEZAN BANK', 'ABC', 'SUMBAL NAZ', '123456789123456789123456', 201, '2020-07-01 14:38:24', '2020-07-01 14:38:24'),
	(121, 'ABL', 'PECHS', 'ALI', 'PK0000000000000000000000', 202, '2020-07-07 13:34:24', '2020-07-07 13:34:24'),
	(122, 'ABL', 'ZAMZAMA', 'ALI JAN', 'PK00ABL00045454545454545', 203, '2020-07-20 16:50:05', '2020-07-20 16:50:05'),
	(123, 'ABL', 'ZAMZAMA', 'ALI JAN', 'PK00ABL00045454545454545', 204, '2020-07-20 16:50:10', '2020-07-20 16:50:10'),
	(124, '1', '1', 'TESTER', 'TESTEREQEQEEEQEEQEEEEEEE', 208, '2020-07-29 15:07:04', '2020-07-29 15:07:04'),
	(125, '1', '1', 'TESTER', 'TESTEREQEQEEEQEEQEEEEEEE', 209, '2020-07-29 15:07:12', '2020-07-29 15:07:12'),
	(126, '1', '1', 'TESTER', 'TESTER123456789987456123', 210, '2020-07-29 15:09:57', '2020-07-29 15:09:57'),
	(127, '1', '1', 'TESTER', 'TESTER123456789987456123', 211, '2020-07-29 15:10:04', '2020-07-29 15:10:04'),
	(128, '2|ABL', '17|Karachi, Baba-E-Urdu', 'OMAIR INAM', 'PK04IBAN7897897897897898', 213, '2020-08-20 16:35:03', '2020-08-20 16:35:03'),
	(129, '2|ABL', '33|Liberty Market Lahore', 'ALI MIRZA', 'PK00ABL12345678901234567', 214, '2020-08-24 16:28:58', '2020-08-24 16:28:58'),
	(130, '5|BAFL', '248|F-10, Markaz', 'ALI MIRZA', 'PK0012345678901233445566', 215, '2020-08-27 10:01:52', '2020-08-27 10:01:52'),
	(131, '5|BAFL', '248|F-10, Markaz', 'ALI MIRZA', 'PK0012345678901233445566', 216, '2020-08-27 10:01:54', '2020-08-27 10:01:54'),
	(132, '14|HBL', '442|Karachi-Jacob Lines', 'OMAIR INAM', 'PK04IBAN7897897897897898', 218, '2020-08-31 13:44:17', '2020-08-31 13:44:17'),
	(133, '35|AHBL', '1680|ARIF HABIB BANK LIMITED - Default Branch', 'OMAIR INAM', 'PK04IBAN7897897897897875', 220, '2020-08-31 13:47:45', '2020-08-31 13:47:45'),
	(134, '2|ABL', '20|Dastgir Colony Branch, Karachi', 'OMAIR INAM', 'PK04IBAN7897897897897987', 221, '2020-08-31 13:51:23', '2020-08-31 13:51:23'),
	(135, '2|ABL', '20|Dastgir Colony Branch, Karachi', 'OMAIR INAM', 'PK04IBAN7897897897897987', 222, '2020-08-31 13:51:27', '2020-08-31 13:51:27');
/*!40000 ALTER TABLE `bank_details` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.charts
CREATE TABLE IF NOT EXISTS `charts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `val` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fund_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.charts: ~75 rows (approximately)
/*!40000 ALTER TABLE `charts` DISABLE KEYS */;
REPLACE INTO `charts` (`id`, `year`, `val`, `ret`, `plan`, `fund_id`, `created_at`, `updated_at`) VALUES
	(7, '1 year', '11092', '10.92', NULL, 11, NULL, NULL),
	(8, '3 year', '12586', '8.62', NULL, 11, NULL, NULL),
	(9, '1 year', '10957', '9.57', NULL, 12, NULL, NULL),
	(10, '3 year', '12523', '8.41', NULL, 12, NULL, NULL),
	(11, '1 year', '11187', '11.87', NULL, 13, NULL, NULL),
	(12, '3 year', '12850', '9.50', NULL, 13, NULL, NULL),
	(13, '1 year', '11220', '12.20', NULL, 14, NULL, NULL),
	(14, '3 year', '12889', '9.63', NULL, 14, NULL, NULL),
	(15, '1 year', '11506', '15.06', NULL, 15, NULL, NULL),
	(16, '3 year', '13264', '10.88', NULL, 15, NULL, NULL),
	(17, '1 year', '11553', '15.53', NULL, 16, NULL, NULL),
	(18, '3 year', '8251', '-17.49', NULL, 16, NULL, NULL),
	(19, '1 year', '13249', '32.49', NULL, 17, NULL, NULL),
	(20, '3 year', '9627', '-3.73', NULL, 17, NULL, NULL),
	(21, '1 year', '12143', '21.43', NULL, 18, NULL, NULL),
	(22, '3 year', '8399', '-16.01', NULL, 18, NULL, NULL),
	(23, '1 Year', '12393', '23.93', NULL, 19, NULL, NULL),
	(24, '3 Year', '8307', '-16.93', NULL, 19, NULL, NULL),
	(25, '1 year', '10749', '7.49', NULL, 20, NULL, NULL),
	(26, '3 year', '6966', '-30.34', NULL, 20, NULL, NULL),
	(27, '1 year', '11209', '12.09', NULL, 21, NULL, NULL),
	(28, '3 year', '10838', '8.38', NULL, 21, NULL, NULL),
	(29, '1 year', '11318', '13.18', NULL, 22, NULL, NULL),
	(30, '3 year', '9562', '-4.38', NULL, 22, NULL, NULL),
	(33, '5 year', '13795', '7.34', NULL, 11, NULL, NULL),
	(34, '5 year', '13950', '7.64', NULL, 12, NULL, NULL),
	(35, '5 year', '14524', '8.75', NULL, 13, NULL, NULL),
	(36, '5 year', '14410', '8.53', NULL, 14, NULL, NULL),
	(37, '5 year', '15216', '10.09', NULL, 15, NULL, NULL),
	(38, '5 year', '9965', '--0.35', NULL, 16, NULL, NULL),
	(39, '5 year', '12151', '21.51', NULL, 17, NULL, NULL),
	(40, '5 year', '10820', '8.20', NULL, 18, NULL, NULL),
	(41, '5 Year', '10145', '1.45', NULL, 19, NULL, NULL),
	(42, '5 year', '9182', '-8.18', NULL, 20, NULL, NULL),
	(43, '5 year', '10000', '0.00%', NULL, 21, NULL, NULL),
	(44, '5 year', '11574', '15.74', NULL, 22, NULL, NULL),
	(45, '1 year', '11234', '12.34', NULL, 10, NULL, NULL),
	(46, '3 year', '12976', '9.92', NULL, 10, NULL, NULL),
	(47, '5 year', '14901', '9.48', NULL, 10, NULL, NULL),
	(48, '1 year', '11122', '11.22', 'mmsf', 25, NULL, NULL),
	(49, '3 year', '12580', '8.60', 'mmsf', 25, NULL, NULL),
	(50, '5 year', '13821', '7.39', 'mmsf', 25, NULL, NULL),
	(51, '1 year', '11775', '17.75', 'dsf', 25, NULL, NULL),
	(52, '3 year', '13309', '11.03', 'dsf', 25, NULL, NULL),
	(53, '5 year', '15097', '9.86', 'dsf', 25, NULL, NULL),
	(54, '1 year', '12536', '25.36', 'esf', 25, NULL, NULL),
	(55, '3 year', '9338', '-6.62', 'esf', 25, NULL, NULL),
	(56, '5 year', '12255', '22.55', 'esf', 25, NULL, NULL),
	(57, '1 year', '10765', '7.65', 'mmsf', 26, NULL, NULL),
	(58, '3 year', '11920', '6.40', 'mmsf', 26, NULL, NULL),
	(59, '5 year', '12859', '5.53', 'mmsf', 26, NULL, NULL),
	(60, '1 year', '10695', '6.95', 'dsf', 26, NULL, NULL),
	(61, '3 year', '11896', '6.32', 'dsf', 26, NULL, NULL),
	(62, '5 year', '12968', '5.74', 'dsf', 26, NULL, NULL),
	(63, '1 year', '12869', '28.69', 'esf', 26, NULL, NULL),
	(64, '3 year', '8973', '-10.27', 'esf', 26, NULL, NULL),
	(65, '5 year', '11716', '17.16', 'esf', 26, NULL, NULL),
	(66, '90 Days', '10337', '3.37', 'cap', 23, NULL, NULL),
	(67, '180 Days', '10198', '1.98', 'cap', 23, NULL, NULL),
	(68, '1 Year', '11221', '12.21', 'cap', 23, NULL, NULL),
	(69, '90 Days', '10694', '6.94', 'aap', 23, NULL, NULL),
	(70, '180 Days', '9809', '-1.91', 'aap', 23, NULL, NULL),
	(71, '1 Year', '11519', '15.19', 'aap', 23, NULL, NULL),
	(72, '90 Days', '0', '0', 'sap', 23, NULL, NULL),
	(73, '180 Days', '0', '0', 'sap', 23, NULL, NULL),
	(74, '1 Year', '0', '0', 'sap', 23, NULL, NULL),
	(75, '90 Days', '10315', '3.15', 'cap', 24, NULL, NULL),
	(76, '180 Days', '10322', '3.22', 'cap', 24, NULL, NULL),
	(77, '1 Year', '11378', '13.78', 'cap', 24, NULL, NULL),
	(78, '90 Days', '10572', '5.72', 'aap', 24, NULL, NULL),
	(79, '180 Days', '9578', '-4.22', 'aap', 24, NULL, NULL),
	(80, '1 Year', '11271', '12.71', 'aap', 24, NULL, NULL),
	(81, '90 Days', '-', '-', 'sap', 24, NULL, NULL),
	(82, '180 Days', '-', '-', 'sap', 24, NULL, NULL),
	(83, '1 Year', '-', '-', 'sap', 24, NULL, NULL);
/*!40000 ALTER TABLE `charts` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.customers
CREATE TABLE IF NOT EXISTS `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `qq` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mother_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnic` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnic_attachment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnic_issue_date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pob_city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pob_country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cell` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occ_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `org_emp_bes_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_experience` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age_of_business` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `education` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marital_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_of_dependants` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public_figure` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `average_annual_income` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refused_account_by_institute` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_value_item` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `soi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `soi_attachment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zakat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zakat_options` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zakat_certificate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.customers: 5 rows
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
REPLACE INTO `customers` (`id`, `qq`, `name`, `father_name`, `mother_name`, `dob`, `cnic`, `cnic_attachment`, `cnic_issue_date`, `pob_city`, `pob_country`, `email`, `cell`, `occupation`, `occ_name`, `designation`, `department`, `org_emp_bes_name`, `working_experience`, `age_of_business`, `education`, `marital_status`, `no_of_dependants`, `public_figure`, `average_annual_income`, `refused_account_by_institute`, `high_value_item`, `soi`, `soi_attachment`, `address`, `city1`, `country1`, `zakat`, `zakat_options`, `zakat_certificate`, `created_at`, `updated_at`) VALUES
	(105, 'pk', 'ALI', 'ALI', 'KHKK', '2020-06-04', '45456-4564564-6', 'sr.png', '2020-06-03', 'Karachi', 'pakistan', 'ALI@GMAI.COM', '923542165459', 'Businessman', 'SSADASDS', 'DFXCVVCV', NULL, 'FDSFSFS', '3', '21', 'Graduate', 'Single', '2', 'yes', '500k-1mn', 'DSFSFFSDF', 'SDSS', 'Salary', '2.jpg', 'KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-11 14:54:19', '2020-06-11 14:54:19'),
	(106, 'pk', 'ALI', 'RAZA', 'SEEMA', '2000-01-01', '45102-6543212-7', '1.jpg', '2000-01-01', 'Karachi', 'pakistan', 'ALI@GMAIL.COM', '923441234567', 'Businessman', 'SHOP', 'CEO', NULL, 'SHOP', '5', '5', 'Graduate', 'Single', '5', 'yes', '250-500k', 'no', 'no', 'Self-Owned', '113.jpg', 'KARACHI', 'Karachi', 'pakistan', 'no', 'file', '12.jpg', '2020-06-15 10:53:45', '2020-06-15 10:53:45'),
	(107, 'pk', 'ALI', 'RAZA', 'SEEMA', '2000-01-01', '45102-6543212-7', '1.jpg', '2000-01-01', 'Karachi', 'pakistan', 'ALI@GMAIL.COM', '923441234567', 'Businessman', 'SHOP', 'CEO', NULL, 'SHOP', '5', '5', 'Graduate', 'Single', '5', 'yes', '250-500k', 'no', 'no', 'Self-Owned', '113.jpg', 'KARACHI', 'Karachi', 'pakistan', 'no', 'file', '12.jpg', '2020-06-15 10:53:52', '2020-06-15 10:53:52'),
	(108, 'pk', 'ALI', 'RAZA', 'SEEMA', '2000-01-01', '45102-6543212-7', '1.jpg', '2000-01-01', 'Karachi', 'pakistan', 'ALI@GMAIL.COM', '923441234567', 'Businessman', 'SHOP', 'CEO', NULL, 'SHOP', '5', '5', 'Graduate', 'Single', '5', 'yes', '250-500k', 'no', 'no', 'Self-Owned', '113.jpg', 'KARACHI', 'Karachi', 'pakistan', 'no', 'file', '12.jpg', '2020-06-15 10:54:23', '2020-06-15 10:54:23'),
	(109, 'pk', 'ALI', 'RAZA', 'SEEMA', '2000-01-01', '45102-6543212-7', '1.jpg', '2000-01-01', 'Karachi', 'pakistan', 'ALI@GMAIL.COM', '923441234567', 'Businessman', 'SHOP', 'CEO', NULL, 'SHOP', '5', '5', 'Graduate', 'Single', '5', 'yes', '250-500k', 'no', 'no', 'Self-Owned', '113.jpg', 'KARACHI', 'Karachi', 'pakistan', 'no', 'file', '12.jpg', '2020-06-15 10:54:37', '2020-06-15 10:54:37'),
	(110, 'pk', 'ALI', 'RAZA', 'SEEMA', '2000-01-01', '45102-6543212-7', '1.jpg', '2000-01-01', 'Karachi', 'pakistan', 'ALI@GMAIL.COM', '923441234567', 'Businessman', 'SHOP', 'CEO', NULL, 'SHOP', '5', '5', 'Graduate', 'Single', '5', 'yes', '250-500k', 'no', 'no', 'Self-Owned', '113.jpg', 'KARACHI', 'Karachi', 'pakistan', 'no', 'file', '12.jpg', '2020-06-15 10:54:39', '2020-06-15 10:54:39'),
	(111, 'pk', 'ALI', 'RAZA', 'SEEMA', '2000-01-01', '45102-6543212-7', '1.jpg', '2000-01-01', 'Karachi', 'pakistan', 'ALI@GMAIL.COM', '923441234567', 'Businessman', 'SHOP', 'CEO', NULL, 'SHOP', '5', '5', 'Graduate', 'Single', '5', 'yes', '250-500k', 'no', 'no', 'Self-Owned', '113.jpg', 'KARACHI', 'Karachi', 'pakistan', 'no', 'file', '12.jpg', '2020-06-15 10:54:41', '2020-06-15 10:54:41'),
	(112, 'pk', 'ALI', 'RAZA', 'SEEMA', '2000-01-01', '45102-6543212-7', '1.jpg', '2000-01-01', 'Karachi', 'pakistan', 'ALI@GMAIL.COM', '923441234567', 'Businessman', 'SHOP', 'CEO', NULL, 'SHOP', '5', '5', 'Graduate', 'Single', '5', 'yes', '250-500k', 'no', 'no', 'Self-Owned', '113.jpg', 'KARACHI', 'Karachi', 'pakistan', 'no', 'file', '12.jpg', '2020-06-15 10:54:56', '2020-06-15 10:54:56'),
	(113, 'pk', 'ALI', 'HAMZA', 'HIRA', '1984-06-14', '42201-7586659-9', 'new-year.png', '2018-01-02', 'Lahore', 'pakistan', 'OMAIR.FAROOQ!@HBLASSET.COM', '923223333333', 'Govt. Employee', 'FINANCE', 'OFFICER', 'FINANCE', 'FBR', '10', NULL, 'Graduate', 'Single', '1', 'no', '1-10mn', 'no', 'no', 'Salary', 'Screenshot_20191114-152503_HBL Funds.jpg', 'H.NO 202, 3RD STREET PECHS KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-16 14:23:03', '2020-06-16 14:23:03'),
	(114, 'pk', 'ALI', 'HAMZA', 'HIRA', '1984-06-14', '42201-7586659-9', 'new-year.png', '2018-01-02', 'Lahore', 'pakistan', 'OMAIR.FAROOQ!@HBLASSET.COM', '923223333333', 'Govt. Employee', 'FINANCE', 'OFFICER', 'FINANCE', 'FBR', '10', NULL, 'Graduate', 'Single', '1', 'no', '1-10mn', 'no', 'no', 'Salary', 'Screenshot_20191114-152503_HBL Funds.jpg', 'H.NO 202, 3RD STREET PECHS KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-16 14:23:12', '2020-06-16 14:23:12'),
	(115, 'pk', 'SHAHZAD UL HAQ', 'ABDUL HAQ', 'NASREEN BEGUM', '1978-03-29', '35201-2279690-3', 'shahzad cnic.pdf', '2018-11-18', 'Lahore', 'pakistan', 'SHAHZADUL_HAQ@HOTMAIL.COM', '923004278178', 'Private Service', 'MUTUAL FUNDS', 'AREA MANAGER', 'SALES', 'HBL ASSET MANAGEMENT', '18', NULL, 'Graduate', 'Married', '4', 'no', '1-10mn', 'no', 'no', 'Salary', 'PaySlip_of_00332_for_May 2020.pdf', '176 ASKARI BAZAR CANTT LAHORE', 'Lahore', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-18 14:17:07', '2020-06-18 14:17:07'),
	(116, 'pk', 'SHAHZAD UL HAQ', 'ABDUL HAQ', 'NASREEN BEGUM', '1978-03-29', '35201-2279690-3', 'shahzad cnic.pdf', '2018-11-18', 'Lahore', 'pakistan', 'SHAHZADUL_HAQ@HOTMAIL.COM', '923004278178', 'Private Service', 'MUTUAL FUNDS', 'AREA MANAGER', 'SALES', 'HBL ASSET MANAGEMENT', '18', NULL, 'Graduate', 'Married', '4', 'no', '1-10mn', 'no', 'no', 'Salary', 'PaySlip_of_00332_for_May 2020.pdf', '176 ASKARI BAZAR CANTT LAHORE', 'Lahore', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-18 14:17:12', '2020-06-18 14:17:12'),
	(117, 'pk', 'SHAHZAD UL HAQ', 'ABDUL HAQ', 'NASREEN BEGUM', '1978-03-29', '35201-2279690-3', 'shahzad cnic.pdf', '2018-11-18', 'Lahore', 'pakistan', 'SHAHZADUL_HAQ@HOTMAIL.COM', '923004278178', 'Private Service', 'MUTUAL FUNDS', 'AREA MANAGER', 'SALES', 'HBL ASSET MANAGEMENT', '18', NULL, 'Graduate', 'Married', '4', 'no', '1-10mn', 'no', 'no', 'Salary', 'PaySlip_of_00332_for_May 2020.pdf', '176 ASKARI BAZAR CANTT LAHORE', 'Lahore', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-18 14:17:22', '2020-06-18 14:17:22'),
	(118, 'pk', 'FIAZ AHMED KHAN', 'LIAQAT ALI KHAN', 'HALEEMA', '1983-02-14', '31102-9849483-3', 'CNIC Fiaz 11-Jun-2020 13-41-29.pdf', '2013-11-27', 'Bahawalnagar', 'pakistan', 'FIAZ_KHAN@HOTMAIL.COM', '923333770970', 'Private Service', 'MUTUAL FUNDS', 'AREA MANAGER', 'SALES', 'HBL ASSET MANAGEMENT LTD', '13', NULL, 'Postgraduate', 'Married', '5', 'no', '1-10mn', 'no', 'no', 'Salary', 'Pay Slip Jan-2020.pdf', 'HOUSE # 129-130, STREET # 02, A BLOCK, SHAH RUKNE ALAM COLONY, M ULTAN', 'Bahawalnagar', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-18 14:35:29', '2020-06-18 14:35:29'),
	(119, 'pk', 'SYED ALI RAZA ZAIDI', 'SYED RAZA MEHDI ZAIDI', 'SAIMA ZAIDI', '1985-10-30', '35202-8241131-7', 'CNIC Front.jpg', '2016-09-20', 'Lahore', 'pakistan', 'ALIRAZA.Z@GMAIL.COM', '923452222288', 'Private Service', 'BANKING', 'AREA MANAGER', 'SALES', 'HBL ASSET MANAGEMENT', '10', NULL, 'Graduate', 'Married', '3', 'no', '500k-1mn', 'no', 'no', 'Salary', 'employee card front.jpg', 'UPPER MALL, LAHORE', 'Lahore', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-18 14:54:38', '2020-06-18 14:54:38'),
	(120, 'pk', 'SYED ALI RAZA ZAIDI', 'SYED RAZA MEHDI ZAIDI', 'SAIMA ZAIDI', '1985-10-30', '35202-8241131-7', 'CNIC Front.jpg', '2016-09-20', 'Lahore', 'pakistan', 'ALIRAZA.Z@GMAIL.COM', '923452222288', 'Private Service', 'BANKING', 'AREA MANAGER', 'SALES', 'HBL ASSET MANAGEMENT', '10', NULL, 'Graduate', 'Married', '3', 'no', '500k-1mn', 'no', 'no', 'Salary', 'employee card front.jpg', 'UPPER MALL, LAHORE', 'Lahore', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-18 14:54:45', '2020-06-18 14:54:45'),
	(121, 'pk', 'MUHAMMAD MOAZ QURESHI', 'SHAMSHAD HUSSAIN QURESHI', 'NUZHAT', '1987-08-09', '35202-2100621-5', 'New Doc 2020-03-05 17.09.22.pdf', '2017-04-08', 'Lahore', 'pakistan', 'MOAZQURESHI@HOTMAIL.COM', '923224681071', 'Private Service', 'BANKER', 'AREA MANAGER', 'INVESTMENT ADVISORY', 'HBL ASSET MANAGEMENT', '9', NULL, 'Postgraduate', 'Married', '3', 'no', '1-10mn', 'no', 'no', 'Salary', 'New Doc 2020-03-05 17.09.22.pdf', 'HOUSE NO 110 D1 NESPAK SOCIETY LAHORE', 'Lahore', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-18 15:06:21', '2020-06-18 15:06:21'),
	(122, 'pk', 'MUHAMMAD MOAZ QURESHI', 'SHAMSHAD HUSSAIN QURESHI', 'NUZHAT', '1987-08-09', '35202-2100621-5', 'New Doc 2020-03-05 17.09.22.pdf', '2017-04-08', 'Lahore', 'pakistan', 'MOAZQURESHI@HOTMAIL.COM', '923224681071', 'Private Service', 'BANKER', 'AREA MANAGER', 'INVESTMENT ADVISORY', 'HBL ASSET MANAGEMENT', '9', NULL, 'Postgraduate', 'Married', '3', 'no', '1-10mn', 'no', 'no', 'Salary', 'New Doc 2020-03-05 17.09.22.pdf', 'HOUSE NO 110 D1 NESPAK SOCIETY LAHORE', 'Lahore', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-18 15:06:28', '2020-06-18 15:06:28'),
	(123, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:30:19', '2020-06-19 13:30:19'),
	(124, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:30:33', '2020-06-19 13:30:33'),
	(125, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:30:34', '2020-06-19 13:30:34'),
	(126, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:30:43', '2020-06-19 13:30:43'),
	(127, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:30:43', '2020-06-19 13:30:43'),
	(128, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:30:46', '2020-06-19 13:30:46'),
	(129, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:31:05', '2020-06-19 13:31:05'),
	(130, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:31:11', '2020-06-19 13:31:11'),
	(131, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:31:12', '2020-06-19 13:31:12'),
	(132, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:31:20', '2020-06-19 13:31:20'),
	(133, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:31:22', '2020-06-19 13:31:22'),
	(134, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:31:24', '2020-06-19 13:31:24'),
	(135, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:31:39', '2020-06-19 13:31:39'),
	(136, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:31:49', '2020-06-19 13:31:49'),
	(137, 'pk', 'SANDEEP KUMAR RAJPAL', 'SATIYAPAL RAJPALK', 'INDRA RAJPAL', '1985-04-09', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-02-18', 'Sukkur', 'pakistan', 'SANDEEP@HOTMAIL.COM', '923343645879', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '500k-1mn', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5 KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:31:51', '2020-06-19 13:31:51'),
	(138, 'pk', 'SANDEEP KUMAR RAJPAL', 'RAJPAL', 'INDRA RAJPAL', '2020-06-19', '42201-9943958-7', 'IMG_20200619_131821184.jpg', '2020-06-01', 'Karachi', 'pakistan', 'SANDEEP@HOTMAIL', '923349875412', 'Private Service', 'BANKER', 'MANAGER', 'RETAIL', 'JS BANK LTD', '5', NULL, 'Postgraduate', 'Married', '2', 'no', '250-500k', 'no', 'no', 'Salary', 'IMG_20200619_132421235.jpg', 'CLIFTON BLOCK 5', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:35:12', '2020-06-19 13:35:12'),
	(139, 'pk', 'WAQAR', 'MUHAMMAD YOUNUS', 'ZUBAIDA KATOON', '2020-06-19', '42000-6445781-7', 'IMG_20200619_131821184.jpg', '2020-01-01', 'Lahore', 'pakistan', 'WAQAR_@HOTMAIL.COM', '923349874519', 'Retired', NULL, NULL, NULL, NULL, '40', NULL, 'Postgraduate', 'Married', '5', 'no', '1-10mn', 'no', 'no', 'Inheritance', 'IMG-20200506-WA0024.jpg', '45/2 ,2ND STREET DHA LAHORE', 'Lahore', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-19 13:50:16', '2020-06-19 13:50:16'),
	(140, 'pk', 'ZIA JAVED', 'JAVED ALI KHAN', 'NUZHAT', '1977-10-03', '42301-1092155-3', 'Realme_Logo_-522ebd8e-3349-434d-851c-bad0ba7a2846.jpg', '2016-02-11', 'Karachi', 'pakistan', 'ZIAJAVED@GMAIL.COM', '923212000205', 'Private Service', 'ASSET MANAGEMENT', 'WEALTH MANAGER', 'SALES', 'HBL ASSET MANAGEMENT LTD', '22', NULL, 'Postgraduate', 'Married', '2', 'no', '1-10mn', 'no', 'no', 'Salary', 'Mescla-2094806e-1e71-4033-9d6a-fa2dc93f6092.jpg', '9, 4TH STREET, OFF KHAYABAN-E-MUHAFIZ, PHASE 6, DHA', 'Karachi', 'pakistan', 'no', 'courier', 'no_image.png', '2020-06-19 14:31:50', '2020-06-19 14:31:50'),
	(141, 'pk', 'ZIA JAVED', 'JAVED ALI KHAN', 'NUZHAT', '1977-10-03', '42301-1092155-3', 'Realme_Logo_-522ebd8e-3349-434d-851c-bad0ba7a2846.jpg', '2016-02-11', 'Karachi', 'pakistan', 'ZIAJAVED@GMAIL.COM', '923212000205', 'Private Service', 'ASSET MANAGEMENT', 'WEALTH MANAGER', 'SALES', 'HBL ASSET MANAGEMENT LTD', '22', NULL, 'Postgraduate', 'Married', '2', 'no', '1-10mn', 'no', 'no', 'Salary', 'Mescla-2094806e-1e71-4033-9d6a-fa2dc93f6092.jpg', '9, 4TH STREET, OFF KHAYABAN-E-MUHAFIZ, PHASE 6, DHA', 'Karachi', 'pakistan', 'no', 'courier', 'no_image.png', '2020-06-19 14:31:59', '2020-06-19 14:31:59'),
	(142, 'pk', 'RIZWAN SYED', 'SYED SAMIUD DIN', 'FARIDA SYED', '1976-08-07', '61101-6131642-9', 'IMG-20200619-WA0017.jpg', '1976-11-21', 'Karachi', 'pakistan', 'RIZWAN.SYED@HBLASSET.COM', '923008262640', 'Retired', NULL, NULL, NULL, NULL, '50', NULL, 'Postgraduate', 'Married', '8', 'no', '10mn-100mn', 'no', 'no', 'Self-Owned', 'IMG-20200619-WA0017.jpg', 'H 108 KH RIZWAN DHA PHSE 7', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-19 14:38:52', '2020-06-19 14:38:52'),
	(143, 'pk', 'RIZWAN SYED', 'SYED SAMIUD DIN', 'FARIDA SYED', '1976-08-07', '61101-6131642-9', 'IMG-20200619-WA0017.jpg', '1976-11-21', 'Karachi', 'pakistan', 'RIZWAN.SYED@HBLASSET.COM', '923008262640', 'Retired', NULL, NULL, NULL, NULL, '50', NULL, 'Postgraduate', 'Married', '8', 'no', '10mn-100mn', 'no', 'no', 'Self-Owned', 'IMG-20200619-WA0017.jpg', 'H 108 KH RIZWAN DHA PHSE 7', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-19 14:38:56', '2020-06-19 14:38:56'),
	(144, 'pk', 'RIZWAN SYED', 'SYED SAMIUD DIN', 'FARIDA SYED', '1976-08-07', '61101-6131642-9', 'IMG-20200619-WA0017.jpg', '1976-11-21', 'Karachi', 'pakistan', 'RIZWAN.SYED@HBLASSET.COM', '923008262640', 'Retired', NULL, NULL, NULL, NULL, '50', NULL, 'Postgraduate', 'Married', '8', 'no', '10mn-100mn', 'no', 'no', 'Self-Owned', 'IMG-20200619-WA0017.jpg', 'H 108 KH RIZWAN DHA PHSE 7', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-19 14:39:07', '2020-06-19 14:39:07'),
	(145, 'us', 'LUBNA AHMED', 'KHAWJA SHAHAB AHMED', 'ANADIL', '1981-10-25', '42301-3693448-4', 'ID CARD.jpg', '2020-06-20', 'Karachi', 'pakistan', 'LUBNA.AHMED@HBLASSET.COM', '923458777637', 'Private Service', 'FINANCIAL SERVICES', 'BUSINESS HEAD SOUTH', 'SALES', 'HBL ASSET MANAGEMENT LTD', '14', NULL, 'Postgraduate', 'Married', '1', 'no', 'Less than 250k', 'no', 'no', 'Salary', 'ID CARD.jpg', '180 B SHABBIRABAD', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-20 23:05:51', '2020-06-20 23:05:51'),
	(146, 'pk', 'YOUSUF KERAI', 'SHAHEEN KERAI', 'NAZNEEN', '2020-03-11', '42000-0512403-7', 'ID CARD.jpg', '2020-06-18', 'Karachi', 'pakistan', 'YKERAI@GMAIL.COM', '923008267518', 'Private Service', 'TEACHER', 'LECTURER', 'MATHEMATICS', 'HABIB UNIVERSITY', '21', NULL, 'Undergraduate', 'Married', '1', 'no', 'Less than 250k', 'no', 'no', 'Salary', 'ID CARD.jpg', '180 B SHABBIRABAD, SYEDNA TAYYEB RD, KARACHI 75350', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-20 23:13:12', '2020-06-20 23:13:12'),
	(147, 'pk', 'FAISAL SHABBIR', 'GHULAM SHABBIR', 'NASREEN', '1989-12-10', '36302-7079502-7', 'IMG_20200622_102948.jpg', '2014-03-15', 'Multan', 'pakistan', 'FSL.AIRBASE@GMAIL.COM', '923437140170', 'Private Service', 'SALES JOB', 'INVESTMENT ADVISOR', 'SALES', 'HBL ASSET MANAGEMENT LTD', '2', NULL, 'Graduate', 'Single', '0', 'no', '250-500k', 'no', 'no', 'Salary', 'IMG_20200622_103019.jpg', 'HOUSE # 708/6 , MADINA HOSPITAL STREET SABZAZAR COLONY BOSAN ROAD MULTAN', 'Multan', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 10:35:44', '2020-06-22 10:35:44'),
	(148, 'pk', 'FAISAL SHABBIR', 'GHULAM SHABBIR', 'NASREEN', '1989-12-10', '36302-7079502-7', 'IMG_20200622_102948.jpg', '2014-03-15', 'Multan', 'pakistan', 'FSL.AIRBASE@GMAIL.COM', '923437140170', 'Private Service', 'SALES JOB', 'INVESTMENT ADVISOR', 'SALES', 'HBL ASSET MANAGEMENT LTD', '2', NULL, 'Graduate', 'Single', '0', 'no', '250-500k', 'no', 'no', 'Salary', 'IMG_20200622_103019.jpg', 'HOUSE # 708/6 , MADINA HOSPITAL STREET SABZAZAR COLONY BOSAN ROAD MULTAN', 'Multan', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 10:35:52', '2020-06-22 10:35:52'),
	(149, 'pk', 'FAISAL SHABBIR', 'GHULAM SHABBIR', 'NASREEN', '1989-12-10', '36302-7079502-7', 'IMG_20200622_102948.jpg', '2014-03-15', 'Multan', 'pakistan', 'FSL.AIRBASE@GMAIL.COM', '923437140170', 'Private Service', 'SALES JOB', 'INVESTMENT ADVISOR', 'SALES', 'HBL ASSET MANAGEMENT LTD', '2', NULL, 'Graduate', 'Single', '0', 'no', '250-500k', 'no', 'no', 'Salary', 'IMG_20200622_103019.jpg', 'HOUSE # 708/6 , MADINA HOSPITAL STREET SABZAZAR COLONY BOSAN ROAD MULTAN', 'Multan', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 10:35:54', '2020-06-22 10:35:54'),
	(150, 'pk', 'TESTING', 'TESTING', 'TESTING', '2020-06-01', '12313-1313131-3', '7684f482-7f64-4b0e-99a2-afc001ac4b8e.jpg', '2020-06-22', 'Karachi', 'pakistan', 'SHAHEEDKHAN336@GMAIL.COM', '923412427229', 'Private Service', 'TESTING', 'TESTING', 'TESTING', 'TESTING', '3', NULL, 'Undergraduate', 'Single', '1', 'yes', '250-500k', 'no', 'no', 'Inheritance', '7684f482-7f64-4b0e-99a2-afc001ac4b8e.jpg', 'TESTING', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 12:20:07', '2020-06-22 12:20:07'),
	(151, 'pk', 'TESTING', 'TESTING', 'TESTING', '1993-01-01', '11111-111111111', '7684f482-7f64-4b0e-99a2-afc001ac4b8e.jpg', '2020-06-11', 'Karachi', 'pakistan', 'SHAHEEDKHAN336@GAMIL.COM', '923412427229', 'Student', NULL, NULL, NULL, NULL, NULL, NULL, 'Professional', 'Single', '3', 'no', '500k-1mn', 'no', 'no', 'Self-Owned', '7684f482-7f64-4b0e-99a2-afc001ac4b8e.jpg', 'TESTING', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 12:24:35', '2020-06-22 12:24:35'),
	(152, 'pk', 'TESTING', 'TESTING', 'TESTING', '1993-01-01', '11111-111111111', '7684f482-7f64-4b0e-99a2-afc001ac4b8e.jpg', '2020-06-11', 'Karachi', 'pakistan', 'SHAHEEDKHAN336@GAMIL.COM', '923412427229', 'Student', NULL, NULL, NULL, NULL, NULL, NULL, 'Professional', 'Single', '3', 'no', '500k-1mn', 'no', 'no', 'Self-Owned', '7684f482-7f64-4b0e-99a2-afc001ac4b8e.jpg', 'TESTING', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 12:24:40', '2020-06-22 12:24:40'),
	(153, 'pk', 'TEST', 'TEST', 'TEST', '2018-12-27', '12234-4444455-5', 'IMG_20200622_123019.jpg', '2020-06-16', 'Karachi', 'pakistan', 'SHAHEEDKHAN336@GMAGMAIL.COM', '923412127229', 'Businessman', 'TEST', 'TEST', NULL, 'TEST', '1', '1', 'Postgraduate', 'Single', '1', 'no', '10mn-100mn', 'no', 'no', 'Salary', '159281100998671323012.jpg', 'TEST', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 12:31:40', '2020-06-22 12:31:40'),
	(154, 'pk', 'TEST', 'TEST', 'TEST', '1996-01-01', '12567-788888--$', 'IMG_20200622_123019.jpg', '2020-06-17', 'Karachi', 'pakistan', 'SHAHEEDKHAN336@GMAIL.COM', '923412427229', 'Businessman', 'TEST', 'TEST', NULL, 'TEST', '12', '12', 'Graduate', 'Single', '12', 'no', '1-10mn', 'TEST', 'no', 'Stock/Investment', 'IMG_20200622_123019.jpg', 'TEST', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 12:38:46', '2020-06-22 12:38:46'),
	(155, 'pk', 'TEST', 'TEST', 'TEST', '1996-01-01', '12567-788888--$', 'IMG_20200622_123019.jpg', '2020-06-17', 'Karachi', 'pakistan', 'SHAHEEDKHAN336@GMAIL.COM', '923412427229', 'Businessman', 'TEST', 'TEST', NULL, 'TEST', '12', '12', 'Graduate', 'Single', '12', 'no', '1-10mn', 'TEST', 'no', 'Stock/Investment', 'IMG_20200622_123019.jpg', 'TEST', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 12:39:05', '2020-06-22 12:39:05'),
	(156, 'pk', 'TESTING', 'TESTING', 'TESTING', '2019-01-01', '12334-1233456-1', '1592812252351160402447.jpg', '2020-06-03', 'Karachi', 'pakistan', 'SHAHEEDKHA336@GMAL.COM', '921234566789', 'Govt. Employee', 'TESTING', 'TESTING', 'TESTING', 'TESTING', '22', NULL, 'Postgraduate', 'Single', '12', 'no', '500k-1mn', 'TESTING', 'no', 'Self-Owned', 'Screenshot_2018-05-16-16-50-58.png', 'TESTING', 'Karachi', 'pakistan', 'no', 'file', 'no_image.png', '2020-06-22 12:55:37', '2020-06-22 12:55:37'),
	(157, 'pk', 'TESTING', 'TESTING', 'TESTING', '1996-01-01', '12345-1234556-1', 'Screenshot_2019-02-22-16-34-09.png', '2020-06-04', 'Karachi', 'pakistan', 'SHAHEEDKHAN@GMAL.COM', '921234567890', 'Private Service', 'TEST', 'TEST', 'TEST', 'TEST', '2', NULL, 'Postgraduate', 'Single', '2', 'yes', 'Less than 250k', 'TESTING', 'TESTING', 'TEST', 'Screenshot_2018-05-16-16-50-58.png', 'TESTING', 'Karachi', 'pakistan', 'no', 'file', 'Screenshot_2018-05-16-16-50-58.png', '2020-06-22 13:05:33', '2020-06-22 13:05:33'),
	(158, 'pk', 'TESTING', 'TESTING', 'TESTING', '1996-01-01', '12345-1234556-1', 'Screenshot_2019-02-22-16-34-09.png', '2020-06-04', 'Karachi', 'pakistan', 'SHAHEEDKHAN@GMAL.COM', '921234567890', 'Private Service', 'TEST', 'TEST', 'TEST', 'TEST', '2', NULL, 'Postgraduate', 'Single', '2', 'yes', 'Less than 250k', 'TESTING', 'TESTING', 'TEST', 'Screenshot_2018-05-16-16-50-58.png', 'TESTING', 'Karachi', 'pakistan', 'no', 'file', 'Screenshot_2018-05-16-16-50-58.png', '2020-06-22 13:06:08', '2020-06-22 13:06:08'),
	(159, 'us', 'TESTING', 'TESTING', 'TESTING', '1994-02-01', '12345-6789012-2', 'Screenshot_2018-05-16-16-50-58.png', '2020-06-03', 'Karachi', 'pakistan', 'SHAHEEDKHAN336@GAMAIL.COM', '921212212121', 'Businessman', 'TESTING', 'TESTING', NULL, 'TESTING', '2', '2', 'Graduate', 'Single', '2', 'no', 'Above 100mn', 'no', 'no', 'Self-Owned', 'Screenshot_2018-05-16-16-50-58.png', 'TESTING', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 13:11:27', '2020-06-22 13:11:27'),
	(160, 'pk', 'TESTING', 'TESTING', 'TESTING', '1996-02-01', '55555-5555555-5', 'Screenshot_2018-05-16-16-50-58.png', '1995-12-29', 'ER5666', 'us', 'SHAHEEDKHA336@GMAIL.COM', '+11233252363', 'Retired', NULL, NULL, NULL, NULL, '2', NULL, 'Postgraduate', 'Married', '2', 'no', '10mn-100mn', 'TESTING', 'TESTING', 'Home Remittance', 'Screenshot_2018-05-16-16-50-58.png', 'TESTING', 'TESTING', 'us', 'yes', NULL, 'no_image.png', '2020-06-22 13:18:12', '2020-06-22 13:18:12'),
	(161, 'pk', 'MUHAMMAD UMER', 'MUHAMMAD KHALID KHAN', 'SHAJAR KHALID', '1992-08-25', '42101-7879754-9', 'zakat form ss.JPG', '2020-06-22', 'Karachi', 'pakistan', 'MUHAMMAD.UMER@HBLASSET.COM', '923433486605', 'Private Service', 'ASSET MANAGEMENT LTD', 'RM', 'RETAIL SALES', 'HBL AML', '5', NULL, 'Postgraduate', 'Married', '0', 'yes', '250-500k', 'no', 'no', 'Salary', 'zakat form ss.JPG', 'HOUSE ETCETCECT', 'Karachi', 'pakistan', 'no', 'file', 'zakat form ss.JPG', '2020-06-22 15:30:55', '2020-06-22 15:30:55'),
	(162, 'pk', 'MUHAMMAD UMER', 'MUHAMMAD KHALID KHAN', 'SHAJAR KHALID', '1992-08-25', '42101-7879754-9', 'zakat form ss.JPG', '2020-06-22', 'Karachi', 'pakistan', 'MUHAMMAD.UMER@HBLASSET.COM', '923433486605', 'Private Service', 'ASSET MANAGEMENT LTD', 'RM', 'RETAIL SALES', 'HBL AML', '5', NULL, 'Postgraduate', 'Married', '0', 'yes', '250-500k', 'no', 'no', 'Salary', 'zakat form ss.JPG', 'HOUSE ETCETCECT', 'Karachi', 'pakistan', 'no', 'file', 'zakat form ss.JPG', '2020-06-22 15:30:58', '2020-06-22 15:30:58'),
	(163, 'pk', 'MUHAMMAD UMER', 'MUHAMMAD KHALID KHAN', 'SHAJAR KHALID', '1992-08-25', '42101-7879754-9', 'zakat form ss.JPG', '2020-06-22', 'Karachi', 'pakistan', 'MUHAMMAD.UMER@HBLASSET.COM', '923433486605', 'Private Service', 'ASSET MANAGEMENT LTD', 'RM', 'RETAIL SALES', 'HBL AML', '5', NULL, 'Postgraduate', 'Married', '0', 'yes', '250-500k', 'no', 'no', 'Salary', 'zakat form ss.JPG', 'HOUSE ETCETCECT', 'Karachi', 'pakistan', 'no', 'file', 'zakat form ss.JPG', '2020-06-22 15:31:02', '2020-06-22 15:31:02'),
	(164, 'pk', 'SYED MUHAMMAD IMRAN', 'QAMARUDDIN AHMED', 'NIGHAT', '1979-10-17', '42101-2117254-1', 'IMG-20200620-WA0054.jpg', '2018-04-12', 'Karachi', 'pakistan', 'IMRAN30507@GMAIL.COM', '923222339690', 'Private Service', 'FINANCIAL SERVICE', 'CFO', 'FINANCE', 'MCB FINANCIAL SERVICES LTD', '19', NULL, 'Postgraduate', 'Married', '4', 'no', '1-10mn', 'no', 'no', 'Salary', 'IMG-20200622-WA0049.jpg', 'HOUSE NO.B4, SBCHS, BLOCK-12, GULISTAN-E-JOUHAR, KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-22 15:34:41', '2020-06-22 15:34:41'),
	(165, 'pk', '123456', 'SHAHA12263747', 'AHMED', '2020-06-17', '42301-3693448-4', 'ID CARD.jpg', '2020-06-09', 'Karachi', 'pakistan', 'LUBNA.S.AHMED@GMAIL.COM', '923458777637', 'Private Service', 'FINANCIAL SERVICES', 'BUSINESS HEAD SOUTH', 'SALES', 'HBL ASSET', '9', NULL, 'Postgraduate', 'Married', '2', 'no', '250-500k', 'no', 'no', 'Salary', 'ID CARD.jpg', '180 B SHABBIRABAD', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-22 16:59:55', '2020-06-22 16:59:55'),
	(166, 'us', 'LUBNA AHMED', 'LUBNA AHMED', 'LUBNA AHMED', '2020-06-03', '42301-3693448-4', 'ID CARD.jpg', '2020-06-09', 'Karachi', 'pakistan', 'LUBNA.S.AHMED@GMAIL.COM', '923458777637', 'Private Service', '1233MMFFKKF', 'HOS', 'SALES', 'HBL', '10', NULL, 'Graduate', 'Single', '0', 'no', 'Less than 250k', 'no', 'no', 'Salary', 'ID CARD.jpg', 'JSKJASKJS19018282281', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-22 18:10:19', '2020-06-22 18:10:19'),
	(167, 'pk', 'LUBNA', 'SHAHAB', 'ANADIL', '2020-06-10', '42301-3693448-4', 'ID CARD.jpg', '2020-06-18', 'Karachi', 'pakistan', 'LUBNA.AHMED@GMAIL.COM', '923458777637', 'Private Service', 'FINANCIAL SERVICES', 'HOS', 'SALES', 'HBL ASSET', '14', NULL, 'Postgraduate', 'Married', '1', 'no', '250-500k', 'no', 'no', 'Salary', 'ID CARD.jpg', '180 B SHABBIRABAD', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-22 18:29:25', '2020-06-22 18:29:25'),
	(168, 'pk', 'LUBNA', 'SHAHHA', 'ANADIL', '2020-06-02', '42301-3693448-4', 'ID CARD.jpg', '2020-06-09', 'Karachi', 'pakistan', 'LUBNA.AHMED@HBLASSET.COM', '923458777637', 'Private Service', 'SALES', 'HOS', 'SALES', 'HBL', '10', NULL, 'Postgraduate', 'Single', '1', 'no', 'Less than 250k', 'no', 'no', 'Salary', 'ID CARD.jpg', '180 B', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-22 18:42:54', '2020-06-22 18:42:54'),
	(169, 'pk', 'ALY KHAN', 'AZHAR TARIQ', 'FARZANA ANIS', '1982-03-20', '42201-8043104-9', 'download.png', '2010-09-08', 'Karachi', 'pakistan', 'MOHAMMADALYK@GMAIL.COM', '923008213173', 'Private Service', 'ASSET MANAGEMENT', 'HEAD OF MARKETING', 'MARKETING', 'HBL ASSET MANAGEMENT', '10', NULL, 'Postgraduate', 'Single', '2', 'yes', '500k-1mn', 'no', 'no', 'Salary', 'download.png', 'APT 8, 4TH FLOOR, KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-23 10:11:18', '2020-06-23 10:11:18'),
	(170, 'pk', 'ALY KHAN', 'AZHAR TARIQ', 'FARZANA ANIS', '1982-03-20', '42201-8043104-9', 'download.png', '2010-09-08', 'Karachi', 'pakistan', 'MOHAMMADALYK@GMAIL.COM', '923008213173', 'Private Service', 'ASSET MANAGEMENT', 'HEAD OF MARKETING', 'MARKETING', 'HBL ASSET MANAGEMENT', '10', NULL, 'Postgraduate', 'Single', '2', 'yes', '500k-1mn', 'no', 'no', 'Salary', 'download.png', 'APT 8, 4TH FLOOR, KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-23 10:11:23', '2020-06-23 10:11:23'),
	(171, 'pk', 'ALY KHAN', 'AZHAR TARIQ', 'FARZANA ANIS', '1982-03-20', '42201-8043104-9', 'download.png', '2010-09-08', 'Karachi', 'pakistan', 'MOHAMMADALYK@GMAIL.COM', '923008213173', 'Private Service', 'ASSET MANAGEMENT', 'HEAD OF MARKETING', 'MARKETING', 'HBL ASSET MANAGEMENT', '10', NULL, 'Postgraduate', 'Single', '2', 'yes', '500k-1mn', 'no', 'no', 'Salary', 'download.png', 'APT 8, 4TH FLOOR, KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-23 10:11:28', '2020-06-23 10:11:28'),
	(172, 'pk', 'ALI', 'HAMZA', 'HIRA', '1990-02-02', '45454-5454545-4', 'Captcha Error.jpg', '2020-06-02', 'Karachi', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '923232323232', 'Private Service', 'PRIVATE', 'OFFICER', 'AUDIT', 'ABC PVT LTD', '10', NULL, 'Postgraduate', 'Married', '10', 'no', '1-10mn', 'no', 'no', 'Salary', 'Captcha Error.jpg', '7TH FLOOR EMERALD TOWER DO TALWAR CLIFTON KARACHI', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-23 10:44:46', '2020-06-23 10:44:46'),
	(173, 'pk', 'ALI', 'HAMZA', 'HIRA', '1990-02-02', '45454-5454545-4', 'Captcha Error.jpg', '2020-06-02', 'Karachi', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '923232323232', 'Private Service', 'PRIVATE', 'OFFICER', 'AUDIT', 'ABC PVT LTD', '10', NULL, 'Postgraduate', 'Married', '10', 'no', '1-10mn', 'no', 'no', 'Salary', 'Captcha Error.jpg', '7TH FLOOR EMERALD TOWER DO TALWAR CLIFTON KARACHI', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-23 10:44:51', '2020-06-23 10:44:51'),
	(174, 'pk', 'LUBNA', 'SHAHAB', 'ANADIL', '1981-10-25', '42301-3693448-4', 'ID CARD.jpg', '2020-06-23', 'Karachi', 'pakistan', 'LUBNA.AHMED@HBLASSET.COM', '923458777637', 'Private Service', 'FINANCIAL SERVICES', 'HOS', 'SALES', 'HBL', '14', NULL, 'Postgraduate', 'Married', '1', 'no', 'Less than 250k', 'no', 'no', 'Salary', 'ID CARD.jpg', '180 B KARACHI', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-23 12:51:03', '2020-06-23 12:51:03'),
	(175, 'pk', 'LUBNA', 'SHAHAB', 'ANADIL', '1981-10-25', '42301-3693448-4', 'ID CARD.jpg', '2020-06-23', 'Karachi', 'pakistan', 'LUBNA.AHMED@HBLASSET.COM', '923458777637', 'Private Service', 'FINANCIAL SERVICES', 'HOS', 'SALES', 'HBL', '14', NULL, 'Postgraduate', 'Married', '1', 'no', 'Less than 250k', 'no', 'no', 'Salary', 'ID CARD.jpg', '180 B KARACHI', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-23 12:51:07', '2020-06-23 12:51:07'),
	(176, 'us', 'LUBNA', 'SHAHAB', 'ANADIL', '1981-10-25', '42301-3693448-4', 'ID CARD.jpg', '2020-06-02', 'NEW YORK', 'us', 'LUBNA.S.AHMED@GMAIL.COM', '+13458777637', 'Private Service', 'FINANCIAL SERVICES', 'HOS', 'SALES', 'HBL', '14', NULL, 'Postgraduate', 'Married', '1', 'no', 'Less than 250k', 'no', 'no', 'Salary', 'ID CARD.jpg', '180 B', 'NEW YORK', 'us', 'no', 'email', 'no_image.png', '2020-06-23 12:59:50', '2020-06-23 12:59:50'),
	(177, 'pk', 'PERRY MASON', 'MANSON BATE', 'ROSE LOBO', '2015-02-04', '42301-4444444-4', 'DSC_7839 - Edited.jpg', '2020-06-03', 'Karachi', 'pakistan', 'TEST@GMAIL.COM', '923210000000', 'Private Service', 'PRIVATE', 'PRIVATE', 'PRODUCT', 'PRIVATE', '20', NULL, 'Graduate', 'Married', '0', 'no', '250-500k', 'no', 'no', 'Salary', 'DSC_7841 - Edited.jpg', 'TEST', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-23 15:23:30', '2020-06-23 15:23:30'),
	(178, 'pk', 'NOMAN', 'ALI', 'MAYA', '1993-05-05', '56565-6565656-5', 'Updated Tax Post.jpg', '2020-06-10', 'Karachi', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '923232323232', 'Private Service', 'CONSTRUCTION', 'ACCOUNTANT', 'FINANCE', 'ABC PVT LTD', '7', NULL, 'Graduate', 'Single', '0', 'no', '1-10mn', 'no', 'no', 'Salary', 'Tax Table Final.jpg', 'H. NO 212 STREET 2 PECHS KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-24 12:44:15', '2020-06-24 12:44:15'),
	(179, 'pk', 'NOMAN', 'ALI', 'MAYA', '1993-05-05', '56565-6565656-5', 'Updated Tax Post.jpg', '2020-06-10', 'Karachi', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '923232323232', 'Private Service', 'CONSTRUCTION', 'ACCOUNTANT', 'FINANCE', 'ABC PVT LTD', '7', NULL, 'Graduate', 'Single', '0', 'no', '1-10mn', 'no', 'no', 'Salary', 'Tax Table Final.jpg', 'H. NO 212 STREET 2 PECHS KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-24 12:44:18', '2020-06-24 12:44:18'),
	(180, 'pk', 'HAMMAD', 'FAISAL', 'ALIYA', '2003-09-26', '87944-6210003-5', 'Updated Tax Post.jpg', '2017-05-22', 'Lahore', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '923223252549', 'Student', NULL, NULL, NULL, NULL, NULL, NULL, 'Undergraduate', 'Single', '0', 'no', 'Less than 250k', 'no', 'no', 'Self-Owned', 'Updated Tax Post.jpg', 'FLAT NO 1/2 BLOCK C, GULSHAN E IQBAL KARACHI', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-24 12:49:06', '2020-06-24 12:49:06'),
	(181, 'pk', 'SAEEM KHAN', 'NOOR BAD SHAH', 'MASHAL BIBI', '1991-01-18', '14102-0374908-9', 'CNIC.pdf', '2015-06-15', 'Hangu', 'pakistan', 'SAEEM2012@GMAIL.COM', '923469252636', 'Private Service', 'FINANCIAL SERVICES', 'SR. INVESTMENT ADVISOR', 'RETAIL SALES NORTH', 'HBL ASSET  MANAGEMENT', '3', NULL, 'Postgraduate', 'Single', '0', 'no', '500k-1mn', 'no', 'no', 'Salary', 'MiHCM.pdf', 'ISLAMABAD', 'Islamabad', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-25 15:28:19', '2020-06-25 15:28:19'),
	(182, 'pk', 'SAEEM KHAN', 'NOOR BAD SHAH', 'MASHAL BIBI', '1991-01-18', '14102-0374908-9', 'CNIC.pdf', '2015-06-15', 'Hangu', 'pakistan', 'SAEEM2012@GMAIL.COM', '923469252636', 'Private Service', 'FINANCIAL SERVICES', 'SR. INVESTMENT ADVISOR', 'RETAIL SALES NORTH', 'HBL ASSET  MANAGEMENT', '3', NULL, 'Postgraduate', 'Single', '0', 'no', '500k-1mn', 'no', 'no', 'Salary', 'MiHCM.pdf', 'ISLAMABAD', 'Islamabad', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-25 15:28:26', '2020-06-25 15:28:26'),
	(183, 'pk', 'SAEEM KHAN', 'NOOR BAD SHAH', 'MASHAL BIBI', '1991-01-18', '14102-0374908-9', 'CNIC.pdf', '2015-06-16', 'Hangu', 'pakistan', 'SAEEM2012@GMAIL.COM', '923469252636', 'Private Service', 'FINANCIAL SERVICES', 'SR. INVESTMENT ADVISOR', 'RETAIL SALES NORTH', 'HBL ASSET MANAGEMENT', '3', NULL, 'Postgraduate', 'Single', '0', 'no', '500k-1mn', 'no', 'no', 'Salary', 'MiHCM.pdf', 'ISLAMABAD', 'Islamabad', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-25 15:35:48', '2020-06-25 15:35:48'),
	(184, 'pk', 'SAEEM KHAN', 'NOOR BAD SHAH', 'MASHAL BIBI', '1991-01-18', '14102-0374908-9', 'CNIC.pdf', '2015-06-16', 'Hangu', 'pakistan', 'SAEEM2012@GMAIL.COM', '923469252636', 'Private Service', 'FINANCIAL SERVICES', 'SR. INVESTMENT ADVISOR', 'RETAIL SALES NORTH', 'HBL ASSET MANAGEMENT', '3', NULL, 'Postgraduate', 'Single', '0', 'no', '500k-1mn', 'no', 'no', 'Salary', 'MiHCM.pdf', 'ISLAMABAD', 'Islamabad', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-25 15:35:55', '2020-06-25 15:35:55'),
	(185, 'pk', 'MUHAMMAD DAWOOD KHOKHAR', 'KHALID PERVAIZ KHOKHAR', 'FOUZIA ASAD', '1980-05-11', '61101-4344224-5', 'DK-CNIC.jpg', '2015-09-07', 'CINCINNATI', 'us', 'MAGNUMOPUS80@YAHOO.COM', '+13005077430', 'Private Service', 'BANKING', 'CEO', 'ALL DEPARTMENTS', 'AL MEEZAN INVESTMENT MANAGEMENT', '12', NULL, 'Postgraduate', 'Married', '03', 'no', '10mn-100mn', 'no', 'no', 'Salary', 'images.jpg', 'HOUSE NO 786, SACHET CLINIC ROAD, BANIGALA, ISLAMABAD', 'Islamabad', 'pakistan', 'no', 'email', 'no_image.png', '2020-06-25 15:50:31', '2020-06-25 15:50:31'),
	(186, 'pk', 'USMAN BIN LADIN', 'KAMRAM BIN LADIN', 'SABAH BINT SAUD', '2000-12-25', '61101-4144224-7', '1eb7f877ad3c7690e5f646e36814ad99.jpg', '2013-08-13', 'JEDDAH', 'SAUDIA ARABIA', 'UBL@YAHOO.COM', '3370600600', 'Businessman', 'PROPRIETORSHIP', 'MANAGING PARTNER', NULL, 'GUL KHAN SHOE MAKERS', '10', '40', 'Professional', 'Single', '14', 'no', '1-10mn', 'no', 'no', 'Inheritance', 'images.jpg', 'HOUSE NO 21, STREET NO 12, SECTOR B-17', 'Islamabad', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-25 16:06:07', '2020-06-25 16:06:07'),
	(187, 'pk', 'KATRINA', 'SHAKOOR', 'KAREENA GHAFOOR', '2003-05-10', '61101-4244224-2', '1eb7f877ad3c7690e5f646e36814ad99.jpg', '2020-05-01', 'JOHANNESBURG', 'SOUTH AFRICA', 'ANGEL_17@YAHOO.COM', '3155000509', 'Private Service', 'BANKING', 'RECEPTIONIST', 'ADMIN', 'BANK OF KHYBER', '01', NULL, 'Graduate', 'Single', '0', 'no', '250-500k', 'no', 'no', 'Salary', '3a481311626a3ade25060327c9724d18.jpg', 'HOUSE NO 09, STREET NO 06, SECTOR: F-7/1', 'Islamabad', 'pakistan', 'yes', NULL, 'no_image.png', '2020-06-25 16:17:18', '2020-06-25 16:17:18'),
	(188, 'pk', 'MUZAFFAR KHAN AFRIDI', 'MUDASSIR KHAN', 'ZAINA', '1987-01-04', '14301-6152504-7', 'cbee770e-442b-4233-90cd-9bc2add7d125.JPG', '2019-05-30', 'Kohat', 'pakistan', 'AFRIDI.MUZAFFAR@GMAIL.COM', '923345307787', 'Private Service', 'BANKER', 'SEMIOR RELATIONSHIP MANAGER', 'RETAIL SALES', 'HBL ASSET MANAGEMENT', '10', NULL, 'Graduate', 'Married', '3', 'no', '500k-1mn', 'no', 'no', 'Salary', 'Deposit Slip.jpeg', 'HOUSE #104, STREET 1, GHOURI TOWN PHASE 5-A, ISLAMABAD.', 'Islamabad', 'pakistan', 'no', 'file', 'ZT Format (1).jpg', '2020-06-26 11:32:53', '2020-06-26 11:32:53'),
	(100, 'pk', 'ALI', 'QASIM', 'ZARA', '1993-02-03', '45555-5555555-5', 'HBL AMC 2.jfif', '2020-02-03', 'Karachi', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '923232323232', 'Private Service', 'FINANCIAL', 'OFFICER', 'FINANCE', 'ABC PVT LTD', '8', NULL, 'Graduate', 'Single', '1', 'no', '500k-1mn', 'no', 'no', 'Salary', 'HBL AMC 2.jfif', 'H NO 11 KARACHI PAKSITAN', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-05-20 13:03:07', '2020-05-20 13:03:07'),
	(101, 'pk', 'ALI', 'QASIM', 'ZARA', '1993-02-03', '45555-5555555-5', 'HBL AMC 2.jfif', '2020-02-03', 'Karachi', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '923232323232', 'Private Service', 'FINANCIAL', 'OFFICER', 'FINANCE', 'ABC PVT LTD', '8', NULL, 'Graduate', 'Single', '1', 'no', '500k-1mn', 'no', 'no', 'Salary', 'HBL AMC 2.jfif', 'H NO 11 KARACHI PAKSITAN', 'Karachi', 'pakistan', 'no', 'email', 'no_image.png', '2020-05-20 13:03:13', '2020-05-20 13:03:13'),
	(102, 'pk', 'ALI', 'QASIM', 'ZARA', '1993-02-03', '45555-5555555-5', 'HBL AMC 2.jfif', '2020-02-03', 'Karachi', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '923232323232', 'Private Service', 'FINANCIAL', 'OFFICER', 'FINANCE', 'ABC PVT LTD', '8', NULL, 'Graduate', 'Single', '1', 'no', '500k-1mn', 'no', 'no', 'Salary', 'HBL AMC 2.jfif', 'H NO 11 KARACHI PAKSITAN', 'Karachi', 'pakistan', 'no', 'email', NULL, '2020-05-20 13:03:14', '2020-06-02 12:50:05'),
	(103, 'pk', 'HAMZA', 'HAMZA', 'HAMZA', '2020-05-06', '54545-4545454-5', 'Lilly-takes-to-continuous-manufacturing-with-40m-Irish-investment.jpg', '2016-02-23', 'Lahore', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '922564789566', 'Govt. Employee', 'GOVERNMENT', 'OFFICER', 'AUDIT', 'WATER BOARD', '10', NULL, 'Undergraduate', 'Married', '5', 'no', '1-10mn', 'CREDIT CARD DEFAULTER', 'no', 'Salary', 'Lilly-takes-to-continuous-manufacturing-with-40m-Irish-investment.jpg', '5465465465465465', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-05-20 13:06:21', '2020-05-20 13:06:21'),
	(104, 'pk', 'NOMAN', 'ALI', 'SARA', '2005-02-11', '78979-7987987-9', 'winner-investment-plan.jpg', '2020-05-19', 'Karachi', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '928787878787', 'Student', NULL, NULL, NULL, NULL, NULL, NULL, 'Undergraduate', 'Single', '0', 'no', 'Less than 250k', 'no', 'no', 'POCKET MONEY', 'winner-investment-plan.jpg', 'DSDSDSDSADSAD', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-05-20 13:25:41', '2020-05-20 13:25:41'),
	(189, 'pk', 'MUZAFFAR KHAN AFRIDI', 'MUDASSIR KHAN', 'ZAINA', '1987-01-04', '14301-6152504-7', 'cbee770e-442b-4233-90cd-9bc2add7d125.JPG', '2019-05-30', 'Kohat', 'pakistan', 'AFRIDI.MUZAFFAR@GMAIL.COM', '923345307787', 'Private Service', 'BANKER', 'SEMIOR RELATIONSHIP MANAGER', 'RETAIL SALES', 'HBL ASSET MANAGEMENT', '10', NULL, 'Graduate', 'Married', '3', 'no', '500k-1mn', 'no', 'no', 'Salary', 'Deposit Slip.jpeg', 'HOUSE #104, STREET 1, GHOURI TOWN PHASE 5-A, ISLAMABAD.', 'Islamabad', 'pakistan', 'no', 'file', 'ZT Format (1).jpg', '2020-06-26 11:33:01', '2020-06-26 11:33:01'),
	(190, 'pk', 'MUZAFFAR KHAN AFRIDI', 'MUDASSIR KHAN', 'ZAINA', '1987-01-04', '14301-6152504-7', 'cbee770e-442b-4233-90cd-9bc2add7d125.JPG', '2019-05-30', 'Kohat', 'pakistan', 'AFRIDI.MUZAFFAR@GMAIL.COM', '923345307787', 'Private Service', 'BANKER', 'SEMIOR RELATIONSHIP MANAGER', 'RETAIL SALES', 'HBL ASSET MANAGEMENT', '10', NULL, 'Graduate', 'Married', '3', 'no', '500k-1mn', 'no', 'no', 'Salary', 'Deposit Slip.jpeg', 'HOUSE #104, STREET 1, GHOURI TOWN PHASE 5-A, ISLAMABAD.', 'Islamabad', 'pakistan', 'no', 'file', 'ZT Format (1).jpg', '2020-06-26 11:33:26', '2020-06-26 11:33:26'),
	(191, 'pk', 'MUZAFFAR KHAN AFRIDI', 'MUDASSIR KHAN', 'ZAINA', '1987-01-04', '14301-6152504-7', 'cbee770e-442b-4233-90cd-9bc2add7d125.JPG', '2019-05-30', 'Kohat', 'pakistan', 'AFRIDI.MUZAFFAR@GMAIL.COM', '923345307787', 'Private Service', 'BANKER', 'SEMIOR RELATIONSHIP MANAGER', 'RETAIL SALES', 'HBL ASSET MANAGEMENT', '10', NULL, 'Graduate', 'Married', '3', 'no', '500k-1mn', 'no', 'no', 'Salary', 'Deposit Slip.jpeg', 'HOUSE #104, STREET 1, GHOURI TOWN PHASE 5-A, ISLAMABAD.', 'Islamabad', 'pakistan', 'no', 'file', 'ZT Format (1).jpg', '2020-06-26 11:33:26', '2020-06-26 11:33:26'),
	(192, 'pk', 'MUZAFFAR KHAN AFRIDI', 'MUDASSIR KHAN', 'ZAINA', '1987-01-04', '14301-6152504-7', 'cbee770e-442b-4233-90cd-9bc2add7d125.JPG', '2019-05-30', 'Kohat', 'pakistan', 'AFRIDI.MUZAFFAR@GMAIL.COM', '923345307787', 'Private Service', 'BANKER', 'SEMIOR RELATIONSHIP MANAGER', 'RETAIL SALES', 'HBL ASSET MANAGEMENT', '10', NULL, 'Graduate', 'Married', '3', 'no', '500k-1mn', 'no', 'no', 'Salary', 'Deposit Slip.jpeg', 'HOUSE #104, STREET 1, GHOURI TOWN PHASE 5-A, ISLAMABAD.', 'Islamabad', 'pakistan', 'no', 'file', 'ZT Format (1).jpg', '2020-06-26 11:33:27', '2020-06-26 11:33:27'),
	(193, 'pk', 'AWAIS AHMAD', 'FIAZ AHMAD MUGHAL', 'REHANA', '1991-09-24', '34101--576772-7', 'IMG-20200618-WA0002.jpg', '2010-06-29', 'Gujranwala', 'pakistan', 'MRAWAISAHMAD597@GMAIL.COM', '923026643589', 'Private Service', 'RETAIL SALES (HBL ASSET MANAGEMENT)', 'INVESTMENT ADVISOR', 'RETAIL SALES', 'HBL ASSET MANAGEMENT', '3', NULL, 'Postgraduate', 'Single', '5', 'no', '500k-1mn', 'no', 'no', 'Salary', 'Pay Slip Month of DEC.PNG', 'FIRST FLOOR ROSHAN CENTER,BLUE AREA ISLAMABAD', 'Islamabad', 'pakistan', 'yes', NULL, 'no_image.png', '2020-07-01 11:32:25', '2020-07-01 11:32:25'),
	(194, 'pk', 'AWAIS AHMAD', 'FIAZ AHMAD MUGHAL', 'REHANA', '1991-09-24', '34101--576772-7', 'IMG-20200618-WA0002.jpg', '2010-06-29', 'Gujranwala', 'pakistan', 'MRAWAISAHMAD597@GMAIL.COM', '923026643589', 'Private Service', 'RETAIL SALES (HBL ASSET MANAGEMENT)', 'INVESTMENT ADVISOR', 'RETAIL SALES', 'HBL ASSET MANAGEMENT', '3', NULL, 'Postgraduate', 'Single', '5', 'no', '500k-1mn', 'no', 'no', 'Salary', 'Pay Slip Month of DEC.PNG', 'FIRST FLOOR ROSHAN CENTER,BLUE AREA ISLAMABAD', 'Islamabad', 'pakistan', 'yes', NULL, 'no_image.png', '2020-07-01 11:32:27', '2020-07-01 11:32:27'),
	(195, 'pk', 'MARIA SHAHNAWAZ', 'SHAHNAWAZ', 'IRSHA BIBI', '1989-04-30', '37405-8971990-0', '38F63777-B66A-49CE-AF0C-97A32B5266FB.jpeg', '2019-12-17', 'Rawalpindi', 'pakistan', 'MARIASHAHNAWAZ@YAHOO.COM', '923365365336', 'Private Service', 'MARKETI', 'SIA', 'SALES', 'HBL ASSET MANAGEM', '10', NULL, 'Graduate', 'Single', '0', 'no', 'Less than 250k', 'no', 'no', 'Salary', '2CFF799A-11F5-4253-98B8-8AA0E68C4A3F.png', 'RAWAL', 'Rawalpindi', 'pakistan', 'no', 'courier', 'no_image.png', '2020-07-01 11:46:56', '2020-07-01 11:46:56'),
	(196, 'pk', 'MARIA SHAHNAWAZ', 'SHAHNAWAZ', 'IRSHA BIBI', '1989-04-30', '37405-8971990-0', '38F63777-B66A-49CE-AF0C-97A32B5266FB.jpeg', '2019-12-17', 'Rawalpindi', 'pakistan', 'MARIASHAHNAWAZ@YAHOO.COM', '923365365336', 'Private Service', 'MARKETI', 'SIA', 'SALES', 'HBL ASSET MANAGEM', '10', NULL, 'Graduate', 'Single', '0', 'no', 'Less than 250k', 'no', 'no', 'Salary', '2CFF799A-11F5-4253-98B8-8AA0E68C4A3F.png', 'RAWAL', 'Rawalpindi', 'pakistan', 'no', 'courier', 'no_image.png', '2020-07-01 11:47:13', '2020-07-01 11:47:13'),
	(197, 'pk', 'RAJA USMAN AHMED', 'RAJA SHAH MUHAMMAD', 'SAKINA BEGUM', '1990-01-14', '37405-3362019-7', 'RAJA USMAN AHMED CNIC.jpg', '2013-03-25', 'Rawalpindi', 'pakistan', 'R.USMANAHMED@YAHOO.COM', '923344313616', 'Private Service', 'BANKING', 'RM', 'SALES', 'HBL', '5', NULL, 'Postgraduate', 'Single', '0', 'no', '500k-1mn', 'no', 'no', 'Salary', 'PaySlip_of_00423_for_May 2020 (2).pdf', 'H NO 22/25 STREET 01 BLOCK A REHMATABAD CHAKLALA RAWALPINDI', 'Rawalpindi', 'pakistan', 'no', 'file', 'no_image.png', '2020-07-01 12:04:04', '2020-07-01 12:04:04'),
	(198, 'pk', 'RAJA USMAN AHMED', 'RAJA SHAH MUHAMMAD', 'SAKINA BEGUM', '1990-01-14', '37405-3362019-7', 'RAJA USMAN AHMED CNIC.jpg', '2013-03-25', 'Rawalpindi', 'pakistan', 'R.USMANAHMED@YAHOO.COM', '923344313616', 'Private Service', 'BANKING', 'RM', 'SALES', 'HBL', '5', NULL, 'Postgraduate', 'Single', '0', 'no', '500k-1mn', 'no', 'no', 'Salary', 'PaySlip_of_00423_for_May 2020 (2).pdf', 'H NO 22/25 STREET 01 BLOCK A REHMATABAD CHAKLALA RAWALPINDI', 'Rawalpindi', 'pakistan', 'no', 'file', 'no_image.png', '2020-07-01 12:04:10', '2020-07-01 12:04:10'),
	(199, 'pk', 'SUMBAL NAZ', 'REHMAT HUSSAIN', 'SAMINA', '1995-08-17', '17301-0982582-8', 'Cnic.pdf', '2014-04-01', 'Peshawar', 'pakistan', 'SUMBALNAZ_95@YAHOO.COM', '923349304052', 'Private Service', 'SALES', 'INVESTMENT ADVISOR', 'HBL AMC', 'HBL AMC', '2', NULL, 'Postgraduate', 'Single', '0', 'no', '250-500k', 'no', 'no', 'Salary', 'salary slip.pdf', 'HOUSE#C1-46 DARAKSHAN COLONY GUNJ PESHAWAR', 'Peshawar', 'pakistan', 'no', 'courier', 'no_image.png', '2020-07-01 14:37:55', '2020-07-01 14:37:55'),
	(200, 'pk', 'SUMBAL NAZ', 'REHMAT HUSSAIN', 'SAMINA', '1995-08-17', '17301-0982582-8', 'Cnic.pdf', '2014-04-01', 'Peshawar', 'pakistan', 'SUMBALNAZ_95@YAHOO.COM', '923349304052', 'Private Service', 'SALES', 'INVESTMENT ADVISOR', 'HBL AMC', 'HBL AMC', '2', NULL, 'Postgraduate', 'Single', '0', 'no', '250-500k', 'no', 'no', 'Salary', 'salary slip.pdf', 'HOUSE#C1-46 DARAKSHAN COLONY GUNJ PESHAWAR', 'Peshawar', 'pakistan', 'no', 'courier', 'no_image.png', '2020-07-01 14:38:01', '2020-07-01 14:38:01'),
	(201, 'pk', 'SUMBAL NAZ', 'REHMAT HUSSAIN', 'SAMINA', '1995-08-17', '17301-0982582-8', 'Cnic.pdf', '2014-04-01', 'Peshawar', 'pakistan', 'SUMBALNAZ_95@YAHOO.COM', '923349304052', 'Private Service', 'SALES', 'INVESTMENT ADVISOR', 'HBL AMC', 'HBL AMC', '2', NULL, 'Postgraduate', 'Single', '0', 'no', '250-500k', 'no', 'no', 'Salary', 'salary slip.pdf', 'HOUSE#C1-46 DARAKSHAN COLONY GUNJ PESHAWAR', 'Peshawar', 'pakistan', 'no', 'courier', 'no_image.png', '2020-07-01 14:38:19', '2020-07-01 14:38:19'),
	(202, 'pk', 'ALI', 'IFTIKHAR', 'FARHAT', '1992-05-07', '42201-5789658-8', 'HBL AM Query.jpg', '2020-07-05', 'Karachi', 'pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '923232255778', 'Govt. Employee', 'GOVT EMPLOYEE', 'OFFICER', 'AUDIT', 'ABC', '10', NULL, 'Postgraduate', 'Single', '1', 'no', '10mn-100mn', 'no', 'no', 'Salary', 'Lilly-takes-to-continuous-manufacturing-with-40m-Irish-investment.jpg', 'STREET 2', 'Karachi', 'pakistan', 'yes', NULL, 'no_image.png', '2020-07-07 13:34:19', '2020-07-07 13:34:19'),
	(203, 'pk', 'ALI', 'JAN', 'JAVERIA', '1995-05-10', '55555-5555555-5', 'HBL AMC 2.jfif', '2012-02-08', 'Karachi', 'pk', 'OMAIR.FAROOQ@HBLASSET.COM', '923232323232', 'Private Service', 'PRIVATE JOB', 'OFFICER', 'CALL CENTER', 'ABC PVT LTD', '6', NULL, 'Graduate', 'Single', '0', 'no', '500k-1mn', 'no', 'no', 'Salary', 'HBL AMC 2.jfif', 'H.NO 223 PECHS KARACHI', 'Karachi', 'pk', 'yes', NULL, 'no_image.png', '2020-07-20 16:49:59', '2020-07-20 16:49:59'),
	(204, 'pk', 'ALI', 'JAN', 'JAVERIA', '1995-05-10', '55555-5555555-5', 'HBL AMC 2.jfif', '2012-02-08', 'Karachi', 'pk', 'OMAIR.FAROOQ@HBLASSET.COM', '923232323232', 'Private Service', 'PRIVATE JOB', 'OFFICER', 'CALL CENTER', 'ABC PVT LTD', '6', NULL, 'Graduate', 'Single', '0', 'no', '500k-1mn', 'no', 'no', 'Salary', 'HBL AMC 2.jfif', 'H.NO 223 PECHS KARACHI', 'Karachi', 'pk', 'yes', NULL, 'no_image.png', '2020-07-20 16:50:06', '2020-07-20 16:50:06'),
	(205, 'us', 'TESTER', 'TESTER', 'TESTER', '1997-01-01', '44654-5646464-4', '684789_high-resolution-purple-desktop-wallpapers-full-size-siwallpaperhd_2880x1800_h.jpg', '2020-07-01', '194', '19', 'TESTER@E', '9213131313131321', 'Student', NULL, NULL, NULL, NULL, NULL, NULL, 'Postgraduate', 'Single', '1', 'yes', '500k-1mn', 'TESTER', 'TESTER', 'Home Remittance', '41KeFBGCG1L.jpg', 'TESTER', 'undefined', 'undefined', 'no', 'file', '41KeFBGCG1L.jpg', '2020-07-29 11:51:36', '2020-07-29 11:51:36'),
	(206, 'pk', 'TESTER', 'TESTER', 'TESTER', '2020-07-01', '12121-2131311-1', '41KeFBGCG1L.jpg', '2020-07-01', '36', '1', 'A@G', '92111111121212121', 'Businessman', 'TESTER', 'TESTER', NULL, 'TESTER', '1', '1', 'Undergraduate', 'Single', '1', 'yes', '10mn-100mn', 'no', 'no', 'Inheritance', '41KeFBGCG1L.jpg', 'TESTER', 'undefined', 'undefined', 'no', 'file', '41KeFBGCG1L.jpg', '2020-07-29 11:56:18', '2020-07-29 11:56:18'),
	(207, 'pk', 'TESTER', 'TESTER', 'TESTER', '2020-02-01', '113131313131313', '41KeFBGCG1L.jpg', '2020-07-01', '1', '1', 'A@G', '1313131313131', 'Govt. Employee', 'TESTER', 'TESTER', 'TESTER', 'TESTER', '2', NULL, 'Postgraduate', 'Single', '2', 'no', '1-10mn', 'no', 'no', 'Salary', '41KeFBGCG1L.jpg', 'TESTER', 'undefined', 'undefined', 'no', 'file', '41KeFBGCG1L.jpg', '2020-07-29 14:41:29', '2020-07-29 14:41:29'),
	(208, 'pk', 'TESTER', 'TESTER', 'TESTER', '1994-02-01', '12121-2131311-1', '41KeFBGCG1L.jpg', '2020-07-01', '133', '1', 'A@G', '121313131313111', 'Businessman', 'TESTER', 'TESTER', NULL, 'TESTER', '2', '2', 'Postgraduate', 'Married', '2', 'yes', 'Above 100mn', 'TESTER', 'TESTER', 'Self-Owned', '41KeFBGCG1L.jpg', 'TESTER', 'undefined', 'undefined', 'no', 'file', '11-117837_samsung-mobile-phone-clipart-hand-png-mobile-in.png', '2020-07-29 15:07:00', '2020-07-29 15:07:00'),
	(209, 'pk', 'TESTER', 'TESTER', 'TESTER', '1994-02-01', '12121-2131311-1', '41KeFBGCG1L.jpg', '2020-07-01', '133', '1', 'A@G', '121313131313111', 'Businessman', 'TESTER', 'TESTER', NULL, 'TESTER', '2', '2', 'Postgraduate', 'Married', '2', 'yes', 'Above 100mn', 'TESTER', 'TESTER', 'Self-Owned', '41KeFBGCG1L.jpg', 'TESTER', 'undefined', 'undefined', 'no', 'file', '11-117837_samsung-mobile-phone-clipart-hand-png-mobile-in.png', '2020-07-29 15:07:08', '2020-07-29 15:07:08'),
	(210, 'pk', 'ASIF', 'ASIF', 'ASIF', '1997-08-14', '1131313131311-1', '41KeFBGCG1L.jpg', '2020-07-01', '43', '1', 'A@G', '123456789123456', 'Govt. Employee', 'TESTER', 'TESTER', 'TESTER', 'TESTER', '2', NULL, 'Undergraduate', 'Married', '2', 'yes', '10mn-100mn', 'TESTER', 'no', 'Salary', '41KeFBGCG1L.jpg', 'TESTER', 'undefined', 'undefined', 'no', 'file', '41KeFBGCG1L.jpg', '2020-07-29 15:09:53', '2020-07-29 15:09:53'),
	(211, 'pk', 'ASIF', 'ASIF', 'ASIF', '1997-08-14', '1131313131311-1', '41KeFBGCG1L.jpg', '2020-07-01', '43', '1', 'A@G', '123456789123456', 'Govt. Employee', 'TESTER', 'TESTER', 'TESTER', 'TESTER', '2', NULL, 'Undergraduate', 'Married', '2', 'yes', '10mn-100mn', 'TESTER', 'no', 'Salary', '41KeFBGCG1L.jpg', 'TESTER', 'undefined', 'undefined', 'no', 'file', '41KeFBGCG1L.jpg', '2020-07-29 15:10:00', '2020-07-29 15:10:00'),
	(212, 'pk', 'TESTER', 'TESTER', 'TESTER', '1999-01-01', '11311-3113131-1', 'Australia-To-Host-T20-723x394.jpg', '2019-01-01', '19|Carlifornia', '5|United States of America', 'A@S', '1112121212', 'Govt. Employee', 'TESTER', 'TESTER', 'TESTER', 'TESTER', '2', NULL, 'Undergraduate', 'Married', '2', 'yes', 'Less than 250k', 'TESTER', 'no', 'Salary', 'Australia-To-Host-T20-723x394.jpg', 'TESTER', '3|Ahmadi', '3|Kuwait', 'no', 'file', 'Australia-To-Host-T20-723x394.jpg', '2020-08-18 13:10:13', '2020-08-18 13:10:13'),
	(213, 'pk', 'OMAIR', 'INAM', 'NASREEN', '1985-10-10', '42501-0850690-1', 'Logo (White).bmp', '2015-03-21', '1|KARACHI', '1|Pakistan', 'OMAIRINAM@HOTMAIL.COM', '03333008195', 'Private Service', 'ASSET MANAGER', 'MANAGER', 'CUSTOMER CARE', 'HBL ASSET', '12', NULL, 'Graduate', 'Married', '3', 'no', '10mn-100mn', 'no', 'no', 'Salary', 'Logo Green.bmp', 'JAUHAR KARACHI', '1|KARACHI', '1|Pakistan', 'yes', NULL, 'no_image.png', '2020-08-20 16:34:59', '2020-08-20 16:34:59'),
	(214, 'pk', 'ALI', 'MIRZA', 'HIRA', '1974-02-06', '42425-4254254-2', 'AMC-VPS-300x250b.jpg', '2020-02-04', '1|KARACHI', '1|Pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '03211234567', 'Govt. Employee', 'GOVT EMPLOYEE', 'OFFICER', 'FINANCE', 'ABC', '6', NULL, 'Graduate', 'Single', '0', 'no', '500k-1mn', 'no', 'no', 'Salary', 'AMC-VPS-300x250b.jpg', 'STREET 3', '15|Lahore', '1|Pakistan', 'yes', NULL, 'no_image.png', '2020-08-24 16:28:43', '2020-08-24 16:28:43'),
	(215, 'pk', 'ALI', 'HAIDER', 'JAVERIA', '1998-05-06', '45454-5454545-4', 'HBL AM VPS Post 3.jpg', '2020-01-06', '15|Lahore', '1|Pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '032232323232', 'Businessman', 'PRIVATE', 'MANAGER', NULL, 'ABC PVT LTD', '12', '12', 'Professional', 'Married', '4', 'no', '1-10mn', 'no', 'no', 'Self-Owned', 'HBL AM VPS Post 3.jpg', 'BLUE AREA SECTOR C ISB', '24|Islamabad', '1|Pakistan', 'no', 'email', 'no_image.png', '2020-08-27 10:01:46', '2020-08-27 10:01:46'),
	(216, 'pk', 'ALI', 'HAIDER', 'JAVERIA', '1998-05-06', '45454-5454545-4', 'HBL AM VPS Post 3.jpg', '2020-01-06', '15|Lahore', '1|Pakistan', 'OMAIR.FAROOQ@HBLASSET.COM', '032232323232', 'Businessman', 'PRIVATE', 'MANAGER', NULL, 'ABC PVT LTD', '12', '12', 'Professional', 'Married', '4', 'no', '1-10mn', 'no', 'no', 'Self-Owned', 'HBL AM VPS Post 3.jpg', 'BLUE AREA SECTOR C ISB', '24|Islamabad', '1|Pakistan', 'no', 'email', 'no_image.png', '2020-08-27 10:01:51', '2020-08-27 10:01:51'),
	(217, 'o', 'BABAR', 'ALI', 'HIRA', '1989-01-01', '45454-5454545-4', 'HBL AM VPS Post 3.jpg', '2015-02-18', '2|Dubai', '2|United Arab Emirates', 'OMAIR.FAROOQ@HBLASSET.COM', '971565965656565', 'Businessman', 'GENERAL TRADING', 'DIRECTOR', NULL, 'ABC LLC', '0', '10', 'Postgraduate', 'Married', '3', 'no', '10mn-100mn', 'no', 'no', 'Self-Owned', 'HBL AM VPS Post 3.jpg', 'DSDSDSDSDSDSDSDSDSDSDSDSDSDS', '2|Dubai', '2|United Arab Emirates', 'yes', NULL, 'no_image.png', '2020-08-27 10:06:51', '2020-08-27 10:06:51'),
	(218, 'pk', 'OMAIR INAM ONE', 'INAM MASOOD', 'NASREEN INAM', '1985-10-08', '42501-0850690-1', 'Logo Green.bmp', '2003-02-06', '1|KARACHI', '1|Pakistan', 'OMAIR.INAM@HBLASSET.COM', '03333008195', 'Private Service', 'ASSET MANAGEMENT', 'MANAGER', 'CUSTOMER CARE', 'HBL ASSET', '13', NULL, 'Postgraduate', 'Married', '3', 'no', '500k-1mn', 'no', 'no', 'Salary', 'Logo (White).bmp', 'GULISTAN-E-JAUHAR', '1|KARACHI', '1|Pakistan', 'no', 'file', 'services_desk.jpg', '2020-08-31 13:44:12', '2020-08-31 13:44:12'),
	(219, 'pk', 'OMAIR INAM ONE', 'INAM MASOOD', 'NASREEN INAM', '1985-10-08', '42501-0850690-1', 'Logo Green.bmp', '2003-02-06', '1|KARACHI', '1|Pakistan', 'OMAIR.INAM@HBLASSET.COM', '03333008195', 'Private Service', 'ASSET MANAGEMENT', 'MANAGER', 'CUSTOMER CARE', 'HBL ASSET', '13', NULL, 'Postgraduate', 'Married', '3', 'no', '500k-1mn', 'no', 'no', 'Salary', 'Logo (White).bmp', 'GULISTAN-E-JAUHAR', '1|KARACHI', '1|Pakistan', 'no', 'file', 'services_desk.jpg', '2020-08-31 13:44:17', '2020-08-31 13:44:17'),
	(220, 'pk', 'OMAIR INAM TWO', 'INAM MASOOD', 'NASREEN INAM', '1986-05-08', '42501-0850690-2', 'Logo (White).bmp', '2011-02-02', '1|KARACHI', '1|Pakistan', 'OMAIRINAM1985@GMAIL.COM', '03032268074', 'Businessman', 'JEWELERS', 'OWNER', NULL, 'SYED JEWELERS', '10', '10', 'Graduate', 'Single', '0', 'no', '250-500k', 'no', 'no', 'Self-Owned', 'services_desk.jpg', 'TARIQ ROAD', '1|KARACHI', '1|Pakistan', 'no', 'file', 'Logo Green.bmp', '2020-08-31 13:47:42', '2020-08-31 13:47:42'),
	(221, 'pk', 'OMAIR INAM THREE', 'INAM MASOOD', 'NASREEN INAM', '1977-05-12', '42500-8506903-3', 'Logo Green.bmp', '2016-02-01', '1|KARACHI', '1|Pakistan', 'OMAIRINAM@YAHOO.COM', '03458777147', 'Govt. Employee', 'FBR', 'HEAD OF THE DEPARTMENT', 'FINANCE', 'FBR', '20', NULL, 'Postgraduate', 'Married', '5', 'no', '10mn-100mn', 'no', 'no', 'Salary', 'services_desk.jpg', 'GULSHAN', '1|KARACHI', '1|Pakistan', 'no', 'file', 'services_desk.jpg', '2020-08-31 13:51:19', '2020-08-31 13:51:19'),
	(222, 'pk', 'OMAIR INAM THREE', 'INAM MASOOD', 'NASREEN INAM', '1977-05-12', '42500-8506903-3', 'Logo Green.bmp', '2016-02-01', '1|KARACHI', '1|Pakistan', 'OMAIRINAM@YAHOO.COM', '03458777147', 'Govt. Employee', 'FBR', 'HEAD OF THE DEPARTMENT', 'FINANCE', 'FBR', '20', NULL, 'Postgraduate', 'Married', '5', 'no', '10mn-100mn', 'no', 'no', 'Salary', 'services_desk.jpg', 'GULSHAN', '1|KARACHI', '1|Pakistan', 'no', 'file', 'services_desk.jpg', '2020-08-31 13:51:23', '2020-08-31 13:51:23');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.discussions
CREATE TABLE IF NOT EXISTS `discussions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `msg` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.discussions: ~2 rows (approximately)
/*!40000 ALTER TABLE `discussions` DISABLE KEYS */;
REPLACE INTO `discussions` (`id`, `form_id`, `msg`, `receiver_id`, `sender_id`, `created_at`, `updated_at`) VALUES
	(12, 'SA1799', 'Form ok Please conduct CBC', '76', '91', '2020-06-02 12:48:28', '2020-06-02 12:48:28'),
	(13, 'SA1799', 'CBC Done', '0', '95', '2020-06-02 12:50:05', '2020-06-02 12:50:05'),
	(14, 'SA4793', 'Please perform CBC', '76', '90', '2020-06-19 11:46:28', '2020-06-19 11:46:28'),
	(15, 'SA4092', 'CNIC BACK SIDE REQUIRED, JOB CARD BACK, ZD FORM MISSING', '89', '90', '2020-06-19 13:23:26', '2020-06-19 13:23:26'),
	(16, 'SA2936', 'ATTACHMENTS ARE NOT SHOWING, PLEASE ATTACHED DOCUMENTS', '89', '90', '2020-06-19 13:36:58', '2020-06-19 13:36:58'),
	(17, 'SA1799', 'test', '89', '90', '2020-07-22 17:53:23', '2020-07-22 17:53:23');
/*!40000 ALTER TABLE `discussions` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.exp
CREATE TABLE IF NOT EXISTS `exp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shd` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fund_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.exp: ~17 rows (approximately)
/*!40000 ALTER TABLE `exp` DISABLE KEYS */;
REPLACE INTO `exp` (`id`, `shd`, `title`, `desc`, `fund_id`, `created_at`, `updated_at`) VALUES
	(1, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 10, NULL, NULL),
	(2, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 11, NULL, NULL),
	(3, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 12, '0000-00-00 00:00:00', NULL),
	(4, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 13, '0000-00-00 00:00:00', NULL),
	(5, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 14, NULL, NULL),
	(6, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 15, NULL, NULL),
	(7, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 16, NULL, NULL),
	(8, 'As of July  31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 17, NULL, NULL),
	(9, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 18, NULL, NULL),
	(10, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 19, NULL, NULL),
	(11, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 20, NULL, NULL),
	(12, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- for one year; the cumulative value of your investment would have been as per the above chart.', 21, NULL, NULL),
	(13, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 22, NULL, NULL),
	(14, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 23, NULL, NULL),
	(15, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 24, NULL, NULL),
	(16, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- for one year; the cumulative value of your investment would have been as per the above chart.', 25, NULL, NULL),
	(17, 'As of July 31, 2020', 'Explanation:', 'If you would have invested Rs. 10,000/- each for three different tenures of 1 Year, 3 Years and 5 Years; the cumulative value of your investment would have been as per the above chart.', 26, NULL, NULL);
/*!40000 ALTER TABLE `exp` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.fatca_details
CREATE TABLE IF NOT EXISTS `fatca_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `multiple_nat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nats` longtext COLLATE utf8mb4_unicode_ci,
  `green_card` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_resi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `for_citi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `co_ma` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `co_mp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attor_addr` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trans_fund` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wf` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wform` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wform_options` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.fatca_details: 3 rows
/*!40000 ALTER TABLE `fatca_details` DISABLE KEYS */;
REPLACE INTO `fatca_details` (`id`, `multiple_nat`, `nats`, `green_card`, `tax_resi`, `for_citi`, `co_ma`, `co_mp`, `attor`, `attor_addr`, `trans_fund`, `wf`, `wform`, `wform_options`, `customer_id`, `created_at`, `updated_at`) VALUES
	(59, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 107, '2020-06-15 10:54:27', '2020-06-15 10:54:27'),
	(60, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 108, '2020-06-15 10:54:32', '2020-06-15 10:54:32'),
	(61, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 111, '2020-06-15 10:54:47', '2020-06-15 10:54:47'),
	(62, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 111, '2020-06-15 10:55:02', '2020-06-15 10:55:02'),
	(63, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 112, '2020-06-15 10:55:02', '2020-06-15 10:55:02'),
	(64, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 112, '2020-06-15 10:55:07', '2020-06-15 10:55:07'),
	(65, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 113, '2020-06-16 14:23:09', '2020-06-16 14:23:09'),
	(66, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 114, '2020-06-16 14:23:17', '2020-06-16 14:23:17'),
	(67, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 115, '2020-06-18 14:17:16', '2020-06-18 14:17:16'),
	(68, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 116, '2020-06-18 14:17:23', '2020-06-18 14:17:23'),
	(69, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 117, '2020-06-18 14:17:27', '2020-06-18 14:17:27'),
	(70, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 118, '2020-06-18 14:35:35', '2020-06-18 14:35:35'),
	(71, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 119, '2020-06-18 14:54:43', '2020-06-18 14:54:43'),
	(72, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 120, '2020-06-18 14:54:51', '2020-06-18 14:54:51'),
	(73, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 121, '2020-06-18 15:06:29', '2020-06-18 15:06:29'),
	(74, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 122, '2020-06-18 15:06:33', '2020-06-18 15:06:33'),
	(75, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 140, '2020-06-19 14:31:55', '2020-06-19 14:31:55'),
	(76, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 141, '2020-06-19 14:32:04', '2020-06-19 14:32:04'),
	(77, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 142, '2020-06-19 14:38:58', '2020-06-19 14:38:58'),
	(78, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 143, '2020-06-19 14:39:01', '2020-06-19 14:39:01'),
	(79, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 144, '2020-06-19 14:39:13', '2020-06-19 14:39:13'),
	(80, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 147, '2020-06-22 10:35:52', '2020-06-22 10:35:52'),
	(81, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 149, '2020-06-22 10:35:57', '2020-06-22 10:35:57'),
	(82, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 151, '2020-06-22 12:24:42', '2020-06-22 12:24:42'),
	(83, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 152, '2020-06-22 12:24:44', '2020-06-22 12:24:44'),
	(84, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 154, '2020-06-22 12:38:52', '2020-06-22 12:38:52'),
	(85, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 155, '2020-06-22 12:39:12', '2020-06-22 12:39:12'),
	(86, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 157, '2020-06-22 13:05:43', '2020-06-22 13:05:43'),
	(87, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 160, '2020-06-22 13:18:19', '2020-06-22 13:18:19'),
	(88, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 161, '2020-06-22 15:30:59', '2020-06-22 15:30:59'),
	(89, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 162, '2020-06-22 15:31:04', '2020-06-22 15:31:04'),
	(90, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 163, '2020-06-22 15:31:07', '2020-06-22 15:31:07'),
	(91, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 164, '2020-06-22 15:34:45', '2020-06-22 15:34:45'),
	(92, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 169, '2020-06-23 10:11:24', '2020-06-23 10:11:24'),
	(93, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 170, '2020-06-23 10:11:29', '2020-06-23 10:11:29'),
	(94, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 171, '2020-06-23 10:11:33', '2020-06-23 10:11:33'),
	(95, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 172, '2020-06-23 10:44:51', '2020-06-23 10:44:51'),
	(96, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 173, '2020-06-23 10:44:55', '2020-06-23 10:44:55'),
	(97, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 174, '2020-06-23 12:51:11', '2020-06-23 12:51:11'),
	(98, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 178, '2020-06-24 12:44:19', '2020-06-24 12:44:19'),
	(99, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 179, '2020-06-24 12:44:21', '2020-06-24 12:44:21'),
	(100, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 181, '2020-06-25 15:28:24', '2020-06-25 15:28:24'),
	(101, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 182, '2020-06-25 15:28:30', '2020-06-25 15:28:30'),
	(102, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 183, '2020-06-25 15:35:53', '2020-06-25 15:35:53'),
	(103, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 184, '2020-06-25 15:35:59', '2020-06-25 15:35:59'),
	(56, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 100, '2020-05-20 13:03:14', '2020-05-20 13:03:14'),
	(57, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 101, '2020-05-20 13:03:18', '2020-05-20 13:03:18'),
	(58, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 102, '2020-05-20 13:03:18', '2020-05-20 13:03:18'),
	(104, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 185, '2020-06-25 15:50:37', '2020-06-25 15:50:37'),
	(105, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 186, '2020-06-25 16:06:12', '2020-06-25 16:06:12'),
	(106, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 188, '2020-06-26 11:33:00', '2020-06-26 11:33:00'),
	(107, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 189, '2020-06-26 11:33:08', '2020-06-26 11:33:08'),
	(108, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 191, '2020-06-26 11:33:30', '2020-06-26 11:33:30'),
	(109, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 191, '2020-06-26 11:33:30', '2020-06-26 11:33:30'),
	(110, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 192, '2020-06-26 11:33:31', '2020-06-26 11:33:31'),
	(111, 'no', NULL, 'no', 'no', 'no', 'NO', '03026643589', 'no', NULL, 'no', 'no', 'no_image.png', NULL, 194, '2020-07-01 11:32:32', '2020-07-01 11:32:32'),
	(112, 'no', NULL, 'no', 'no', 'no', 'NO', '03026643589', 'no', NULL, 'no', 'no', 'no_image.png', NULL, 194, '2020-07-01 11:32:32', '2020-07-01 11:32:32'),
	(113, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 195, '2020-07-01 11:47:04', '2020-07-01 11:47:04'),
	(114, 'no', NULL, 'no', 'no', 'no', 'N/A', '0', 'no', NULL, 'no', 'no', 'no_image.png', NULL, 197, '2020-07-01 12:04:11', '2020-07-01 12:04:11'),
	(115, 'no', NULL, 'no', 'no', 'no', 'N/A', '0', 'no', NULL, 'no', 'no', 'no_image.png', NULL, 198, '2020-07-01 12:04:15', '2020-07-01 12:04:15'),
	(116, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 200, '2020-07-01 14:38:10', '2020-07-01 14:38:10'),
	(117, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 201, '2020-07-01 14:38:33', '2020-07-01 14:38:33'),
	(118, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 202, '2020-07-07 13:34:25', '2020-07-07 13:34:25'),
	(119, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 203, '2020-07-20 16:50:06', '2020-07-20 16:50:06'),
	(120, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 204, '2020-07-20 16:50:11', '2020-07-20 16:50:11'),
	(121, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 208, '2020-07-29 15:07:05', '2020-07-29 15:07:05'),
	(122, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 209, '2020-07-29 15:07:12', '2020-07-29 15:07:12'),
	(123, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 210, '2020-07-29 15:09:57', '2020-07-29 15:09:57'),
	(124, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 211, '2020-07-29 15:10:04', '2020-07-29 15:10:04'),
	(125, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 213, '2020-08-20 16:35:03', '2020-08-20 16:35:03'),
	(126, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 214, '2020-08-24 16:28:58', '2020-08-24 16:28:58'),
	(127, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 215, '2020-08-27 10:01:52', '2020-08-27 10:01:52'),
	(128, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 216, '2020-08-27 10:01:54', '2020-08-27 10:01:54'),
	(129, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 218, '2020-08-31 13:44:17', '2020-08-31 13:44:17'),
	(130, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 220, '2020-08-31 13:47:46', '2020-08-31 13:47:46'),
	(131, 'no', NULL, 'no', 'no', 'no', NULL, NULL, 'no', NULL, 'no', 'no', 'no_image.png', NULL, 221, '2020-08-31 13:51:23', '2020-08-31 13:51:23');
/*!40000 ALTER TABLE `fatca_details` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.features_benefits
CREATE TABLE IF NOT EXISTS `features_benefits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_bullets_rt` varchar(300) DEFAULT NULL,
  `fb_bullets_lt` varchar(300) DEFAULT NULL,
  `fund_id` int(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.features_benefits: ~58 rows (approximately)
/*!40000 ALTER TABLE `features_benefits` DISABLE KEYS */;
REPLACE INTO `features_benefits` (`id`, `fb_bullets_rt`, `fb_bullets_lt`, `fund_id`, `created_at`, `updated_at`) VALUES
	(1, 'Easy to Invest.', 'No back end load.', 10, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(2, 'Safe Investment.', 'Actively managed by experienced Fund Managers.', 10, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(3, 'Stable returns.', NULL, 10, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(4, 'Timely redeemable.', NULL, 10, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(7, 'Easy to Invest.', 'No back end load.', 11, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(8, 'Actively managed by experienced Fund Managers.', 'Safe Investment.', 11, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(9, 'Stable returns.', 'Actively managed by experienced Fund Managers.', 11, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(10, 'Timely redeemable.', NULL, 11, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(13, 'Easy to Invest.', 'No back end load.', 12, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(14, 'Safe Investment.', 'Actively managed by experienced Fund Managers.', 12, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(15, 'Stable returns.', NULL, 12, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(16, 'Timely redeemable.', NULL, 12, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(19, 'Easy to Invest.', 'No back end load.', 13, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(20, 'Safe Investment.', 'Actively managed by experienced Fund Managers.', 13, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(21, 'Stable returns.', NULL, 13, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(22, 'Timely redeemable.', NULL, 13, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(25, 'Easy to Invest.', 'No back end load.', 14, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(26, 'Safe Investment.', 'Actively managed by experienced Fund Managers.', 14, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(27, 'Stable returns.', NULL, 14, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(28, 'Timely redeemable.', NULL, 14, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(31, 'Easy to Invest.', 'No back end load.', 15, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(32, 'Safe Investment.', 'Actively managed by experienced Fund Managers.', 15, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(33, 'Stable returns.', NULL, 15, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(34, 'Timely redeemable.', NULL, 15, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(37, 'Easy to Invest.', 'Selective off-index allocations to generate alpha.\r\n', 16, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(38, 'Diversified portfolio with a focus on high-quality blue-chip stocks.\r\n', 'Actively managed by experienced Fund Managers.\r\n', 16, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(39, 'No back end load.', NULL, 16, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(42, 'Easy to Invest.', 'Selective off-index allocations to generate alpha.\r\n', 17, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(43, 'Diversified portfolio with a focus on high-quality blue-chip stocks.\r\n', 'Actively managed by experienced Fund Managers.\r\n', 17, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(44, 'No back end load.', NULL, 17, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(47, 'Easy to Invest.', 'Selective off-index allocations to generate alpha.\r\n', 18, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(48, 'Diversified portfolio with a focus on high-quality blue-chip stocks.\r\n', 'Actively managed by experienced Fund Managers.\r\n', 18, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(49, 'No back end load.', NULL, 18, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(52, 'Easy to Invest.', 'Selective off-index allocations to generate alpha.\r\n', 19, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(53, 'Diversified portfolio with a focus on high-quality blue-chip stocks.\r\n', 'Actively managed by experienced Fund Managers.\r\n', 19, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(54, 'No back end load.', NULL, 19, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(57, 'Easy to Invest.', 'Selective off-index allocations to generate alpha.\r\n', 20, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(58, 'Diversified portfolio with a focus on high-quality blue-chip stocks.\r\n', 'Actively managed by experienced Fund Managers.\r\n', 20, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(59, 'No back end load.', NULL, 20, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(62, 'Easy to Invest.', 'Up to 30% exposure in listed stocks.\r\n', 21, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(63, 'Up to 30% exposure in listed stocks', 'No back end load.', 21, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(64, 'Diversified into money market/fixed income and equities asset classes', 'Actively managed by experienced Fund Managers.', 21, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(68, 'Easy to Invest.', 'Time redeemable', 22, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(69, 'Safe Investment.', 'No back end load.\r\n', 22, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(70, 'Better Returns than Money Market & Fixed \r\nIncome Funds.', 'Up to 70% exposure in listed stocks.\r\n', 22, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(71, NULL, 'Actively managed by experienced Fund Managers.\r\n', 22, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(74, NULL, NULL, 23, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(75, 'Actively managed by experienced Fund Managers', NULL, 23, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(76, 'Easy to Invest.', 'Diversified into defensive (money market/fixed income) and aggressive (equities) assets classes.', 23, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(77, 'Easy to Invest.', 'Diversified into defensive (money market/fixed income) and aggressive (equities) assets classes.', 24, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(78, 'Actively managed by experienced Fund Managers.', NULL, 24, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(79, NULL, NULL, 24, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(80, 'Invest as per the investor’s risk appetite.', 'No Back End Load', 25, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(81, 'Competitive Returns.', 'Professional Management.\r\n', 25, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(82, 'Tax Credit.', 'Option to withdraw entire or partial amount 50% free of tax at retirement.\r\n', 25, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(83, 'Invest as per the investor’s risk appetite.', 'No Back End Load', 26, '2018-07-07 11:47:22', '2018-07-07 11:47:22'),
	(84, 'Competitive Returns.', 'Professional Management.\r\n', 26, '2018-07-09 21:08:55', '2018-07-09 21:08:55'),
	(85, 'Tax Credit.', 'Option to withdraw entire or partial amount 50% free of tax at retirement.', 26, '2018-07-09 21:08:55', '2018-07-09 21:08:55');
/*!40000 ALTER TABLE `features_benefits` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.fi
CREATE TABLE IF NOT EXISTS `fi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fi_k_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_v_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_v_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_v_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_v_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k_5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_v_5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fund_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.fi: ~13 rows (approximately)
/*!40000 ALTER TABLE `fi` DISABLE KEYS */;
REPLACE INTO `fi` (`id`, `fi_k_1`, `fi_v_1`, `fi_k_2`, `fi_v_2`, `fi_k_3`, `fi_v_3`, `fi_k_4`, `fi_v_4`, `fi_k_5`, `fi_v_5`, `fund_id`, `created_at`, `updated_at`) VALUES
	(1, 'Fund Size (PKR Mn)', '20,338', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 1.00% of NAV', 'Back end Load', 'Nil', 10, NULL, NULL),
	(2, 'Fund Size (PKR Mn)', '5,683', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 1.00%', 'Back end Load', 'Nil', 11, NULL, NULL),
	(3, 'Fund Size (PKR Mn)', '1,985', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 2.00%', 'Back end Load', 'Nil', 12, NULL, NULL),
	(4, 'Fund Size (PKR Mn)', '12,017', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 1.00%', 'Back end Load', 'Nil', 13, NULL, NULL),
	(5, 'Fund Size (PKR Mn)', '1,523', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '500', 'Front end Load', 'Up to 1.50%', 'Back end Load', 'Nil', 14, NULL, NULL),
	(6, 'Fund Size (PKR Mn)', '3,089', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 2.00%', 'Back end Load', 'Nil', 15, NULL, NULL),
	(7, 'Fund Size (PKR Mn)', '1,998', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 2.50%', 'Back end Load', 'Nil', 16, NULL, NULL),
	(8, 'Fund Size (PKR Mn)', '587', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 2.00%', 'Back end Load', 'Nil', 17, NULL, NULL),
	(9, 'Fund Size (PKR Mn)', '285', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 2.00%', 'Back end Load', 'Nil', 18, NULL, NULL),
	(10, 'Fund Size (PKR Mn)', '439', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 2.00%', 'Back end Load', 'Nil', 19, NULL, NULL),
	(11, 'Fund Size (PKR Mn)', '684', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 2.00%', 'Back end Load', 'Nil', 20, NULL, NULL),
	(12, 'Fund Size (PKR Mn)', '318', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', 'Up to 2.00%', 'Back end Load', 'Nil', 21, NULL, NULL),
	(13, 'Fund Size (PKR Mn)', '211', 'Minimum Investment (PKR)', '1,000', 'Subsequent Investment (PKR)', '1,000', 'Front end Load', '2.00%', 'Back end Load', 'Nil', 22, NULL, NULL);
/*!40000 ALTER TABLE `fi` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.fi1
CREATE TABLE IF NOT EXISTS `fi1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fi_k1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k1v1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k1v2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k1v3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k2v1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k2v2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k2v3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k3v1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k3v2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k3v3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k4v1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k4v2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k4v3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k5v1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k5v2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fi_k5v3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fund_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.fi1: ~4 rows (approximately)
/*!40000 ALTER TABLE `fi1` DISABLE KEYS */;
REPLACE INTO `fi1` (`id`, `fi_k1`, `fi_k1v1`, `fi_k1v2`, `fi_k1v3`, `fi_k2`, `fi_k2v1`, `fi_k2v2`, `fi_k2v3`, `fi_k3`, `fi_k3v1`, `fi_k3v2`, `fi_k3v3`, `fi_k4`, `fi_k4v1`, `fi_k4v2`, `fi_k4v3`, `fi_k5`, `fi_k5v1`, `fi_k5v2`, `fi_k5v3`, `fund_id`, `created_at`, `updated_at`) VALUES
	(1, 'Fund Size (PKR Mn)', '7', '99', NULL, 'Minimum Investment (PKR)', 'Rs. 10,000/-', 'Rs. 10,000/-', NULL, 'Subsequent Investment', NULL, 'Rs. 1000/-', NULL, 'Front end Load', 'Up to 2.00%', 'Up to 2.00%', 'Up to 2.00%', 'Back end Load', 'Nil', 'Nil', 'Nil', 23, NULL, NULL),
	(2, 'Fund Size (PKR Mn)', '54', '61', '-', 'Minimum Investment (PKR)', 'Rs. 10,000/-', 'Rs. 10,000/-', '-', 'Subsequent Investment', 'Rs. 1,000/-', 'Rs. 1,000/-', '-', 'Front end Load', 'Up to 2.00%', 'Up to 2.00%', '-', 'Back end Load', 'Nil', 'Nil', '-', 24, NULL, NULL),
	(3, 'Fund Size (PKR Mn)', '150', '192', '229', 'Minimum Investment (PKR)', 'Rs. 1,000/-', 'Rs. 1,000/-', 'Rs. 1,000/-', 'Subsequent Investment', 'Rs. 1,000/-', 'Rs. 1,000/-', 'Rs. 1,000/-', 'Front end Load', 'Up to 3.00%', 'Up to 3.00%', 'Up to 3.00%', 'Back end Load', 'Nil', 'Nil', 'Nil', 25, NULL, NULL),
	(4, 'Fund Size (PKR Mn)', '53', '76', '152', 'Minimum Investment (PKR)', 'Rs. 1,000/-', 'Rs. 1,000/-', 'Rs. 1,000/-', 'Subsequent Investment', 'Rs. 1,000/-', 'Rs. 1,000/-', 'Rs. 1,000/-', 'Front end Load', 'Up to 3.00%', 'Up to 3.00%', 'Up to 3.00%', 'Back end Load', 'Nil', 'Nil', 'Nil', 26, NULL, NULL);
/*!40000 ALTER TABLE `fi1` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.fields
CREATE TABLE IF NOT EXISTS `fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `investment_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fatca_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.fields: 0 rows
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
REPLACE INTO `fields` (`id`, `form_id`, `customer_details`, `bank_details`, `investment_details`, `other_details`, `fatca_details`, `user_id`, `status`, `created_at`, `updated_at`) VALUES
	(4, 'SA2936', '["cnic_attachment","soi_attachment"]', 'null', '["attachment"]', 'null', 'null', '89', 'unchecked', '2020-06-19 13:36:58', '2020-06-19 13:36:58'),
	(3, 'SA4092', '["cnic_attachment","soi_attachment","zakat_certificate"]', 'null', 'null', 'null', 'null', '89', 'unchecked', '2020-06-19 13:23:26', '2020-06-19 13:23:26'),
	(5, 'SA1799', '["name"]', 'null', 'null', 'null', 'null', '89', 'unchecked', '2020-07-22 17:53:23', '2020-07-22 17:53:23');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.forms
CREATE TABLE IF NOT EXISTS `forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `assigned_to` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.forms: 3 rows
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
REPLACE INTO `forms` (`id`, `form_id`, `channel`, `status`, `customer_id`, `user_id`, `assigned_to`, `created_at`, `updated_at`) VALUES
	(141, 'SA7055', 'SA', 0, 198, 89, 0, '2020-07-01 12:04:15', '2020-07-01 12:04:15'),
	(85, 'SA0468', 'SA', 0, 108, 89, 0, '2020-06-15 10:54:28', '2020-06-15 10:54:28'),
	(86, 'SA0474', 'SA', 0, 108, 89, 0, '2020-06-15 10:54:34', '2020-06-15 10:54:34'),
	(87, 'SA0487', 'SA', 0, 111, 89, 0, '2020-06-15 10:54:47', '2020-06-15 10:54:47'),
	(88, 'SA0504', 'SA', 0, 112, 89, 0, '2020-06-15 10:55:04', '2020-06-15 10:55:04'),
	(89, 'SA0504', 'SA', 0, 112, 89, 0, '2020-06-15 10:55:04', '2020-06-15 10:55:04'),
	(90, 'SA0507', 'SA', 0, 112, 89, 0, '2020-06-15 10:55:07', '2020-06-15 10:55:07'),
	(91, 'SA9389', 'SA', 0, 113, 89, 0, '2020-06-16 14:23:09', '2020-06-16 14:23:09'),
	(92, 'SA9397', 'SA', 0, 114, 89, 0, '2020-06-16 14:23:17', '2020-06-16 14:23:17'),
	(93, 'SA1836', 'SA', 0, 115, 89, 0, '2020-06-18 14:17:16', '2020-06-18 14:17:16'),
	(94, 'SA1843', 'SA', 0, 116, 89, 0, '2020-06-18 14:17:23', '2020-06-18 14:17:23'),
	(95, 'SA1848', 'SA', 0, 117, 89, 0, '2020-06-18 14:17:28', '2020-06-18 14:17:28'),
	(96, 'SA2936', 'SA', 1, 118, 89, 0, '2020-06-18 14:35:36', '2020-06-18 14:35:36'),
	(97, 'SA4085', 'SA', 0, 119, 89, 0, '2020-06-18 14:54:45', '2020-06-18 14:54:45'),
	(98, 'SA4092', 'SA', 1, 120, 89, 0, '2020-06-18 14:54:52', '2020-06-18 14:54:52'),
	(99, 'SA4789', 'SA', 0, 121, 89, 0, '2020-06-18 15:06:29', '2020-06-18 15:06:29'),
	(100, 'SA4793', 'SA', 3, 122, 89, 0, '2020-06-18 15:06:33', '2020-06-18 15:06:33'),
	(101, 'SA9116', 'SA', 0, 140, 89, 0, '2020-06-19 14:31:56', '2020-06-19 14:31:56'),
	(102, 'SA9125', 'SA', 0, 141, 89, 0, '2020-06-19 14:32:05', '2020-06-19 14:32:05'),
	(103, 'SA9539', 'SA', 0, 142, 89, 0, '2020-06-19 14:38:59', '2020-06-19 14:38:59'),
	(104, 'SA9541', 'SA', 0, 143, 89, 0, '2020-06-19 14:39:01', '2020-06-19 14:39:01'),
	(105, 'SA9553', 'SA', 0, 144, 89, 0, '2020-06-19 14:39:13', '2020-06-19 14:39:13'),
	(106, 'SA4153', 'SA', 0, 147, 89, 0, '2020-06-22 10:35:53', '2020-06-22 10:35:53'),
	(107, 'SA4157', 'SA', 0, 149, 89, 0, '2020-06-22 10:35:57', '2020-06-22 10:35:57'),
	(108, 'SA0683', 'SA', 0, 151, 89, 0, '2020-06-22 12:24:43', '2020-06-22 12:24:43'),
	(109, 'SA0684', 'SA', 0, 152, 89, 0, '2020-06-22 12:24:44', '2020-06-22 12:24:44'),
	(110, 'SA1534', 'SA', 0, 154, 89, 0, '2020-06-22 12:38:54', '2020-06-22 12:38:54'),
	(111, 'SA1552', 'SA', 0, 155, 89, 0, '2020-06-22 12:39:12', '2020-06-22 12:39:12'),
	(112, 'SA3143', 'SA', 0, 157, 89, 0, '2020-06-22 13:05:43', '2020-06-22 13:05:43'),
	(113, 'SA3899', 'SA', 0, 160, 89, 0, '2020-06-22 13:18:19', '2020-06-22 13:18:19'),
	(114, 'SA1859', 'SA', 0, 161, 89, 0, '2020-06-22 15:30:59', '2020-06-22 15:30:59'),
	(115, 'SA1864', 'SA', 0, 162, 89, 0, '2020-06-22 15:31:04', '2020-06-22 15:31:04'),
	(116, 'SA1867', 'SA', 0, 163, 89, 0, '2020-06-22 15:31:07', '2020-06-22 15:31:07'),
	(117, 'SA2085', 'SA', 0, 164, 89, 0, '2020-06-22 15:34:45', '2020-06-22 15:34:45'),
	(118, 'SA9085', 'SA', 0, 169, 89, 0, '2020-06-23 10:11:25', '2020-06-23 10:11:25'),
	(119, 'SA9090', 'SA', 0, 170, 89, 0, '2020-06-23 10:11:30', '2020-06-23 10:11:30'),
	(120, 'SA9094', 'SA', 0, 171, 89, 0, '2020-06-23 10:11:34', '2020-06-23 10:11:34'),
	(121, 'SA1091', 'SA', 0, 172, 89, 0, '2020-06-23 10:44:51', '2020-06-23 10:44:51'),
	(122, 'SA1095', 'SA', 0, 173, 89, 0, '2020-06-23 10:44:55', '2020-06-23 10:44:55'),
	(123, 'SA8671', 'SA', 0, 175, 89, 0, '2020-06-23 12:51:11', '2020-06-23 12:51:11'),
	(124, 'SA4660', 'SA', 0, 178, 89, 0, '2020-06-24 12:44:20', '2020-06-24 12:44:20'),
	(125, 'SA4662', 'SA', 0, 179, 89, 0, '2020-06-24 12:44:22', '2020-06-24 12:44:22'),
	(126, 'SA0905', 'SA', 0, 181, 89, 0, '2020-06-25 15:28:25', '2020-06-25 15:28:25'),
	(127, 'SA0911', 'SA', 0, 182, 89, 0, '2020-06-25 15:28:31', '2020-06-25 15:28:31'),
	(128, 'SA1354', 'SA', 0, 183, 89, 0, '2020-06-25 15:35:54', '2020-06-25 15:35:54'),
	(129, 'SA1360', 'SA', 0, 184, 89, 0, '2020-06-25 15:36:00', '2020-06-25 15:36:00'),
	(130, 'SA2237', 'SA', 0, 185, 89, 0, '2020-06-25 15:50:37', '2020-06-25 15:50:37'),
	(131, 'SA3173', 'SA', 0, 186, 89, 0, '2020-06-25 16:06:13', '2020-06-25 16:06:13'),
	(132, 'SA3180', 'SA', 0, 188, 89, 0, '2020-06-26 11:33:00', '2020-06-26 11:33:00'),
	(133, 'SA3188', 'SA', 0, 189, 89, 0, '2020-06-26 11:33:08', '2020-06-26 11:33:08'),
	(134, 'SA3211', 'SA', 0, 192, 89, 0, '2020-06-26 11:33:31', '2020-06-26 11:33:31'),
	(135, 'SA3211', 'SA', 0, 192, 89, 0, '2020-06-26 11:33:31', '2020-06-26 11:33:31'),
	(136, 'SA3211', 'SA', 0, 192, 89, 0, '2020-06-26 11:33:31', '2020-06-26 11:33:31'),
	(137, 'SA5152', 'SA', 0, 194, 89, 0, '2020-07-01 11:32:32', '2020-07-01 11:32:32'),
	(138, 'SA5152', 'SA', 0, 194, 89, 0, '2020-07-01 11:32:32', '2020-07-01 11:32:32'),
	(139, 'SA6024', 'SA', 0, 195, 89, 0, '2020-07-01 11:47:04', '2020-07-01 11:47:04'),
	(140, 'SA7051', 'SA', 0, 197, 89, 0, '2020-07-01 12:04:11', '2020-07-01 12:04:11'),
	(82, 'SA1795', 'SA', 0, 100, 89, 0, '2020-05-20 13:03:15', '2020-05-20 13:03:15'),
	(83, 'SA1798', 'SA', 0, 101, 89, 0, '2020-05-20 13:03:18', '2020-05-20 13:03:18'),
	(84, 'SA1799', 'SA', 1, 102, 89, 0, '2020-05-20 13:03:19', '2020-05-20 13:03:19'),
	(142, 'SA6292', 'SA', 0, 200, 89, 0, '2020-07-01 14:38:12', '2020-07-01 14:38:12'),
	(143, 'SA6315', 'SA', 0, 201, 89, 0, '2020-07-01 14:38:35', '2020-07-01 14:38:35'),
	(144, 'SA0865', 'SA', 0, 202, 89, 0, '2020-07-07 13:34:25', '2020-07-07 13:34:25'),
	(145, 'SA5806', 'SA', 0, 203, 89, 0, '2020-07-20 16:50:06', '2020-07-20 16:50:06'),
	(146, 'SA5811', 'SA', 0, 204, 89, 0, '2020-07-20 16:50:11', '2020-07-20 16:50:11'),
	(147, 'Web7226', 'Web', 0, 208, 0, 0, '2020-07-29 15:07:06', '2020-07-29 15:07:06'),
	(148, 'Web7232', 'Web', 0, 209, 0, 0, '2020-07-29 15:07:12', '2020-07-29 15:07:12'),
	(149, 'Web7398', 'Web', 0, 210, 0, 0, '2020-07-29 15:09:58', '2020-07-29 15:09:58'),
	(150, 'Web7404', 'Web', 0, 211, 0, 0, '2020-07-29 15:10:04', '2020-07-29 15:10:04'),
	(151, 'SA3303', 'SA', 0, 213, 101, 0, '2020-08-20 16:35:03', '2020-08-20 16:35:03'),
	(152, 'SA8538', 'SA', 0, 214, 101, 0, '2020-08-24 16:28:58', '2020-08-24 16:28:58'),
	(153, 'SA4513', 'SA', 0, 215, 101, 0, '2020-08-27 10:01:53', '2020-08-27 10:01:53'),
	(154, 'SA4514', 'SA', 0, 216, 101, 0, '2020-08-27 10:01:54', '2020-08-27 10:01:54'),
	(155, 'SA3457', 'SA', 0, 218, 101, 0, '2020-08-31 13:44:17', '2020-08-31 13:44:17'),
	(156, 'SA3666', 'SA', 0, 220, 101, 0, '2020-08-31 13:47:46', '2020-08-31 13:47:46'),
	(157, 'SA3883', 'SA', 0, 221, 101, 0, '2020-08-31 13:51:23', '2020-08-31 13:51:23');
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.fr
CREATE TABLE IF NOT EXISTS `fr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `k1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k1v1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k1v2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k1v3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k1v4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k2v1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k2v2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k2v3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k2v4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k3v1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k3v2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k3v3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `k3v4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fund_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.fr: ~15 rows (approximately)
/*!40000 ALTER TABLE `fr` DISABLE KEYS */;
REPLACE INTO `fr` (`id`, `k1`, `k1v1`, `k1v2`, `k1v3`, `k1v4`, `k2`, `k2v1`, `k2v2`, `k2v3`, `k2v4`, `k3`, `k3v1`, `k3v2`, `k3v3`, `k3v4`, `fund_id`, `created_at`, `updated_at`) VALUES
	(1, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '6.69', '7.64', '11.03', '11.35', 'Benchmark %', '6.76', '7.72', '9.60', '10.05', 10, NULL, NULL),
	(2, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '6.27', '6.96', '9.00', '9.49', 'Benchmark %', '3.72', '4.41', '4.96', '5.03', 11, NULL, NULL),
	(3, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '4.18', '5.15', '7.64', '8.27', 'Benchmark %', '4.99', '5.82', '6.24', '6.32', 12, NULL, NULL),
	(4, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '6.41', '7.17', '10.42', '10.81', 'Benchmark %', '6.76', '7.72', '9.60', '10.05', 13, NULL, NULL),
	(5, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '0.12', '2.01', '12.41', '12.63', 'Benchmark %', '6.81', '7.50', '9.59', '10.16', 14, NULL, NULL),
	(6, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '1.75', '1.79', '16.64', '15.59', 'Benchmark %', '6.61', '7.35', '9.44', '10.01', 15, NULL, NULL),
	(7, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '13.37', '10.68', '-10.67', '-8.15', 'Benchmark %', '14.85', '14.06', '-8.68', '-6.27', 16, NULL, NULL),
	(8, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '16.61', '17.98', '1.77', '4.21', 'Benchmark %', '14.05', '15.09', '-5.70', '-3.62', 17, NULL, NULL),
	(9, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '12.98', '13.40', '-6.75', '-5.09', 'Benchmark %', '14.75', '13.65', '-5.91', '-4.43', 18, NULL, NULL),
	(10, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '13.05', '12.71', '-5.86', '-3.96', 'Benchmark %', '14.75', '13.65', '-5.91', '-4.43', 19, NULL, NULL),
	(11, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '10.10', '10.27', '-16.52', '-15.74', 'Benchmark %', '14.85', '14.06', '-8.68', '-6.27', 20, NULL, NULL),
	(12, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '3.83', '3.40', '-0.58', '0.64', 'Benchmark %', '4.30', '4.65', '0.99', '1.85', 21, NULL, NULL),
	(13, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYTD*', 'Return %', '8.33', '7.54', '-6.53', '-4.45', 'Benchmark %', '9.11', '10.14', '-1.20', '0.69', 22, NULL, NULL),
	(16, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYDT*', 'Return %', '1.30', '3.44', '2.64', '3.44', 'Benchmark %', '1.50', '3.49', '3.14', '3.49', 25, NULL, NULL),
	(17, 'Tenure', '30 Days', '90 Days', '180 Days', 'CYDT*', 'Return %', '3.38', '8.11', '5.77', '4.35', 'Benchmark %', '3.28', '7.71', '5.34', '7.71', 26, NULL, NULL);
/*!40000 ALTER TABLE `fr` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.fr1
CREATE TABLE IF NOT EXISTS `fr1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fr1_v1` varchar(191) DEFAULT NULL,
  `fr1_v2` varchar(191) DEFAULT NULL,
  `fr1_v3` varchar(191) DEFAULT NULL,
  `fr1_v4` varchar(191) DEFAULT NULL,
  `fund_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.fr1: ~7 rows (approximately)
/*!40000 ALTER TABLE `fr1` DISABLE KEYS */;
REPLACE INTO `fr1` (`id`, `fr1_v1`, `fr1_v2`, `fr1_v3`, `fr1_v4`, `fund_id`) VALUES
	(1, '30 Days', '4.29%', '-6.44%', '14.61%', 25),
	(2, '90 Days', '6.38%', '-0.91%', '13.04%', 25),
	(3, '180 Days', '9.37%', '15.15%', '-6.25%', 25),
	(4, '30 Days', '4.14%', '5.02%', '13.92%', 26),
	(5, '90 Days', '5.27%', '0.18%', '12.47%', 26),
	(6, '180 Days', '6.16%', '4.03%', '-3.90%', 26),
	(7, 'CYTD*', '6.56%', '4.89%', '-2.14%', 26);
/*!40000 ALTER TABLE `fr1` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.funds
CREATE TABLE IF NOT EXISTS `funds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.funds: ~17 rows (approximately)
/*!40000 ALTER TABLE `funds` DISABLE KEYS */;
REPLACE INTO `funds` (`id`, `title`, `created_at`, `updated_at`) VALUES
	(10, 'HBL Cash Fund', NULL, NULL),
	(11, 'HBL Islamic Money Market Fund\r\n', NULL, NULL),
	(12, 'HBL Islamic Income Fund\r\n', NULL, NULL),
	(13, 'HBL Money Market Fund', NULL, NULL),
	(14, 'HBL Income Fund\r\n', NULL, NULL),
	(15, 'HBL Government Securities Fund\r\n', NULL, NULL),
	(16, 'HBL Stock Fund\r\n', NULL, NULL),
	(17, 'HBL Equity Fund', NULL, NULL),
	(18, 'HBL Islamic Equity Fund', NULL, NULL),
	(19, 'HBL Islamic Stock Fund', NULL, NULL),
	(20, 'HBL Energy Fund\r\n', NULL, NULL),
	(21, 'HBL Islamic Asset Allocation Fund', NULL, NULL),
	(22, 'HBL Multi Asset Fund', NULL, NULL),
	(23, 'HBL Islamic Financial Planning Fund\r\n', NULL, NULL),
	(24, 'HBL Financial Planning Fund', NULL, NULL),
	(25, 'HBL Pension Fund', NULL, NULL),
	(26, 'HBL Islamic Pension Fund\r\n', NULL, NULL);
/*!40000 ALTER TABLE `funds` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.hamls
CREATE TABLE IF NOT EXISTS `hamls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b1` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b2` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b3` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b4` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b5` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b6` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f1` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f2` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f3` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f4` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.hamls: ~0 rows (approximately)
/*!40000 ALTER TABLE `hamls` DISABLE KEYS */;
REPLACE INTO `hamls` (`id`, `title`, `b1`, `b2`, `b3`, `b4`, `b5`, `b6`, `f1`, `f2`, `f3`, `f4`, `created_at`, `updated_at`) VALUES
	(1, 'HBL Asset Management Limited', 'PKR.  14.81<br />\r\nBillion  <br />\r\nEquity AUM', '17 <br />\r\nOpen-end  <br />\r\nFunds', 'Total AUMs <br />\r\nPKR.   61.54 <br />\r\nBillion', 'AM2+ <br />\r\nRating <br />\r\nby JCR-VIS', '2 VPS  <br />\r\nSchemes', '6th Largest <br />\r\n AMC <br />\r\nin  Pakistan', 'HBL Asset Management Limited (HBL AMC) is a wholly owned subsidiary of HBL, the largest commercial bank in Pakistan.', 'With a nationwide footprint of retail and corporate clients, HBL AMC is one of the largest private fund management company in the country. We offer both conventional and Shariah-compliant investment products.', 'During the year 2016, HBL AMC acquired PICIC Asset Management Company Limited which has subsequently merged into HBL AMC. The acquisition has increased our product suite to 19 mutual fund schemes and plans.', 'HBL Asset Management is rated AM2+ by JCR-VIS.', NULL, NULL);
/*!40000 ALTER TABLE `hamls` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.iimf
CREATE TABLE IF NOT EXISTS `iimf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sf` varchar(3000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f3` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f4` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f5` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f6` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f7` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.iimf: ~0 rows (approximately)
/*!40000 ALTER TABLE `iimf` DISABLE KEYS */;
REPLACE INTO `iimf` (`id`, `title`, `sh`, `sf`, `f1`, `f2`, `f3`, `f4`, `f5`, `f6`, `f7`, `created_at`, `updated_at`) VALUES
	(1, 'ADVANTAGES OF INVESTING IN MUTUAL FUNDS', 'ADVANTAGES OF INVESTING IN MUTUAL FUNDS', 'Mutual funds are an easy, convenient and affordable way of gaining access to capital markets. Each investor has a stake in the assets and earnings of the fund in proportion to the amount of their investments. The benefits of mutual funds include:', 'Professional Management', 'Tax Efficient Way to Save', 'Diversification', 'Liquidity', 'Reduction of transaction costs', 'Convenience', 'Time', NULL, NULL);
/*!40000 ALTER TABLE `iimf` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.investment_avenues
CREATE TABLE IF NOT EXISTS `investment_avenues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ai_key` varchar(191) DEFAULT NULL,
  `fund_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.investment_avenues: ~83 rows (approximately)
/*!40000 ALTER TABLE `investment_avenues` DISABLE KEYS */;
REPLACE INTO `investment_avenues` (`id`, `ai_key`, `fund_id`, `created_at`, `updated_at`) VALUES
	(1, 'Cash', 10, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(2, 'Placements with Banks & DFIs', 10, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(3, 'T-Bills', 10, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(4, 'Commercial Paper', 10, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(5, 'Other including Receivables', 10, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(12, 'Cash	', 11, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(13, 'Commercial Paper', 11, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(14, 'Other including Receivables', 11, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(16, 'Cash	', 12, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(17, 'Commercial Paper', 12, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(18, 'Other including Receivables', 12, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(19, 'TFCs/ Sukuks', 12, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(21, 'Placement with Banks and DFI', 12, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(23, 'Cash	', 13, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(24, 'Placement with Banks and DFIs', 13, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(25, 'T-Bills', 13, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(28, 'Other including Receivables', 13, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(30, 'Cash', 14, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(33, 'Other including Receivables', 14, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(36, 'TFCs/ Sukuks', 14, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(37, 'Cash', 15, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(41, 'Other including Receivables', 15, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(42, 'PIBs', 15, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(44, 'Commercial Paper', 15, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(47, 'Cash', 16, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(49, 'Other including Receivables', 16, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(50, 'Stock/Equities', 16, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(51, 'Cash', 17, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(52, 'Other including receivables', 17, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(53, 'Stock/Equities', 17, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(54, 'Cash', 18, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(55, 'Other including Receivables', 18, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(56, 'Stock/Equities', 18, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(57, 'Cash', 19, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(58, 'Other including Receivables', 19, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(59, 'Stock/Equities', 19, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(60, 'Cash', 20, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(61, 'Other including Receivables', 20, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(62, 'Stock/Equities', 20, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(63, 'Cash	', 21, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(64, 'Other including Receivables', 21, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(65, 'Stock/Equities', 21, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(66, 'Commercial Paper', 21, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(67, 'TFCs/Sukuks', 21, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(68, 'Cash', 22, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(71, 'TFCs / Sukuks', 22, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(72, 'Other including Receivables', 22, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(74, 'Stock/Equities', 22, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(76, 'Cash', 23, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(77, 'Other including Receivables', 23, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(78, 'Equity Funds', 23, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(79, 'Fixed Income Funds', 23, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(81, 'Cash', 24, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(82, 'Equity Funds', 24, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(83, 'Cash', 25, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(85, 'T-Bills', 25, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(86, 'Commercial Paper', 25, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(87, 'PIBs', 25, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(88, 'Other including Receivables', 25, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(89, 'TFCs/ Sukuks', 25, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(90, 'Stock/Equities', 25, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(92, 'Cash', 26, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(93, 'Placement with Banks and DFIs', 26, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(94, 'Other including Receivables', 26, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(95, 'GoP Ijara Sukuks', 26, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(96, 'Cash', 26, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(97, 'Stock / Equities', 26, '2018-07-15 09:29:33', '2018-07-15 09:29:33'),
	(98, 'Fixed Income Funds', 24, '2018-07-20 16:02:56', '2018-07-20 16:02:56'),
	(99, 'Commercial Paper', 26, '2019-01-17 16:01:22', '2019-01-17 16:01:22'),
	(100, 'TFCs/ Sukuks', 26, '2019-01-17 16:01:47', '2019-01-17 16:01:47'),
	(101, 'Others Including Receivables', 24, '2019-01-17 16:21:37', '2019-01-17 16:21:37'),
	(102, 'Placement with Banks & DFI', 21, '2019-01-17 17:03:28', '2019-01-17 17:03:28'),
	(103, 'Commercial Paper', 14, '2019-02-12 10:33:40', '2019-02-12 10:33:40'),
	(104, 'T-Bills', 14, '2019-03-11 10:14:18', '2019-03-11 10:14:18'),
	(105, 'PIBs', 14, '2019-03-11 10:14:26', '2019-03-11 10:14:26'),
	(106, 'TFCs / Sukuks', 15, '2019-03-11 10:22:35', '2019-03-11 10:22:35'),
	(107, 'Placement with Banks & DFI', 25, '2019-03-11 11:40:02', '2019-03-11 11:40:02'),
	(108, 'T-Bills', 15, '2019-05-16 10:14:34', '2019-05-16 10:14:34');
/*!40000 ALTER TABLE `investment_avenues` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.investment_details
CREATE TABLE IF NOT EXISTS `investment_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fund_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_in_words` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `front_end_load` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_mode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instrument_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.investment_details: 3 rows
/*!40000 ALTER TABLE `investment_details` DISABLE KEYS */;
REPLACE INTO `investment_details` (`id`, `fund_name`, `amount`, `amount_in_words`, `front_end_load`, `payment_mode`, `attachment`, `bank_name`, `instrument_number`, `customer_id`, `created_at`, `updated_at`) VALUES
	(59, 'HBL Cash Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', '14.jpg', 'HBL / Konnect', '121212', 106, '2020-06-15 10:54:24', '2020-06-15 10:54:24'),
	(60, 'HBL Cash Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', '14.jpg', 'HBL / Konnect', '121212', 107, '2020-06-15 10:54:28', '2020-06-15 10:54:28'),
	(61, 'HBL Cash Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', '14.jpg', 'HBL / Konnect', '121212', 108, '2020-06-15 10:54:47', '2020-06-15 10:54:47'),
	(62, 'HBL Cash Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', '14.jpg', 'HBL / Konnect', '121212', 109, '2020-06-15 10:54:56', '2020-06-15 10:54:56'),
	(63, 'HBL Cash Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', '14.jpg', 'HBL / Konnect', '121212', 110, '2020-06-15 10:54:58', '2020-06-15 10:54:58'),
	(64, 'HBL Cash Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', '14.jpg', 'HBL / Konnect', '121212', 111, '2020-06-15 10:55:00', '2020-06-15 10:55:00'),
	(65, 'HBL Cash Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', '14.jpg', 'HBL / Konnect', '121212', 112, '2020-06-15 10:55:07', '2020-06-15 10:55:07'),
	(66, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'new-year.png', 'ALBARAKA', '3569874', 113, '2020-06-16 14:23:09', '2020-06-16 14:23:09'),
	(67, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'new-year.png', 'ALBARAKA', '3569874', 114, '2020-06-16 14:23:17', '2020-06-16 14:23:17'),
	(68, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'shahzad cnic.pdf', 'HBL / Konnect', '00000013', 115, '2020-06-18 14:17:15', '2020-06-18 14:17:15'),
	(69, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'shahzad cnic.pdf', 'HBL / Konnect', '00000013', 116, '2020-06-18 14:17:22', '2020-06-18 14:17:22'),
	(70, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'shahzad cnic.pdf', 'HBL / Konnect', '00000013', 117, '2020-06-18 14:17:27', '2020-06-18 14:17:27'),
	(71, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'CNIC Fiaz 11-Jun-2020 13-41-29.pdf', 'HBL / Konnect', '00000007', 118, '2020-06-18 14:35:35', '2020-06-18 14:35:35'),
	(72, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'CNIC Front.jpg', 'ALFALAH', '50565036', 119, '2020-06-18 14:54:43', '2020-06-18 14:54:43'),
	(73, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'CNIC Front.jpg', 'ALFALAH', '50565036', 120, '2020-06-18 14:54:50', '2020-06-18 14:54:50'),
	(74, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'New Doc 2020-03-05 17.09.22.pdf', 'SCB', '12345677', 121, '2020-06-18 15:06:29', '2020-06-18 15:06:29'),
	(75, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'New Doc 2020-03-05 17.09.22.pdf', 'SCB', '12345677', 122, '2020-06-18 15:06:33', '2020-06-18 15:06:33'),
	(76, 'HBL Money Market Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'Realme_Yellow_-f88cca54-4841-45c2-afdb-ea058cb03cfb.jpg', 'HBL / Konnect', '0091638651', 140, '2020-06-19 14:31:54', '2020-06-19 14:31:54'),
	(77, 'HBL Money Market Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'Realme_Yellow_-f88cca54-4841-45c2-afdb-ea058cb03cfb.jpg', 'HBL / Konnect', '0091638651', 141, '2020-06-19 14:32:04', '2020-06-19 14:32:04'),
	(78, 'HBL Money Market Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'IMG-20200619-WA0015.jpg', 'HBL / Konnect', '2819291', 142, '2020-06-19 14:38:58', '2020-06-19 14:38:58'),
	(79, 'HBL Money Market Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'IMG-20200619-WA0015.jpg', 'HBL / Konnect', '2819291', 143, '2020-06-19 14:39:01', '2020-06-19 14:39:01'),
	(80, 'HBL Money Market Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'IMG-20200619-WA0015.jpg', 'HBL / Konnect', '2819291', 144, '2020-06-19 14:39:13', '2020-06-19 14:39:13'),
	(81, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'IMG_20200622_103004.jpg', 'HBL / Konnect', '00000007', 147, '2020-06-22 10:35:51', '2020-06-22 10:35:51'),
	(82, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'IMG_20200622_103004.jpg', 'HBL / Konnect', '00000007', 148, '2020-06-22 10:35:57', '2020-06-22 10:35:57'),
	(83, 'HBL Cash Fund', '11,111', 'Eleven Thousand One Hundred Eleven only', 'N/A', 'Cheque', '7684f482-7f64-4b0e-99a2-afc001ac4b8e.jpg', 'HBL / Konnect', 'TESTING PURPOSE', 151, '2020-06-22 12:24:42', '2020-06-22 12:24:42'),
	(84, 'HBL Cash Fund', '11,111', 'Eleven Thousand One Hundred Eleven only', 'N/A', 'Cheque', '7684f482-7f64-4b0e-99a2-afc001ac4b8e.jpg', 'HBL / Konnect', 'TESTING PURPOSE', 152, '2020-06-22 12:24:43', '2020-06-22 12:24:43'),
	(85, 'HBL Cash Fund', '11,111', 'Eleven Thousand One Hundred Eleven only', 'N/A', 'Cheque', 'IMG_20200622_123019.jpg', 'ABL', 'TEST', 154, '2020-06-22 12:38:52', '2020-06-22 12:38:52'),
	(86, 'HBL Cash Fund', '11,111', 'Eleven Thousand One Hundred Eleven only', 'N/A', 'Cheque', 'IMG_20200622_123019.jpg', 'ABL', 'TEST', 155, '2020-06-22 12:39:12', '2020-06-22 12:39:12'),
	(87, 'HBL Money Market Fund', '5,677', 'Five Thousand Six Hundred Seventy Seven only', 'N/A', 'Cheque', 'Screenshot_2018-05-16-16-50-58.png', 'ADVANS PAK MIRCOFINANCE', '56Y', 157, '2020-06-22 13:05:43', '2020-06-22 13:05:43'),
	(88, 'HBL Cash Fund', '5,759', 'Five Thousand Seven Hundred Fifty Nine only', 'N/A', 'Cheque', 'Screenshot_2018-05-16-16-50-58.png', 'ADVANS PAK MIRCOFINANCE', '6HY6H66IYIHYYUUTU6GUANGZHOU RAJEEV 6HY6H66IYIHYYUUTU6GUANGZHOU RAJEEV KRAMER AHEEL OMIT AHEEL OMAR KRAMER 9GUG AHEEL OMIT AHEEL OMAR KRAMER 9GUG', 160, '2020-06-22 13:18:18', '2020-06-22 13:18:18'),
	(89, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'zakat form ss.JPG', 'HBL / Konnect', '00000', 161, '2020-06-22 15:30:59', '2020-06-22 15:30:59'),
	(90, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'zakat form ss.JPG', 'HBL / Konnect', '00000', 162, '2020-06-22 15:31:04', '2020-06-22 15:31:04'),
	(91, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'zakat form ss.JPG', 'HBL / Konnect', '00000', 163, '2020-06-22 15:31:07', '2020-06-22 15:31:07'),
	(92, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'IMG-20200620-WA0054.jpg', 'SILK Bank', '123456', 164, '2020-06-22 15:34:45', '2020-06-22 15:34:45'),
	(93, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'download.png', 'HBL / Konnect', 'WEWE', 169, '2020-06-23 10:11:24', '2020-06-23 10:11:24'),
	(94, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'download.png', 'HBL / Konnect', 'WEWE', 170, '2020-06-23 10:11:29', '2020-06-23 10:11:29'),
	(95, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'download.png', 'HBL / Konnect', 'WEWE', 171, '2020-06-23 10:11:32', '2020-06-23 10:11:32'),
	(96, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'Captcha Error.jpg', 'ADVANS PAK MIRCOFINANCE', 'A6589659', 172, '2020-06-23 10:44:51', '2020-06-23 10:44:51'),
	(97, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'Captcha Error.jpg', 'ADVANS PAK MIRCOFINANCE', 'A6589659', 173, '2020-06-23 10:44:55', '2020-06-23 10:44:55'),
	(98, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'ID CARD.jpg', 'HBL / Konnect', '63636363636', 174, '2020-06-23 12:51:10', '2020-06-23 12:51:10'),
	(99, 'HBL Money Market Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', 'HBL Tax Rebate Flyer Layout 05 2020 1.jpg', 'ALBARAKA', '65656588', 178, '2020-06-24 12:44:19', '2020-06-24 12:44:19'),
	(100, 'HBL Money Market Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', 'HBL Tax Rebate Flyer Layout 05 2020 1.jpg', 'ALBARAKA', '65656588', 179, '2020-06-24 12:44:21', '2020-06-24 12:44:21'),
	(101, 'HBL Islamic Money Market Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', 'Payslip Oct.pdf', 'HBL / Konnect', '00000021', 181, '2020-06-25 15:28:24', '2020-06-25 15:28:24'),
	(102, 'HBL Islamic Money Market Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', 'Payslip Oct.pdf', 'HBL / Konnect', '00000021', 182, '2020-06-25 15:28:30', '2020-06-25 15:28:30'),
	(103, 'HBL Islamic Money Market Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', 'cheque copy.pdf', 'HBL / Konnect', '00000012', 183, '2020-06-25 15:35:53', '2020-06-25 15:35:53'),
	(104, 'HBL Islamic Money Market Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', 'cheque copy.pdf', 'HBL / Konnect', '00000012', 184, '2020-06-25 15:35:59', '2020-06-25 15:35:59'),
	(105, 'HBL Islamic Money Market Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', '3a481311626a3ade25060327c9724d18.jpg', 'JS BANK', '991001', 185, '2020-06-25 15:50:37', '2020-06-25 15:50:37'),
	(106, 'HBL Cash Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', '3a481311626a3ade25060327c9724d18.jpg', 'ALFALAH', '770001', 186, '2020-06-25 16:06:12', '2020-06-25 16:06:12'),
	(56, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'HBL AMC 2.jfif', 'HBL / Konnect', '3255698', 100, '2020-05-20 13:03:14', '2020-05-20 13:03:14'),
	(57, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'HBL AMC 2.jfif', 'HBL / Konnect', '3255698', 101, '2020-05-20 13:03:17', '2020-05-20 13:03:17'),
	(58, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'HBL AMC 2.jfif', 'HBL / Konnect', '3255698', 102, '2020-05-20 13:03:18', '2020-05-20 13:03:18'),
	(107, 'HBL Cash Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'Nosheen Ashraf.JPG', 'HBL / Konnect', '0101010', 188, '2020-06-26 11:33:00', '2020-06-26 11:33:00'),
	(108, 'HBL Cash Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'Nosheen Ashraf.JPG', 'HBL / Konnect', '0101010', 189, '2020-06-26 11:33:07', '2020-06-26 11:33:07'),
	(109, 'HBL Cash Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'Nosheen Ashraf.JPG', 'HBL / Konnect', '0101010', 191, '2020-06-26 11:33:30', '2020-06-26 11:33:30'),
	(110, 'HBL Cash Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'Nosheen Ashraf.JPG', 'HBL / Konnect', '0101010', 191, '2020-06-26 11:33:30', '2020-06-26 11:33:30'),
	(111, 'HBL Cash Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'Nosheen Ashraf.JPG', 'HBL / Konnect', '0101010', 192, '2020-06-26 11:33:31', '2020-06-26 11:33:31'),
	(112, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'Abdul Sami Cheque.PNG', 'HBL / Konnect', '1', 194, '2020-07-01 11:32:31', '2020-07-01 11:32:31'),
	(113, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'Abdul Sami Cheque.PNG', 'HBL / Konnect', '1', 194, '2020-07-01 11:32:32', '2020-07-01 11:32:32'),
	(114, 'HBL Cash Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', '55EE0040-E247-45EB-A9AD-72C9C9B8AD62.png', 'HBL / Konnect', '6288363', 195, '2020-07-01 11:47:03', '2020-07-01 11:47:03'),
	(115, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'chq investment.jpg', 'FAYSAL BANK', '0000000082', 197, '2020-07-01 12:04:11', '2020-07-01 12:04:11'),
	(116, 'HBL Cash Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'chq investment.jpg', 'FAYSAL BANK', '0000000082', 198, '2020-07-01 12:04:15', '2020-07-01 12:04:15'),
	(117, 'HBL Money Market Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'chq.pdf', 'HBL / Konnect', '123456', 199, '2020-07-01 14:38:09', '2020-07-01 14:38:09'),
	(118, 'HBL Money Market Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'chq.pdf', 'HBL / Konnect', '123456', 200, '2020-07-01 14:38:19', '2020-07-01 14:38:19'),
	(119, 'HBL Money Market Fund', '1,000', 'One Thousand only', 'N/A', 'Cheque', 'chq.pdf', 'HBL / Konnect', '123456', 201, '2020-07-01 14:38:33', '2020-07-01 14:38:33'),
	(120, 'HBL Cash Fund', '1,500', 'One Thousand Five Hundred only', 'N/A', 'Cheque', 'Lilly-takes-to-continuous-manufacturing-with-40m-Irish-investment.jpg', 'ABL', '568999', 202, '2020-07-07 13:34:25', '2020-07-07 13:34:25'),
	(121, 'HBL Cash Fund', '1,500', 'One Thousand Five Hundred only', 'N/A', 'Cheque', 'HBL AMC 2.jfif', 'ABL', '6589965', 203, '2020-07-20 16:50:06', '2020-07-20 16:50:06'),
	(122, 'HBL Cash Fund', '1,500', 'One Thousand Five Hundred only', 'N/A', 'Cheque', 'HBL AMC 2.jfif', 'ABL', '6589965', 204, '2020-07-20 16:50:11', '2020-07-20 16:50:11'),
	(123, 'HBL Cash Fund', '12,212', 'Twelve Thousand Two Hundred Twelve only', 'N/A', 'Cheque', '41KeFBGCG1L.jpg', '1', 'TESTER', 208, '2020-07-29 15:07:05', '2020-07-29 15:07:05'),
	(124, 'HBL Cash Fund', '12,212', 'Twelve Thousand Two Hundred Twelve only', 'N/A', 'Cheque', '41KeFBGCG1L.jpg', '1', 'TESTER', 209, '2020-07-29 15:07:12', '2020-07-29 15:07:12'),
	(125, 'HBL Cash Fund', '1,234', 'One Thousand Two Hundred Thirty Four only', 'N/A', 'Cheque', '41KeFBGCG1L.jpg', '1', 'TESTER', 210, '2020-07-29 15:09:57', '2020-07-29 15:09:57'),
	(126, 'HBL Cash Fund', '1,234', 'One Thousand Two Hundred Thirty Four only', 'N/A', 'Cheque', '41KeFBGCG1L.jpg', '1', 'TESTER', 211, '2020-07-29 15:10:04', '2020-07-29 15:10:04'),
	(127, 'HBL Cash Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'services_desk.jpg', '2|ABL', '123456', 213, '2020-08-20 16:35:03', '2020-08-20 16:35:03'),
	(128, 'HBL Cash Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'AMC-VPS-300x250b.jpg', '2|ABL', '5656565656', 214, '2020-08-24 16:28:58', '2020-08-24 16:28:58'),
	(129, 'HBL Money Market Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'HBL AM VPS Post 3.jpg', '4|BAHL', '565656565', 215, '2020-08-27 10:01:52', '2020-08-27 10:01:52'),
	(130, 'HBL Money Market Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'HBL AM VPS Post 3.jpg', '4|BAHL', '565656565', 216, '2020-08-27 10:01:54', '2020-08-27 10:01:54'),
	(131, 'HBL Money Market Fund', '25,000', 'Twenty Five Thousand only', 'N/A', 'Cheque', 'Logo Green.bmp', '14|HBL', '9859584', 218, '2020-08-31 13:44:17', '2020-08-31 13:44:17'),
	(132, 'HBL Money Market Fund', '10,000', 'Ten Thousand only', 'N/A', 'Cheque', 'Logo (White).bmp', '2|ABL', '963852', 220, '2020-08-31 13:47:46', '2020-08-31 13:47:46'),
	(133, 'HBL Islamic Money Market Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'Logo Green.bmp', '2|ABL', '874587', 221, '2020-08-31 13:51:23', '2020-08-31 13:51:23'),
	(134, 'HBL Islamic Money Market Fund', '5,000', 'Five Thousand only', 'N/A', 'Cheque', 'Logo Green.bmp', '2|ABL', '874587', 222, '2020-08-31 13:51:27', '2020-08-31 13:51:27');
/*!40000 ALTER TABLE `investment_details` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.lead
CREATE TABLE IF NOT EXISTS `lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seller_email` varchar(191) NOT NULL,
  `client_name` varchar(191) DEFAULT NULL,
  `client_email` varchar(191) DEFAULT NULL,
  `client_number` varchar(191) DEFAULT NULL,
  `client_cnic` varchar(255) NOT NULL,
  `location` varchar(191) DEFAULT NULL,
  `fund` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.lead: ~0 rows (approximately)
/*!40000 ALTER TABLE `lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.mf
CREATE TABLE IF NOT EXISTS `mf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f1` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f2` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f3` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f4` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.mf: ~0 rows (approximately)
/*!40000 ALTER TABLE `mf` DISABLE KEYS */;
REPLACE INTO `mf` (`id`, `title`, `f1`, `f2`, `f3`, `f4`, `created_at`, `updated_at`) VALUES
	(1, 'What Are Mutual Funds?', 'A mutual fund is an investment vehicle comprising a pool of funds collected from many investors for the purpose of investing in securities such as stocks, bonds, money market instruments, securities, treasury notes and other capital market instruments.', 'All assets of the mutual fund are held by an independent trustee (such as CDC) and the asset management company only serves as a portfolio manager for the mutual fund.', 'Investors who purchase units of a mutual fund are its unit‐holders.', 'Mutual funds distribute 90% of their realized income to its unit‐holders at the time of dividend pay‐out (once every quarter or at times, once a year).', NULL, NULL);
/*!40000 ALTER TABLE `mf` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.migrations: 0 rows
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.other_details
CREATE TABLE IF NOT EXISTS `other_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asf` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dpo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_of_units` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.other_details: 3 rows
/*!40000 ALTER TABLE `other_details` DISABLE KEYS */;
REPLACE INTO `other_details` (`id`, `asf`, `dpo`, `type_of_units`, `customer_id`, `created_at`, `updated_at`) VALUES
	(59, 'Monthly', 'Cash', 'growth', 108, '2020-06-15 10:54:27', '2020-06-15 10:54:27'),
	(60, 'Monthly', 'Cash', 'growth', 108, '2020-06-15 10:54:34', '2020-06-15 10:54:34'),
	(61, 'Monthly', 'Cash', 'growth', 111, '2020-06-15 10:54:47', '2020-06-15 10:54:47'),
	(62, 'Monthly', 'Cash', 'growth', 112, '2020-06-15 10:55:03', '2020-06-15 10:55:03'),
	(63, 'Monthly', 'Cash', 'growth', 112, '2020-06-15 10:55:03', '2020-06-15 10:55:03'),
	(64, 'Monthly', 'Cash', 'growth', 112, '2020-06-15 10:55:07', '2020-06-15 10:55:07'),
	(65, 'Quarterly', 'Cash', 'growth', 113, '2020-06-16 14:23:09', '2020-06-16 14:23:09'),
	(66, 'Quarterly', 'Cash', 'growth', 114, '2020-06-16 14:23:17', '2020-06-16 14:23:17'),
	(67, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 115, '2020-06-18 14:17:16', '2020-06-18 14:17:16'),
	(68, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 116, '2020-06-18 14:17:23', '2020-06-18 14:17:23'),
	(69, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 117, '2020-06-18 14:17:27', '2020-06-18 14:17:27'),
	(70, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 118, '2020-06-18 14:35:35', '2020-06-18 14:35:35'),
	(71, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 119, '2020-06-18 14:54:44', '2020-06-18 14:54:44'),
	(72, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 120, '2020-06-18 14:54:51', '2020-06-18 14:54:51'),
	(73, 'Annually', 'Reinvestment (Net of applicable taxes)', 'growth', 121, '2020-06-18 15:06:29', '2020-06-18 15:06:29'),
	(74, 'Annually', 'Reinvestment (Net of applicable taxes)', 'growth', 122, '2020-06-18 15:06:33', '2020-06-18 15:06:33'),
	(75, 'Quarterly', 'Cash', 'growth', 140, '2020-06-19 14:31:55', '2020-06-19 14:31:55'),
	(76, 'Quarterly', 'Cash', 'growth', 141, '2020-06-19 14:32:05', '2020-06-19 14:32:05'),
	(77, 'Quarterly', 'Cash', 'growth', 142, '2020-06-19 14:38:59', '2020-06-19 14:38:59'),
	(78, 'Quarterly', 'Cash', 'growth', 143, '2020-06-19 14:39:01', '2020-06-19 14:39:01'),
	(79, 'Quarterly', 'Cash', 'growth', 144, '2020-06-19 14:39:13', '2020-06-19 14:39:13'),
	(80, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 147, '2020-06-22 10:35:53', '2020-06-22 10:35:53'),
	(81, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 149, '2020-06-22 10:35:57', '2020-06-22 10:35:57'),
	(82, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 151, '2020-06-22 12:24:42', '2020-06-22 12:24:42'),
	(83, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 152, '2020-06-22 12:24:44', '2020-06-22 12:24:44'),
	(84, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 154, '2020-06-22 12:38:53', '2020-06-22 12:38:53'),
	(85, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 155, '2020-06-22 12:39:12', '2020-06-22 12:39:12'),
	(86, 'Quarterly', 'Cash', 'growth', 157, '2020-06-22 13:05:43', '2020-06-22 13:05:43'),
	(87, 'Do not send', 'Cash', 'growth', 160, '2020-06-22 13:18:19', '2020-06-22 13:18:19'),
	(88, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 161, '2020-06-22 15:30:59', '2020-06-22 15:30:59'),
	(89, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 162, '2020-06-22 15:31:04', '2020-06-22 15:31:04'),
	(90, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 163, '2020-06-22 15:31:07', '2020-06-22 15:31:07'),
	(91, 'Do not send', 'Reinvestment (Net of applicable taxes)', 'growth', 164, '2020-06-22 15:34:45', '2020-06-22 15:34:45'),
	(92, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 169, '2020-06-23 10:11:25', '2020-06-23 10:11:25'),
	(93, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 170, '2020-06-23 10:11:30', '2020-06-23 10:11:30'),
	(94, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 171, '2020-06-23 10:11:33', '2020-06-23 10:11:33'),
	(95, 'Do not send', 'Reinvestment (Net of applicable taxes)', 'growth', 172, '2020-06-23 10:44:51', '2020-06-23 10:44:51'),
	(56, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 100, '2020-05-20 13:03:14', '2020-05-20 13:03:14'),
	(57, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 101, '2020-05-20 13:03:18', '2020-05-20 13:03:18'),
	(58, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 102, '2020-05-20 13:03:18', '2020-05-20 13:03:18'),
	(96, 'Do not send', 'Reinvestment (Net of applicable taxes)', 'growth', 173, '2020-06-23 10:44:55', '2020-06-23 10:44:55'),
	(97, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 175, '2020-06-23 12:51:11', '2020-06-23 12:51:11'),
	(98, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 178, '2020-06-24 12:44:20', '2020-06-24 12:44:20'),
	(99, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 179, '2020-06-24 12:44:21', '2020-06-24 12:44:21'),
	(100, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 181, '2020-06-25 15:28:25', '2020-06-25 15:28:25'),
	(101, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 182, '2020-06-25 15:28:31', '2020-06-25 15:28:31'),
	(102, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 183, '2020-06-25 15:35:53', '2020-06-25 15:35:53'),
	(103, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 184, '2020-06-25 15:35:59', '2020-06-25 15:35:59'),
	(104, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 185, '2020-06-25 15:50:37', '2020-06-25 15:50:37'),
	(105, 'Annually', 'Cash', 'growth', 186, '2020-06-25 16:06:13', '2020-06-25 16:06:13'),
	(106, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 188, '2020-06-26 11:33:00', '2020-06-26 11:33:00'),
	(107, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 189, '2020-06-26 11:33:08', '2020-06-26 11:33:08'),
	(108, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 192, '2020-06-26 11:33:31', '2020-06-26 11:33:31'),
	(109, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 192, '2020-06-26 11:33:31', '2020-06-26 11:33:31'),
	(110, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 192, '2020-06-26 11:33:31', '2020-06-26 11:33:31'),
	(111, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 194, '2020-07-01 11:32:32', '2020-07-01 11:32:32'),
	(112, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 194, '2020-07-01 11:32:32', '2020-07-01 11:32:32'),
	(113, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 195, '2020-07-01 11:47:04', '2020-07-01 11:47:04'),
	(114, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 197, '2020-07-01 12:04:11', '2020-07-01 12:04:11'),
	(115, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 198, '2020-07-01 12:04:15', '2020-07-01 12:04:15'),
	(116, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 200, '2020-07-01 14:38:11', '2020-07-01 14:38:11'),
	(117, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 201, '2020-07-01 14:38:34', '2020-07-01 14:38:34'),
	(118, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 202, '2020-07-07 13:34:25', '2020-07-07 13:34:25'),
	(119, 'Monthly', 'Cash', 'NA', 203, '2020-07-20 16:50:06', '2020-07-20 16:50:06'),
	(120, 'Monthly', 'Cash', 'NA', 204, '2020-07-20 16:50:11', '2020-07-20 16:50:11'),
	(121, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 208, '2020-07-29 15:07:06', '2020-07-29 15:07:06'),
	(122, 'Monthly', 'Reinvestment (Net of applicable taxes)', 'growth', 209, '2020-07-29 15:07:12', '2020-07-29 15:07:12'),
	(123, 'Monthly', 'Cash', 'NA', 210, '2020-07-29 15:09:58', '2020-07-29 15:09:58'),
	(124, 'Monthly', 'Cash', 'NA', 211, '2020-07-29 15:10:04', '2020-07-29 15:10:04'),
	(125, 'Monthly', 'Cash', 'NA', 213, '2020-08-20 16:35:03', '2020-08-20 16:35:03'),
	(126, 'Quarterly', 'Cash', 'NA', 214, '2020-08-24 16:28:58', '2020-08-24 16:28:58'),
	(127, 'Annually', 'Reinvestment (Net of applicable taxes)', 'growth', 215, '2020-08-27 10:01:52', '2020-08-27 10:01:52'),
	(128, 'Annually', 'Reinvestment (Net of applicable taxes)', 'growth', 216, '2020-08-27 10:01:54', '2020-08-27 10:01:54'),
	(129, 'Monthly', 'Cash', 'NA', 218, '2020-08-31 13:44:17', '2020-08-31 13:44:17'),
	(130, 'Quarterly', 'Reinvestment (Net of applicable taxes)', 'growth', 220, '2020-08-31 13:47:46', '2020-08-31 13:47:46'),
	(131, 'Do not send', 'Reinvestment (Net of applicable taxes)', 'growth', 221, '2020-08-31 13:51:23', '2020-08-31 13:51:23');
/*!40000 ALTER TABLE `other_details` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.returns
CREATE TABLE IF NOT EXISTS `returns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.returns: ~0 rows (approximately)
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.risks
CREATE TABLE IF NOT EXISTS `risks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `client_cnic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'empty',
  `location` text COLLATE utf8mb4_unicode_ci,
  `choosen_fund` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `irf` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crf` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decision` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pushed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.risks: ~48 rows (approximately)
/*!40000 ALTER TABLE `risks` DISABLE KEYS */;
REPLACE INTO `risks` (`id`, `client_name`, `client_email`, `client_number`, `client_cnic`, `location`, `choosen_fund`, `irf`, `crf`, `decision`, `user_id`, `created_at`, `updated_at`, `pushed`) VALUES
	(6, 'Fatwasd shamim', 'fawadshamim94@gmail.com', '03088208576', '', NULL, NULL, 'Islamic Income Fund', 'Income Fund', 'I agree I will go with above recommended product', 25, NULL, NULL, 1),
	(7, 'Fatwasd shamim', 'fawadshamim94@gmail.com', '03088208576', '', NULL, NULL, 'Islamic Income Fund', 'Income Fund', 'I agree I will go with above recommended product', 25, NULL, NULL, 1),
	(8, 'Tahir bin yousuf', 'tahir.yousuf@hblasset.com', '03458221919', '', NULL, NULL, NULL, 'FPF Conservative Plan', 'I agree I will go with above recommended product', 22, NULL, NULL, 0),
	(13, 'Muhammad waleed Minhaj', 'waleed.minhaj@hblasset.com', '03452785148', '', NULL, NULL, 'Islamic Asset Allocation Fund', NULL, 'I agree I will go with above recommended product', 33, NULL, NULL, 1),
	(14, 'Muhib', 'muhib.khan@hblasset.com', '03212342269', '', NULL, NULL, 'Islamic Asset Allocation Fund', NULL, 'Or Choose Another Product at My Own Risk', 26, NULL, NULL, 0),
	(15, 'Farhan', 'm.farhan.khan@hotmail.com', '03452338525', '', NULL, NULL, NULL, 'FPF Conservative Plan', 'Or Choose Another Product at My Own Risk', 39, NULL, NULL, 0),
	(17, 'Shahiid ghaffar', 'shahidghaffar20@gmail.com', '03018202112', '', NULL, NULL, NULL, 'FPF Conservative Plan', 'Or Choose Another Product at My Own Risk', 22, NULL, NULL, 0),
	(23, 'Khurram farhan', 'khassan@ploycon.com.pk', '03008483377', '', NULL, NULL, 'Islamic Asset Allocation Fund', 'FPF Conservative Plan', 'I agree I will go with above recommended product', 51, NULL, NULL, 1),
	(29, 'Dr.amjad mamon', 'asmamon4@gmail.com', '03022431345', '', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 23, NULL, NULL, 0),
	(36, 'Shah sadeem ur rehman', 'sadeem_rehman@yahoo.com', '03463507466', '', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 56, NULL, NULL, 0),
	(37, 'Shah sadeem ur rehman', 'sadeem_rehman@yahoo.com', '03463507466', '', NULL, NULL, NULL, NULL, 'I agree I will go with above recommended product', 56, NULL, NULL, 0),
	(43, 'Danish Ali jaffri', 'danish3@gmail.com', '03452104995', '4210163706789', NULL, NULL, 'Islamic Asset Allocation Fund', 'Multi Asset Fund', 'I agree I will go with above recommended product', 56, NULL, NULL, 0),
	(58, 'Jamal zaidi', 'jamal.@jcrvis.com', '03001234567', '4230136934484', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 24, NULL, NULL, 0),
	(59, 'Jamal zaidi', 'jamal.@jcrvis.com', '03001234567', '4230136934484', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 24, NULL, NULL, 0),
	(60, 'Jamal zaidi', 'jamal.@jcrvis.com', '03001234567', '4230136934484', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 24, NULL, NULL, 0),
	(74, 'muhammad irfan', 'muhammad.irfan@hblasset.com', '923017181288', '3310422481573', NULL, NULL, NULL, NULL, 'I agree I will go with above recommended product', 62, '2019-02-13 15:39:43', '2019-02-13 15:39:43', 0),
	(114, 'zahoor ehali', 'zelahi2772@gmail.com', '0300-4588701', '352023-193973-1', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 34, '2019-08-06 11:06:56', '2019-08-06 11:06:56', 1),
	(115, 'saad zaman', 'saad.zaman73@gmail.com', '0344-7770875', '331028-826791-8', NULL, 'Islamic Asset Allocation Fund', 'Islamic Asset Allocation Fund, IFPF Conservative Plan,', 'Multi Asset Fund,', 'I agree I will go with above recommended product', 52, '2019-08-08 18:23:21', '2019-08-08 18:23:21', 1),
	(116, 'Muhammad Haroon Tanweer', 'haronrajpoot_db@gmail.com', '0333-4541659', '3520082008447-3', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 51, '2019-08-09 10:36:48', '2019-08-09 10:36:48', 1),
	(117, 'Muhammad Usman', 'uah@gmail.com', '0301-4494932', '352024-109740-9', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 51, '2019-08-09 10:43:54', '2019-08-09 10:43:54', 1),
	(118, 'Muhammad Usman', 'uah@gmail.com', '0301-4494932', '352024-109740-9', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 51, '2019-08-09 10:44:38', '2019-08-09 10:44:38', 1),
	(119, 'Waqas', 'waqas.hussain239@gmail.com', '0321-4454459', '352023-997865-9', NULL, 'IFPF Conservative Plan', 'Islamic Asset Allocation Fund, IFPF Conservative Plan,', 'Multi Asset Fund,', 'I agree I will go with above recommended product', 70, '2019-08-09 12:11:20', '2019-08-09 12:11:20', 1),
	(120, 'iqrar baig', 'iqrar.baig@hblasset.com', '0315-2353183', '421013-406234-5', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 69, '2019-08-09 19:08:23', '2019-08-09 19:08:23', 0),
	(121, 'sam', 'sam2@gmail.com', '0333-3333333', '412514-245555-5', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 71, '2019-08-09 21:10:18', '2019-08-09 21:10:18', 1),
	(122, 'Shasta shuja', 'shasta.shuja@gmail.com', '0320-0467171', '35202-3882262-0', NULL, 'Islamic Asset Allocation Fund', 'Islamic Asset Allocation Fund, IFPF Conservative Plan,', 'Multi Asset Fund,', 'I agree I will go with above recommended product', 34, '2019-08-16 16:54:47', '2019-08-16 16:54:47', 1),
	(123, 'usman kusar', 'usman.kusar@gmail.com', '0300-8472332', '35202--272516-7', NULL, 'IFPF Conservative Plan', 'Islamic Asset Allocation Fund, IFPF Conservative Plan,', 'Multi Asset Fund,', 'I agree I will go with above recommended product', 34, '2019-08-16 17:03:36', '2019-08-16 17:03:36', 0),
	(124, 'Sajjad Hussain', 'sajjadkhaira@gmail.com', '0300-5554494', '363036-350503-9', NULL, 'Government Securities Fund', 'Islamic Income Fund,', 'Income Fund, Government Securities Fund,', 'I agree I will go with above recommended product', 72, '2019-08-16 17:04:35', '2019-08-16 17:04:35', 0),
	(125, 'kishwar sultana', 'saadzaman73@gmail.com', '0344-7770875', '331000-814838-6', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 52, '2019-08-17 14:56:28', '2019-08-17 14:56:28', 1),
	(126, 'Inayat Hussain', 'inayat.hussain@hblasset.com', '0307-4949680', '425018-865179-7', NULL, 'Islamic Asset Allocation Fund', 'Islamic Asset Allocation Fund, IFPF Conservative Plan,', 'FPF Conservative Plan,', 'I agree I will go with above recommended product', 73, '2019-08-18 15:23:45', '2019-08-18 15:23:45', 0),
	(127, 'Shua hasnain naqvi', 'shoaa.hasnain@ccco.com', '0300-8490522', '363020-420816-5', 'Block D Shah Rukn-e-Alam Colony, Shah Rukn E Alam Housing Scheme, Multan, Multan, Punjab, Pakistan', 'Money Market Fund', 'Islamic Money Market Fund,', 'Money Market Fund, Cash Fund,', 'I agree I will go with above recommended product', 75, '2019-08-19 11:54:52', '2019-08-19 11:54:52', 0),
	(128, 'umer hiyat', 'umer@gmail.com', '0321-4378896', '352022-725164-7', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 34, '2019-08-20 21:05:49', '2019-08-20 21:05:49', 0),
	(129, 'saeed Ahmed Bajwa', 'saeedbajwa2000@yahoo.com', '0333-5103271', '374053-131345-3', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 51, '2019-08-22 09:02:33', '2019-08-22 09:02:33', 1),
	(130, 'saeed Ahmed Bajwa', 'saeedbajwa2000@yahoo.com', '0333-5103271', '374053-131345-3', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 51, '2019-08-22 09:03:46', '2019-08-22 09:03:46', 1),
	(131, 'Muhammad Arsalan Ashraf', 'marsalan.ashraf@hblasset.com', '0321-8944387', '42201--3296730-', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 33, '2019-08-25 19:54:45', '2019-08-25 19:54:45', 0),
	(133, 'Asad Jabbar', 'jabbar.asad@yahoo.com', '+966-5826114', '363025-940220-3', NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 51, '2019-08-26 15:53:42', '2019-08-26 15:53:42', 1),
	(138, 'arslan', 'ranaarslan69@gmail.com', '0300-4694153', '331000-728998-5', '10, Circular Road, Faisalabad, Faisalabad, Punjab, Pakistan', 'FPF Conservative Plan', 'Islamic Asset Allocation Fund, IFPF Conservative Plan,', 'FPF Conservative Plan,', 'I agree I will go with above recommended product', 61, '2019-11-02 16:17:35', '2019-11-02 16:17:35', 0),
	(139, 'Jahanzeb', 'jahanzeb.shahbaz@sngpl.com.pk', '0333-6121149', '363023-144759-9', ', Shah Rukn E Alam Housing Scheme, Multan, Multan, Punjab, Pakistan', 'Government Securities Fund', 'Islamic Income Fund,', 'Income Fund, Government Securities Fund,', 'I agree I will go with above recommended product', 49, '2019-11-07 11:35:45', '2019-11-07 11:35:45', 0),
	(140, 'moiz', 'moiz.juddi@hblasset.com', '03458207558', '4210117883115', 'Plot FL 9/22 Block 16 Gulshan-e-Iqbal, Karachi Karachi East', NULL, NULL, 'Multi Asset Fund', 'Or Choose Another Product at My Own Risk', 89, NULL, NULL, 1),
	(141, 'moiz', 'moiz.juddi@hblasset.com', '03458207558', '4210117883115', 'Plot FL 9/22 Block 16 Gulshan-e-Iqbal, Karachi Karachi East', 'FPF Conservative Plan', NULL, 'FPF Conservative Plan', 'I agree I will go with above recommended product', 89, NULL, NULL, 1),
	(142, 'Moiz', 'moiz.juddi@hblasset.com', '03458207558', '4210117883115', '6 5th Zamzama Street Defence V, Defence Housing Authority Karachi', NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 89, NULL, NULL, 1),
	(143, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 11, NULL, NULL, 0),
	(144, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 11, NULL, NULL, 0),
	(145, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 11, NULL, NULL, 0),
	(146, 'Mir Adil', 'mir.adil@hblasset.com', '03333013010', '4230138981403', 'Plot No. G-19 Block 5 Clifton, Karachi Karachi South', NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 60, NULL, NULL, 0),
	(147, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 11, NULL, NULL, 0),
	(148, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 11, NULL, NULL, 0),
	(149, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 11, NULL, NULL, 0),
	(150, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 11, NULL, NULL, 0),
	(151, 'test ord', 'test@ord.com', '7878-7878787', '878787-878787-8', NULL, 'Multi Asset Fund', 'Islamic Asset Allocation Fund, IFPF Conservative Plan,', 'Multi Asset Fund,', 'I agree I will go with above recommended product', 11, '2020-04-17 15:31:41', '2020-04-17 15:31:41', 0),
	(152, 'test ord', 'test@ord.com', '7878-7878787', '878787-878787-8', NULL, 'IFPF Active Allocation Plan', 'IFPF Active Allocation Plan, IFPF Conservative Plan,', 'FPF Multi Allocation Plan,', 'I agree I will go with above recommended product', 11, '2020-04-17 15:32:13', '2020-04-17 15:32:13', 0),
	(153, 'lubna', 'lubna.ahmed@hblasset.com', '0345-8777637', '423013-693448-4', '129, Syedna Jalal Road, Shabbirabad, Karachi, Karachi City, Sindh, Pakistan', 'Multi Asset Fund', 'Islamic Asset Allocation Fund, IFPF Conservative Plan,', 'Multi Asset Fund,', 'I agree I will go with above recommended product', 99, '2020-04-22 13:38:38', '2020-04-22 13:38:38', 0),
	(154, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Or Choose Another Product at My Own Risk', 11, NULL, NULL, 0),
	(155, 'Omair Inam', 'omairinam@hotmail.com', '923032268074', '42501-0850690-1', '19 Block 5 Clifton, Karachi Karachi South', 'IFPF Conservative Plan', 'IFPF Conservative Plan', NULL, 'Or Choose Another Product at My Own Risk', 101, NULL, NULL, 0);
/*!40000 ALTER TABLE `risks` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.roles: ~5 rows (approximately)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
REPLACE INTO `roles` (`id`, `role`, `role_title`, `created_at`, `updated_at`) VALUES
	(0, 'admin', 'Admin', NULL, NULL),
	(1, 'user', 'Sales', NULL, NULL),
	(2, 'super_admin', 'Super Admin', NULL, NULL),
	(3, 'retail_admin', 'Retail Admin', NULL, NULL),
	(4, 'retail_user', 'Retail User', NULL, NULL),
	(5, 'cbc', 'cbc', NULL, NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.rp_count
CREATE TABLE IF NOT EXISTS `rp_count` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `counts` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.rp_count: ~0 rows (approximately)
/*!40000 ALTER TABLE `rp_count` DISABLE KEYS */;
REPLACE INTO `rp_count` (`id`, `counts`) VALUES
	(1, 206);
/*!40000 ALTER TABLE `rp_count` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.sc_yr
CREATE TABLE IF NOT EXISTS `sc_yr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yr` varchar(191) DEFAULT NULL,
  `chart_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.sc_yr: ~2 rows (approximately)
/*!40000 ALTER TABLE `sc_yr` DISABLE KEYS */;
REPLACE INTO `sc_yr` (`id`, `yr`, `chart_id`) VALUES
	(1, '2015', 1),
	(2, '2015', 2);
/*!40000 ALTER TABLE `sc_yr` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.slides
CREATE TABLE IF NOT EXISTS `slides` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.slides: ~0 rows (approximately)
/*!40000 ALTER TABLE `slides` DISABLE KEYS */;
REPLACE INTO `slides` (`id`, `title`, `content`, `created_at`, `updated_at`) VALUES
	(1, 'Sponsers', '<p>HBL was the first commercial bank to be established in Pakistan in 1947.&nbsp;<br /><br />The Government of Pakistan privatized HBL in 2004 through which AKFED acquired 51% of the Bank\'s shareholding and the management control.&nbsp;<br /><br />Current network is over 1,600 branches and 1,700 ATMs globally and a customer base exceeding eight million relationships.<br />&nbsp;&nbsp;<br />HBL is the Largest bank by:<br />Deposits<br />Balance sheet<br />Capital<br />Profitability&nbsp;<br /><br />With a global presence in over 25 countries spanning across four continents,&nbsp;&nbsp;HBL is also the largest domestic multinational.&nbsp;<br /><br />HBL is rated AAA by JCR-VIS.&nbsp;</p>', NULL, NULL);
/*!40000 ALTER TABLE `slides` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.sponsers
CREATE TABLE IF NOT EXISTS `sponsers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f1` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f2` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f3` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f4` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f5` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f6` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.sponsers: ~0 rows (approximately)
/*!40000 ALTER TABLE `sponsers` DISABLE KEYS */;
REPLACE INTO `sponsers` (`id`, `title`, `f1`, `f2`, `f3`, `f4`, `f5`, `f6`, `created_at`, `updated_at`) VALUES
	(1, 'Sponsor', 'HBL was the first commercial bank to be established in Pakistan in 1947.', 'The Government of Pakistan privatized HBL in 2004 through which AKFED acquired 51% of the Bank\'s shareholding and the management control.', 'Current network is over 1,600 branches and 1,700 ATMs globally and a customer base exceeding eight million relationships.', 'HBL is the Largest bank by: <br />\r\nDeposits <br />\r\nBalance sheet <br />\r\nCapital', 'With a global presence in over 25 countries spanning across four continents,  HBL is also the largest domestic multinational.', 'HBL is rated AAA by JCR-VIS.', NULL, NULL);
/*!40000 ALTER TABLE `sponsers` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.sponsor_chart_1
CREATE TABLE IF NOT EXISTS `sponsor_chart_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sc_1_nums` varchar(500) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `sort_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.sponsor_chart_1: ~50 rows (approximately)
/*!40000 ALTER TABLE `sponsor_chart_1` DISABLE KEYS */;
REPLACE INTO `sponsor_chart_1` (`id`, `sc_1_nums`, `bank_id`, `sort_id`) VALUES
	(23, '1634', 1, 1),
	(24, '1885', 1, 1),
	(25, '1998', 1, 1),
	(32, '2137', 1, 1),
	(33, '2437', 1, 1),
	(34, '1120', 2, 2),
	(35, '1246', 2, 2),
	(36, '1350', 2, 2),
	(37, '1448', 2, 2),
	(38, '1467', 2, 2),
	(39, '706', 3, 3),
	(40, '796', 3, 3),
	(41, '1001', 3, 3),
	(42, '1122', 3, 3),
	(43, '1144', 3, 3),
	(44, '1432', 4, 4),
	(45, '1657', 4, 4),
	(46, '1727', 4, 4),
	(47, '2011', 4, 4),
	(48, '2198', 4, 4),
	(49, '735', 5, 5),
	(50, '805', 5, 5),
	(51, '884', 5, 5),
	(52, '984', 5, 5),
	(53, '1049', 5, 5),
	(60, '35470', 6, 1),
	(61, '31820', 6, 1),
	(62, '7730', 6, 1),
	(63, '11789', 6, 1),
	(64, '15500', 6, 1),
	(65, '25727', 7, 2),
	(66, '27730', 7, 2),
	(67, '25179', 7, 2),
	(68, '15226', 7, 2),
	(69, '19134', 7, 2),
	(70, '25035', 8, 3),
	(71, '22174', 8, 3),
	(72, '22048', 8, 3),
	(73, '20415', 8, 3),
	(74, '23947', 8, 3),
	(75, '19219', 9, 4),
	(76, '22752', 9, 4),
	(77, '23028', 9, 4),
	(78, '20015', 9, 4),
	(79, '15810', 9, 4),
	(80, '15120', 10, 5),
	(81, '14427', 10, 5),
	(82, '12734', 10, 5),
	(83, '12880', 10, 5),
	(84, '14113', 10, 5);
/*!40000 ALTER TABLE `sponsor_chart_1` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.tomf
CREATE TABLE IF NOT EXISTS `tomf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh1` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh1f1` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh1f2` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh2` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh2f1` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh2f2` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh2f3` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh2f4` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh2f5` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh2f6` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh3` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh3f1` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh3f2` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh3f3` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.tomf: ~0 rows (approximately)
/*!40000 ALTER TABLE `tomf` DISABLE KEYS */;
REPLACE INTO `tomf` (`id`, `title`, `sh1`, `sh1f1`, `sh1f2`, `sh2`, `sh2f1`, `sh2f2`, `sh2f3`, `sh2f4`, `sh2f5`, `sh2f6`, `sh3`, `sh3f1`, `sh3f2`, `sh3f3`, `created_at`, `updated_at`) VALUES
	(1, 'Types Of Mutual Funds', 'By Structure', 'Open End Funds: These units are issued and redeemed by the Management Company', 'Closed End Funds: Only traded at the Stock Exchange and are not redeemable', 'By Investment Objective', 'Money Market Funds: Invest in most liquid securities e.g., Bank Deposits, Treasury bills etc.', 'Growth Funds – Equity Funds: Invest in Equity Securities', 'Income Funds / Debt Funds: Invest in longer term Government & Corporate Bonds.', 'Balanced Funds: Invest in both Fixed Income and Equity Securities', 'Asset Allocation Funds: Usually specifies the percentage of investment in equity and Fixed Income Securities.', 'Capital Protected Funds: Guarantees the protection of capital through different methodologies.', 'Special Funds', 'Shariah Compliant Funds:All assets are Shariah Compliant with the approval of Shariah Advisor', 'Sector Specific Funds: Invest only in the sector that is described in offering document', 'Govt. Securities Funds: Invest in Government bonds both short term and long term.', NULL, NULL);
/*!40000 ALTER TABLE `tomf` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.users: ~58 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `role_id`) VALUES
	(11, 'Ahsan Hassan', 'Ahsan.Hassan@hblasset.com', '$2y$10$URd/mAwgY4Q3pfZL7dlkteGx1U.sFWW//8gKcAx9n7z4FBudoLXlK', 'F3YgvtzZz5y8RP2UDLUE59anbtloB3wqUxEhPLg8AgLA4SrdUXPMCrlb1zJA', '2018-07-09 07:50:44', '2018-07-09 07:50:44', 0),
	(15, 'MUstafa Subhani', 'mustafa.subhani@hblasset.com', '$2y$10$GcoEeqmRiftYTCy7nTUxL.tZN4NOXgqkqBCiIE6nJLRiBbHiJwNi6', NULL, '2018-07-23 21:35:08', '2018-07-23 21:35:08', 1),
	(16, 'Mohammad Noman', 'muhammad.noman@hblasset.com', '$2y$10$9kZaz2.kHAXWvrqz6VnI0.LfJfPyIlyyrEB.NqemAgmao8dicRLqO', NULL, '2018-07-23 21:38:15', '2018-07-23 21:38:15', 1),
	(18, 'Tayyab Javed', 'tayyab.javed@hblasset.com', '$2y$10$AY6hL065QmlcgnAH2G/vEu00fRuSwWRe3x6QtzDw7RMLDAtCcEPwq', NULL, '2018-07-23 21:40:15', '2018-07-23 21:40:15', 1),
	(19, 'Sarmad Iqbal', 'sarmad.iqbal@hblasset.com', '$2y$10$Ot5LwxWYUV3hxv4SZXtdBejYTpDquH3OboWzw7JVQbneOq4bz5B5y', NULL, '2018-07-23 21:41:38', '2018-07-23 21:41:38', 1),
	(21, 'Gohar Ayub', 'gohar.ayub@hblasset.com', '$2y$10$cjNzHjSN1bdBTjAJpPKBXOafNkZsbTLKBrlNbEcroh6m3j5rrjrgq', NULL, '2018-07-23 21:42:41', '2018-07-23 21:42:41', 1),
	(22, 'Tahir Bin Yousuf', 'tahir.yousuf@hblasset.com', '$2y$10$.OJKbmrReNJ0FXWbhJdufuxbbpCs./HrhfZbCa1GMuIN4VFg30mmC', NULL, '2018-07-23 21:43:16', '2018-07-23 21:43:16', 1),
	(23, 'Ali Babar Syed', 'babar.syed@hblasset.com', '$2y$10$/jIeV6lrP3.NBCeQVPL0jOsM0KSYXHYOQv/yqpxJV/tRf7LRJMhna', 'HijzFSB7gHZkrIj5N53B4Y9xjns7FpiIGiCjPJATRgQWYdATN172iO0SVNIs', '2018-07-23 21:44:41', '2018-07-23 21:44:41', 1),
	(25, 'Muhib Khan', 'Muhib.khan@hblasset.com', '$2y$10$UTkm7YtE.eF3pRXx4lbox.bhA9UMI624vT3zzb0SA75tqT0fKKfUW', 'FlQ3tKsyYsXxQmZxEQbxwjNWGrQ2GpKzpMPl2krajOU8JIHKzasjoHl9jVpJ', '2018-07-23 21:45:58', '2018-07-23 21:45:58', 1),
	(26, 'Murtaza Jafri', 'murtuza.jafri@hblasset.com', '$2y$10$mfqbIRf7woG7J6q9kh9WT.099vXnUj4kbdvn7KQXSgPbtiIlGKpEm', NULL, '2018-07-23 21:47:03', '2018-07-23 21:47:03', 1),
	(29, 'Meheboob Ali Solangi', 'mehboob.solangi@hblasset.com', '$2y$10$mXS/BclRKgzT/LdsT8PNEebf1S9ymk5.H/3zB8GkJLIiGqG4b3yn2', NULL, '2018-07-23 21:48:48', '2018-07-23 21:48:48', 1),
	(30, 'Raheel Khawer', 'raheel.khawer@hblasset.com', '$2y$10$joM8WfVT1pMfHsbUjIqDjuxo15IqODpt4nxnYDKQK1d3EXPezPKbm', 'KATksVPkSNde0ePmOCpzJaSSKxCtjHAgRlE2CbzazuYt9Ez20sTFw5ai2gWu', '2018-07-23 21:49:43', '2018-07-23 21:49:43', 1),
	(31, 'Mubashir Azhar', 'mubashir.azhar@hblasset.com', '$2y$10$VznDXEQv0RGUAvtbc16qZeTvKHTjiBF67emlaKM3GgRQj880MnpNq', 'WXvmd1TOHrQZAhLKYSy1KHSJCQGjWU3NJogoFAGd3m55nXQmRNjQVg7ylwVg', '2018-07-23 21:50:18', '2018-07-23 21:50:18', 1),
	(33, 'Arsalan Ashraf', 'marsalan.ashraf@hblasset.com', '$2y$10$BP4xFwumcZ2u/6ALRo1UBOhY5lXVCW0uRh/BjtliufVMf6pfhzX1i', 'JECZwrR2AyBGEsCFy0YMrur6wMBCyTzS4gLoNltKnvdjQQZwNPKoXeaAjK7h', '2018-07-23 21:56:02', '2018-07-23 21:56:02', 1),
	(34, 'Muhammad Shafique', 'muhammad.shafique@hblasset.com', '$2y$10$qN/Jp4yoPsBdjnL2llgFP.pEqq0JK0Odi/ENonwe1Ef5CFBKKaSry', NULL, '2018-07-23 21:58:18', '2018-07-23 21:58:18', 1),
	(35, 'Faiq Alam', 'faiq.alam@hblasset.com', '$2y$10$JHI3/WDwDolx.zjlUPPvfeWv2.UwJlvQiG8VJ83cd6Yox/zRAY/ZK', NULL, '2018-07-23 22:03:29', '2018-07-23 22:03:29', 1),
	(36, 'Zainab Mubeen', 'zainab.mubeen@hblasset.com', '$2y$10$TdRSbM42of6BQVEkZT/YOOdgWVIFOHVBXW23FPHlZbuHZS8ngElIy', NULL, '2018-07-23 22:04:02', '2018-07-23 22:04:02', 1),
	(37, 'Jahanzaib Ahmed Siddiqui', 'jahanzaib.siddiqui@hblasset.com', '$2y$10$KHDkHpBiP/PMrLblZxRK3eE8e2hwDpyz0Ao0MaxB8/aGsCmCmnz3m', NULL, '2018-07-23 22:04:56', '2018-07-23 22:04:56', 1),
	(38, 'Shaikh Muhammad Yasir bashir', 'yasir.bashir@hblasset.com', '$2y$10$ST1bBkxmGQkor/LGew8.s.sl65WtozmT6/OkXmQTBNW4EDU/cnz5e', 'cuJ3JjCcMnt2JUEFvXi7OnuNztTfI62nxvBveaLkkQklDdyaLW0pOATdTbCc', '2018-07-23 22:06:08', '2018-07-23 22:06:08', 1),
	(39, 'Muhammad Farhan Khan', 'Mfarhan.khan@hblasset.com', '$2y$10$AWhYtRllBKdC/XCwEEcb9.FcNeHrjjJk1xA0VULxw0tfV1PxejASO', NULL, '2018-07-23 22:07:00', '2018-07-23 22:07:00', 1),
	(41, 'Amjad Hussain Phull', 'amjad.hussain@hblasset.com', '$2y$10$GvIBbqxCZ3QL8.xuwAuMwOb6WSl3hWLKGi9xZ48IZEm9BqVOsxnZO', '4KtbCYAgVLLwIvmqkIjlyvpiOjFlVpVxc4VZJF7gA558DsTzMtU2QlEAff5J', '2018-07-23 22:07:59', '2018-07-23 22:07:59', 1),
	(44, 'Sheeraz Ahmed', 'sheeraz.ahmed@hblasset.com', '$2y$10$0G3OaN88LwAq.A1qj0Th/.e7Ndh6fI2vCXW8ryfgGbHBuFvo/0Wne', 'QmbP8cUYxOExXfIde0Zjkr7U7zc6f6MEndLtgRod26oI46qTfiDEVIKku56M', '2018-07-24 19:38:14', '2018-07-24 19:38:14', 1),
	(47, 'Muhammad Imran', 'muhammad.imran1@hblasset.com', '$2y$10$Nr.52ITQfaeGYu8ZwnPOouCO8.FiZDouKVn2iN/OfVB//lZAUbc.W', NULL, '2018-08-15 18:17:38', '2018-08-15 18:17:38', 1),
	(48, 'Shahzeb Aziz', 'shahzeb.aziz@hblasset.com', '$2y$10$aialkMApczjdGgjkmsrfw.yyfqkhkEraG33ZI8aeo4ULT3/Rkcixa', NULL, '2018-08-15 18:18:51', '2018-08-15 18:18:51', 1),
	(49, 'Fiaz Ahmed Khan', 'fiaz.ahmed@hblasset.com', '$2y$10$4e.2qKoc41ooO8Gpl7F1nuUf60AZiU.2qBoy4s5Kn6Nx6rrx4ODVG', 'DXlIjKb0ouG71uhfOGjSb82rdskyxSL06guuWi18eOKsk39f1oGd6mOruXbA', '2018-08-15 18:19:48', '2018-08-15 18:19:48', 1),
	(50, 'Zeeshan Tahir', 'zeeshan.tahir@hblasset.com', '$2y$10$6pDCgxzKUZ528GoUTOuCFOdC2sFYk3ocdDWd0qovzUl2ksnOqU0dq', NULL, '2018-08-15 18:24:35', '2018-08-15 18:24:35', 1),
	(51, 'Shahzad Ul Haq', 'shahzad.haq@hblasset.com', '$2y$10$fFTh/EKqPTA4ZyhUNNdGtu.HmlIxohG6jle.roaxKczvAK3L7nxTe', NULL, '2018-08-15 18:25:23', '2018-08-15 18:25:23', 1),
	(52, 'Saad Zaman', 'saad.zaman@hblasset.com', '$2y$10$XjGxbIuWyovEPtcE448o5uNrLzd9mGcdcdM0q5k0yhqGIIAqzVGHO', 'JSyidhPMOtIGf7XRRW9kKzgTjFZzkm0YUgYhNyNkyQXKnC5S7YMLc2urWfIM', '2018-08-15 18:26:24', '2018-08-15 18:26:24', 1),
	(53, 'Ali Raza Zaidi', 'ali.raza@hblasset.com', '$2y$10$L7/YTWii/4yrw/GlWIge1.dKcj9seWn6zHJu5wfKFnt.u6JemE3LK', 'nnHG9C1lOQLosFSRi3ia0kkaagRkDBhCf1QUAOhVpCkPtCFNMhn6GmRBWcOc', '2018-08-15 22:09:25', '2018-08-15 22:09:25', 1),
	(54, 'Ali Raza', 'ali.naqvi@hblasset.com', '$2y$10$FXcvPg5VUxIto5yVDvAG9ub1ZT1efVpdcV77nDOvLDFld.wCv2o1C', 'kbEDNsSU8tdeW2FNK80cRsKWjFCqDQEYvvPmCKJ79WYLWUGrUyPVk7Sth2S8', '2018-08-15 22:10:35', '2018-08-15 22:10:35', 1),
	(56, 'Ehtisham Junaidi', 'ehtisham.junaidi@hblasset.com', '$2y$10$jj0hvJDIOEoVPziDpx6l4uz9dLRTDqDOk7nOcL.ABmxuCtQXFeNZW', NULL, '2018-09-04 19:35:49', '2018-09-04 19:35:49', 1),
	(57, 'francis.gill', 'francis.gill@ord.com', '$2y$10$ss28ZzICcK9h5KziiSV9kO4cnb1yvYvcZO3sUHTqkdoXYVWL4/pFG', 'npHxmp8vnoJaE5EzHJRRWdkNLns7CKfkOndVS0T67ErBJyhuxkwraRX9APQ2', '2018-09-05 17:01:58', '2018-09-05 17:01:58', 2),
	(58, 'Imran Tariq', 'imran.tariq@hblasset.com', '$2y$10$nD0ePsk1h1/P4vAwLAVoKeZpZz2cQKab.bSD3THZbi8bhcYXbQyUa', NULL, '2018-09-18 18:27:59', '2018-09-18 18:27:59', 1),
	(59, 'Amir Khan', 'amir.khan@hblasset.com', '$2y$10$c4WD9k2pjon.6t11FsKo9O6qxugXR.cRDeRCXFmf5BauXx.7ZM/ia', 'EkDTmf0Yhz12ShWFd63DPvIpbDl47loWl7BIGKEFVldP2XZeAGl7GWJwwp34', '2018-10-04 06:20:28', '2018-10-04 06:20:28', 1),
	(60, 'omair.inam', 'omair.inam@hblasset.com', '$2y$10$9nhckVnqHLyb014g9TWHPO9qnr2gU2kq1NVXe9CTZgvM5zKV2fAZW', '90u2kB7ycpDCxYmvcBjSR0BGYR6sRWTjsiGBxqrCXnFCTwJGIYWbpijmtrf3', '2018-11-27 07:47:15', '2018-11-27 07:47:15', 2),
	(61, 'Arslan Khalid', 'arslan.khalid@hblasset.com', '$2y$10$PdQ4sGcSUUz8LoeIecWhyeUz73WM6ebHeCiSt3YKKt3lQ51k9qvgO', NULL, '2019-02-12 06:25:46', '2019-02-12 06:25:46', 1),
	(62, 'Muhammad Irfan', 'muhammad.irfan@hblasset.com', '$2y$10$4Lm8S8Mkw.Tc.5DDA/11C.Xq/9cuvTFGrYjh2T09AY3SuUPNcaunW', NULL, '2019-02-12 06:26:34', '2019-02-12 06:26:34', 1),
	(65, 'Sadaf Wajid', 'sadaf.wajid@hblasset.com', '$2y$10$lx5GIjYaN5bgMeqCJwh7tuOu9TieteEtoCjr52wy1jg7We37mdlfK', NULL, '2019-08-09 10:15:20', '2019-08-09 10:15:20', 1),
	(66, 'Sharafat Ali', 'sharafat.ali@hblasset.com', '$2y$10$sxG2gFWBEblQG.2WAcDwWeUhfVQuXrBHJQLJ90ewz3Us7tjbkugq.', NULL, '2019-08-09 10:17:38', '2019-08-09 10:17:38', 1),
	(67, 'Salman Farooqi', 'salman.farooqi@hblasset.com', '$2y$10$LWnl/DGf6Zk8TwMCl3iNXOoiuj34dAV1I2JeL6KUIBoAVCNpGt7Tu', NULL, '2019-08-09 10:51:01', '2019-08-09 10:51:01', 1),
	(68, 'Moonis Ahmed', 'moonis.ahmed@hblasset.com', '$2y$10$geOdkvb0IveoojNMzj8iXeAWK9ZCh7ASedcnMol64HVYAIassjFvS', NULL, '2019-08-09 11:11:15', '2019-08-09 11:11:15', 1),
	(69, 'Mirza Iqrar Baig', 'iqrar.baig@hblasset.com', '$2y$10$qFrEoo6U/EW.qut7HQ93kuJHk9ZkpAgp5YH/o4ytTUkLQZIrMFFMG', NULL, '2019-08-09 11:26:41', '2019-08-09 11:26:41', 1),
	(70, 'Waqas Hussain', 'waqas.hussain@hblasset.com', '$2y$10$Ah8zcY8wzMMvjKoQeGmL9OTwuPQEAbM0yh3IzmUTzWsrXSstr5I2a', NULL, '2019-08-09 11:50:25', '2019-08-09 11:50:25', 1),
	(71, 'Saeem Khan', 'saeem.khan@hblasset.com', '$2y$10$gFHuzNitkrwxSBWCO6l3wucrjEYeq5jd7vNS6tz1BzYcCgLQ8t1BC', NULL, '2019-08-09 12:56:35', '2019-08-09 12:56:35', 1),
	(72, 'Faisal Shabbir', 'faisal.shabbir@hblasset.com', '$2y$10$a7XXZwFV.U9F1s1QB7UT0uH0VOgZi/eTz/ibNWZSEzHoz59LMpYZO', NULL, '2019-08-16 10:17:13', '2019-08-16 10:17:13', 1),
	(73, 'Inayat Hussain', 'inayat.hussain@hblasset.com', '$2y$10$7x0O7X809F6Z4XCEnsh/GeYa0GKEoOVOCXQqRea0akQGbh69WjRXm', NULL, '2019-08-16 10:44:12', '2019-08-16 10:44:12', 1),
	(74, 'Ahsan Nadeem Bhutta', 'ahsan.nadeem@hblasset.com', '$2y$10$xbEBvheI.b3FXXtnLmLHB.AFkSPbu/.HSQdVF.Syjx6TU6K4VpX4.', NULL, '2019-08-16 11:42:57', '2019-08-16 11:42:57', 1),
	(75, 'Ali Ahmed', 'ali.ahmed@hblasset.com', '$2y$10$uVXXAJ8htK1f6n1V6TdPteaNbtoFrd9cjVuyI8V3s5hywmN.EGsNy', NULL, '2019-08-16 14:46:49', '2019-08-16 14:46:49', 1),
	(76, 'Kashif Naveed', 'kashif.naveed@hblasset.com', '$2y$10$jLxMOeTTKF/91NUADS2hQuNM5ctiUM9z22Q9Wgsl2Euo729//78RC', NULL, '2019-08-17 11:15:07', '2019-08-17 11:15:07', 1),
	(77, 'Shahzad Ali', 'shahzad.ali@hblasset.com', '$2y$10$9JOQd5Nr0t3vKH4WIg1HrOTqXHVo8vYyIEdEua3/p7gPKJOXMCZu6', NULL, '2019-08-17 11:17:00', '2019-08-17 11:17:00', 1),
	(78, 'Munaf Panjwani', 'munaf.panjwani@hblasset.com', '$2y$10$iqoj9ccC9ksAWaMdcl1ckePFe3LHcFfRpPUsc2ZIeg1ZUcOJ7h3PW', NULL, '2019-08-20 10:45:03', '2019-08-20 10:45:03', 1),
	(79, 'Naseem Nawaz', 'naseem.nawaz@hblasset.com', '$2y$10$vW8hakUgcNC7Dvr5Gv5Equ5BEBvN7RaALBzcHjvTMs0yGqyVEjN9q', NULL, '2019-08-20 11:18:44', '2019-08-20 11:18:44', 1),
	(80, 'Muhammad Shujaat Khan', 'shujaat.khan@hblasset.com', '$2y$10$AwMv058mdV9lBrPwSvNsAut7r4YwqIwOVqf3An0QRE9k7tdmMf1wK', NULL, '2019-08-20 11:35:45', '2019-08-20 11:35:45', 1),
	(81, 'Wajahat Butt', 'wajahat.butt@hblasset.com', '$2y$10$FM6ANVzhQctPlGV1d3vm4uwTNzEdRzZXzk6USI5SUauu8TZRzpIki', NULL, '2019-08-20 11:38:11', '2019-08-20 11:38:11', 1),
	(82, 'Umair Ahmed', 'umair.ahmed@hblasset.com', '$2y$10$1mEaJoiYVgw6/G1GOyxFhuIa8rw2JMOcIM0Cq/nd/82dy2fEULTR.', NULL, '2019-08-20 12:06:16', '2019-08-20 12:06:16', 1),
	(83, 'Muhammad Waqar', 'muhammad.waqar@hblasset.com', '$2y$10$EAT0NBXyhKQG5mx3uX17xeXS6ug51MOmW8eoYXFCpgOXABYU0fRjS', NULL, '2019-08-20 14:25:03', '2019-08-20 14:25:03', 1),
	(84, 'Muhammad Fahad', 'muhammad.fahad@hblasset.com', '$2y$10$xRb/2/aKF1vHHt5WmK4wMuJl39TMgzQdFvLKXkP0BZRA4tWf9Vpc6', NULL, '2019-08-20 15:06:55', '2019-08-20 15:06:55', 1),
	(85, 'Jazib Ahmed Essani', 'jazib.essani@hblasset.com', '$2y$10$y5ojjALcCSlpKnpJTB/Psu4xgCWwgfiZXLT2dwaxoSIPcvRZvj8hu', NULL, '2019-08-20 15:08:00', '2019-08-20 15:08:00', 1),
	(86, 'Jarar Haider', 'jarar.haider@hblasset.com', '$2y$10$G9.Mvm8E0zmOUrV13PqrWeZIaTy17udEEVv8SDrY8uUzQvNDX5bfO', NULL, '2019-08-20 16:41:11', '2019-08-20 16:41:11', 1),
	(87, 'Agha Abrar', 'agha.abrar@hblasset.com', '$2y$10$cWv4MJXBkRTi3uqUeSb8eeGoPiA0pFM2XzZxOye9EyEvfyxoJoRs.', NULL, '2019-08-27 16:15:51', '2019-08-27 16:15:51', 1),
	(88, 'Zahid Shams', 'zahid.shams@hblasset.com', '$2y$10$KogBGGnBDRmSiJkECLOj0unfLkGA9HfKZfmPnR8FtUaxCy8KgRzou', NULL, '2019-09-18 09:05:13', '2019-09-18 09:05:13', 1),
	(89, 'sales ord', 'sales@ord.com', '$2y$10$L6EIAPmPPvRbU3PhRBXcPOiuin0I8hiIPNjm84eM73el4.BOMa2JC', 'cah6YY2qPoHYwNp1zUxs47qNyqPmon8GZKiiAyvV90gX3DtWMhs8nYv2Snww', '2019-10-02 18:17:20', '2019-10-02 18:17:20', 1),
	(90, 'retail admin', 'retailadmin@ord.com', '$2y$10$ePAtKspWN.lOnNZ7iDdrw.a.hFpgbmCyecE7aVQAi8htpSWU1LlSy', 'IGN4ABY3jkUOy5S6GtlpcyXphGfQyozMUFBjpevr7YyuGTZcBZBv6i7LkzDX', '2019-10-04 13:47:51', '2019-10-04 13:47:51', 3),
	(91, 'retail user', 'retailuser@ord.com', '$2y$10$FRhrQlx9FdvXQnyE7oCABOCI97lmYAaFQHffrCW0E2VMELKWEvg8S', 'c4FzBHOzpl0yMSuvDDbJ5lRHb1ExKnY73AJIKaDoFDcIlN99s5zTsToZKsyM', '2019-10-04 13:55:56', '2019-10-04 13:55:56', 4),
	(93, 'melvin pereira', 'melvin.pereira@hblasset.com', '$2y$10$vIOUo13kfi2V8z5GGke0ce.L6.8RJnJyef.srObsb9mP7/CgCfOvy', 'AumTT3o6NJIssEtAiJPSjspN9Lkg0jEM4jjnY1hhINGDCGt6jcp9YPeiNewX', '2019-10-04 19:41:35', '2019-10-04 19:41:35', 5),
	(94, 'waseem siddiqui', 'waseem.siddiqui@hblasset.com', '$2y$10$1YIUWrqRz0sDLQdCPq6kEOi5fo6DURyI5O7VaXIg.lDuvFJloXZN2', 'EHI5diWK8jyolGW6J2S4FoNXMFI1bGIFUHZtuzxv0P5YbvBT0WWvAdZfRUmE', '2019-10-04 19:42:16', '2019-10-04 19:42:16', 4),
	(95, 'cbc user', 'cbc@ord.com', '$2y$10$SHJNnS51yBffbWiQhL4cwOgCMcnOeq94YBjq8zD/rot2/g92B55tK', 'iTUgAnSoqTdJl3Ovp3tS4181c1huw6YsQsMoitT5tURJXxdEUiqkW5B8kP1z', '2019-12-04 15:51:06', '2019-12-04 15:51:06', 5),
	(96, 'Zia Javed', 'zia.javed@hblasset.com', '$2y$10$Copr5.FlnShz1bT90j9zCuAAA3nzCvih7KcLbLwvK9a5ieT6bxzxy', NULL, '2020-04-17 13:09:03', '2020-04-17 13:09:03', 1),
	(97, 'Ivan N. Johns', 'ivan.johns@hblasset.com', '$2y$10$xaPtY/x/OrI6iRiwncIj3uLMYg/Tcceq6WnuhgF9ZutcLqyqxIMD.', 'D7MHxPzqRH1Envbs183rOoBnGP3Wi6wrP0oKuOtBE8V7v9Mj4G4p5v0IxA63', '2020-04-21 11:41:00', '2020-04-21 11:41:00', 1),
	(98, 'Mir Adil Rashid', 'mir.adil@hblasset.com', '$2y$10$jNkL9j45Pdbtc4KqBR9crul3aacJ2HHcwras4NwfHhd0hZO311beC', NULL, '2020-04-21 11:53:33', '2020-04-21 11:53:33', 1),
	(99, 'Lubna Ahmed', 'lubna.ahmed@hblasset.com', '$2y$10$RHnRA/WewxD2rfw1oKUREevAGjDyv0fXlkTZhacSLvEH7DxNDKvkO', 'AUwPrrMUGzceTJA4rZNP8X1yBFdcOAbU3HBxIJIXZOuc9JB2BR7FDK7Cu0yx', '2020-04-21 11:58:00', '2020-04-21 11:58:00', 1),
	(100, 'Rizwan Syed', 'rizwan.syed@hblasset.com', '$2y$10$raoydCbdJs01qfpF81sTQOkO3zu8cTW5pdaNpLBUP/pZmwosY7S.q', NULL, '2020-04-21 12:03:52', '2020-04-21 12:03:52', 1),
	(101, 'Omair Farooq', 'omair.farooq@hblasset.com', '$2y$10$XPipvmnXjGF/XSGeb7j.iu4LukL1sK3LJzhzAN.Kodr/Sd5w7SmRy', 'HqHz5TDlf05OnuZk1cJ6ptqbeUhJvoovz4SE5ABVzuH7AIyuIOAl0x0fpYNm', '2020-08-20 15:03:19', '2020-08-20 15:03:19', 1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.views
CREATE TABLE IF NOT EXISTS `views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `count` varchar(191) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `update_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.views: ~22 rows (approximately)
/*!40000 ALTER TABLE `views` DISABLE KEYS */;
REPLACE INTO `views` (`id`, `count`, `user_id`, `update_at`) VALUES
	(1, '4', 29, '2018-10-10'),
	(2, '2', 37, '2018-09-05'),
	(3, '7', 23, '2018-10-23'),
	(4, '22', 12, '2018-10-25'),
	(5, '16', 24, '2018-12-27'),
	(6, '80', 30, '2019-06-19'),
	(7, '8', 44, '2018-09-17'),
	(8, '6', 22, '2018-10-17'),
	(9, '5', 31, '2018-09-07'),
	(10, '10', 25, '2019-01-02'),
	(11, '7', 39, '2018-09-07'),
	(12, '11', 56, '2018-10-26'),
	(13, '5', 26, '2019-01-08'),
	(14, '1', 33, NULL),
	(15, '18', 49, '2018-12-10'),
	(16, '172', 11, '2020-09-02'),
	(17, '10', 53, '2019-02-12'),
	(18, '5', 52, '2019-03-18'),
	(19, '11', 51, '2018-10-24'),
	(20, '5', 21, '2018-09-17'),
	(21, '1', 47, NULL),
	(22, '58', 57, '2020-02-14'),
	(23, '54', 60, '2020-06-12'),
	(24, '6', 61, '2019-02-13'),
	(25, '21', 62, '2019-06-20'),
	(26, '3', 67, '2019-08-09'),
	(27, '2', 64, '2019-09-05'),
	(28, '38', 89, '2020-09-01'),
	(29, '1', 97, NULL),
	(30, '4', 99, '2020-04-22'),
	(31, '1', 90, NULL),
	(32, '5', 101, '2020-09-02');
/*!40000 ALTER TABLE `views` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.welcome
CREATE TABLE IF NOT EXISTS `welcome` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table sales-app-live.welcome: ~0 rows (approximately)
/*!40000 ALTER TABLE `welcome` DISABLE KEYS */;
REPLACE INTO `welcome` (`id`, `date`) VALUES
	(1, 'July, 2020.');
/*!40000 ALTER TABLE `welcome` ENABLE KEYS */;

-- Dumping structure for table sales-app-live.ytp
CREATE TABLE IF NOT EXISTS `ytp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sh` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f1` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f2` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f3` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f4` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f5` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table sales-app-live.ytp: ~0 rows (approximately)
/*!40000 ALTER TABLE `ytp` DISABLE KEYS */;
REPLACE INTO `ytp` (`id`, `title`, `sh`, `f1`, `f2`, `f3`, `f4`, `f5`, `created_at`, `updated_at`) VALUES
	(1, 'Your Trusted Partner', 'WHY HBL SHOULD BE YOUR PREFERRED PARTNER?', 'HBL Asset Management Limited (HBL AMC) is backed by the largest and strongest \r\nFinancial institution of Pakistan which boasts of 75 years of rich and successful \r\nhistory. The franchise is associated with trust and credibility for our investors in \r\nmore than 25 countries that their savings are in safe hands.', 'We provide a seamless financial experience to our clients in partnership with HBL. \r\nThe entire product suite ranging from bank accounts to cash management and saving plans available under one umbrella.', 'We manage one of the largest equity portfolios in the country with a size of over Rs 10..63 billion. \r\nOur mutual funds have a demonstrated track record of over 10 years of superior returns.', 'No conflicts and no third parties involved as we take pride in providing all services in-house. \r\nOur experienced research team provides detailed equity and economic reports.', 'An experienced management team boasting exposure of both local and international markets.', NULL, NULL);
/*!40000 ALTER TABLE `ytp` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
